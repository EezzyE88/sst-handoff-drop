import { useEffect, useRef, useState } from "react"
import { useSyncExternalStore } from "react"
import { BookOpen, Building2, HardHat, LocateFixed, X } from "lucide-react"
import { syncAudio, unlockAudio } from "@/game/audio"
import { drawWorld, focusAt, frameCamera, pickId, type Camera, type FrameFocus } from "@/game/draw"
import {
  armReset,
  boot,
  cancelBuild,
  commission,
  confirmBuild,
  dismissWelcome,
  continueGame,
  openSandbox,
  flushSave,
  getServerSnapshot,
  getSnapshot,
  hirePorter,
  hireTech,
  hireTech2,
  hireManager,
  releaseManager,
  noteLook,
  openSheet,
  readWorld,
  runAction,
  saveGame,
  select,
  setAsking,
  setPriority,
  setServicePlan,
  setSpeed,
  startMakeReady,
  startRepair,
  step,
  subscribe,
  toggleInterior,
  toggleSound,
  type Snap,
} from "@/game/engine"
import { money } from "@/game/economy"
import type { Speed } from "@/game/types"

function applyScale(cam: Camera, next: number, mx: number, my: number) {
  const clamped = Math.min(18, Math.max(1.35, next))
  const k = clamped / cam.scale
  cam.ox = mx - (mx - cam.ox) * k
  cam.oy = my - (my - cam.oy) * k
  cam.scale = clamped
}

export function MapleGame() {
  const snap = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const cam = useRef<Camera>({ ox: 40, oy: 80, scale: 6 })
  const framed = useRef(false)
  const panned = useRef(false)
  const optsRef = useRef<((rect: DOMRect) => { focus?: FrameFocus; insetBottom: number; at?: { x: number; y: number; w: number; d: number } }) | null>(null)
  const pointers = useRef(new Map<number, { x: number; y: number }>())
  const drag = useRef<{ x: number; y: number; ox: number; oy: number; moved: boolean } | null>(null)
  const pinchDist = useRef<number | null>(null)
  const [savedFlash, setSavedFlash] = useState(false)
  const savedTimer = useRef(0)
  const sheetRef = useRef<HTMLElement>(null)
  const [sheetH, setSheetH] = useState(0)

  useEffect(() => {
    const el = sheetRef.current
    if (!el) {
      setSheetH(0)
      return
    }
    const measure = () => setSheetH(Math.round(el.getBoundingClientRect().height))
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
  }, [snap.sheet, snap.selection?.title])

  useEffect(() => {
    boot()
    const canvas = canvasRef.current
    if (!canvas) return
    let raf = 0
    let last = performance.now()
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    const fit = () => {
      const rect = canvas.getBoundingClientRect()
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas.width = Math.max(1, Math.floor(rect.width * dpr))
      canvas.height = Math.max(1, Math.floor(rect.height * dpr))
      if (!panned.current && rect.width > 40 && rect.height > 40) {
        const opts = optsRef.current?.(rect)
        if (opts) frameCamera(cam.current, rect.width, rect.height, opts)
        framed.current = true
      }
    }
    fit()
    const ro = new ResizeObserver(fit)
    ro.observe(canvas)
    const loop = (now: number) => {
      const raw = Number.isFinite(now) && Number.isFinite(last) ? (now - last) / 1000 : 0
      const dt = Number.isFinite(raw) ? Math.min(0.05, Math.max(0, raw)) : 0
      if (Number.isFinite(now)) last = now
      step(dt)
      try {
        syncAudio(readWorld())
        const ctx = canvas.getContext("2d")
        if (ctx) {
          const dpr = Math.min(window.devicePixelRatio || 1, 2)
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
          drawWorld(ctx, readWorld(), cam.current, now / 1000, reduced)
        }
      } catch {
        /* a bad frame must not stop the clock */
      }
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    const onHide = () => {
      if (document.hidden) flushSave()
    }
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA") return
      if (e.key === " " || e.key === "0") {
        e.preventDefault()
        setSpeed(0)
      } else if (e.key === "1") setSpeed(1)
      else if (e.key === "2") setSpeed(2)
      else if (e.key === "4") setSpeed(4)
    }
    const onWheel = (e: WheelEvent) => {
      e.preventDefault()
      const rect = canvas.getBoundingClientRect()
      const factor = e.deltaY > 0 ? 0.92 : 1.08
      applyScale(cam.current, cam.current.scale * factor, e.clientX - rect.left, e.clientY - rect.top)
    }
    canvas.addEventListener("wheel", onWheel, { passive: false })
    document.addEventListener("visibilitychange", onHide)
    window.addEventListener("keydown", onKey)
    window.addEventListener("pagehide", flushSave)
    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      canvas.removeEventListener("wheel", onWheel)
      document.removeEventListener("visibilitychange", onHide)
      window.removeEventListener("keydown", onKey)
      window.removeEventListener("pagehide", flushSave)
    }
  }, [])

  useEffect(() => {
    panned.current = false
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    if (rect.width < 40 || rect.height < 40) return
    frameCamera(cam.current, rect.width, rect.height, viewOpts(rect))
    framed.current = true
  }, [snap.sheet, snap.welcome, snap.selection?.title, snap.place])

  useEffect(() => {
    if (panned.current) return
    const canvas = canvasRef.current
    if (!canvas || sheetH <= 0) return
    const rect = canvas.getBoundingClientRect()
    if (rect.width < 40 || rect.height < 40) return
    frameCamera(cam.current, rect.width, rect.height, viewOpts(rect))
  }, [sheetH])

  function viewOpts(rect: DOMRect) {
    const w = readWorld()
    const phone = rect.width < 768
    const openSheet = snap.sheet === "inspect" || snap.sheet === "build"
    const cap = Math.min(rect.height * 0.46, 280)
    const insetBottom = !phone ? (w.welcome ? 160 : 0) : openSheet ? (sheetH > 0 ? Math.min(sheetH, cap) : cap) : w.welcome ? Math.min(200, rect.height * 0.42) : 0
    if (snap.sheet === "inspect") {
      const at = focusAt(w, w.selectedId)
      if (at) return { insetBottom, at }
    }
    if (snap.sheet === "build") {
      const focus: FrameFocus = w.view === "cedar" ? "cedar" : "pads"
      return { focus, insetBottom }
    }
    if (w.welcome) return { focus: "front" as const, insetBottom }
    const focus: FrameFocus = w.view === "cedar" ? "cedar" : "site"
    return { focus, insetBottom }
  }
  optsRef.current = viewOpts

  function frame() {
    const canvas = canvasRef.current
    if (!canvas) return
    panned.current = false
    const rect = canvas.getBoundingClientRect()
    const w = readWorld()
    frameCamera(cam.current, rect.width, rect.height, { focus: w.view === "cedar" ? "cedar" : "site" })
    framed.current = true
  }

  function onPointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
    if (readWorld().sound) unlockAudio()
    e.currentTarget.setPointerCapture(e.pointerId)
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY })
    if (pointers.current.size === 1) {
      drag.current = { x: e.clientX, y: e.clientY, ox: cam.current.ox, oy: cam.current.oy, moved: false }
      pinchDist.current = null
    } else if (pointers.current.size >= 2) {
      const pts = [...pointers.current.values()]
      pinchDist.current = Math.hypot(pts[0]!.x - pts[1]!.x, pts[0]!.y - pts[1]!.y)
      drag.current = null
    }
  }

  function onPointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!pointers.current.has(e.pointerId)) return
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY })
    if (pointers.current.size >= 2 && pinchDist.current) {
      const pts = [...pointers.current.values()]
      const dist = Math.hypot(pts[0]!.x - pts[1]!.x, pts[0]!.y - pts[1]!.y)
      const rect = e.currentTarget.getBoundingClientRect()
      const mx = (pts[0]!.x + pts[1]!.x) / 2 - rect.left
      const my = (pts[0]!.y + pts[1]!.y) / 2 - rect.top
      applyScale(cam.current, cam.current.scale * (dist / pinchDist.current), mx, my)
      pinchDist.current = dist
      return
    }
    const pan = drag.current
    if (!pan || pointers.current.size !== 1) return
    const dx = e.clientX - pan.x
    const dy = e.clientY - pan.y
    if (Math.hypot(dx, dy) > 8) {
      pan.moved = true
      panned.current = true
    }
    cam.current.ox = pan.ox + dx
    cam.current.oy = pan.oy + dy
  }

  function look() {
    dismissWelcome()
    frameFront()
  }

  function sandbox() {
    openSandbox()
    frameFront()
  }

  function frameFront() {
    dismissWelcome()
    panned.current = false
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const canvas = canvasRef.current
        if (!canvas) return
        const rect = canvas.getBoundingClientRect()
        frameCamera(cam.current, rect.width, rect.height, { focus: "front" })
      })
    })
  }

  function onPointerUp(e: React.PointerEvent<HTMLCanvasElement>) {
    const pan = drag.current
    pointers.current.delete(e.pointerId)
    if (pointers.current.size < 2) pinchDist.current = null
    if (pan?.moved) noteLook()
    if (pan && !pan.moved && pointers.current.size === 0) {
      const rect = e.currentTarget.getBoundingClientRect()
      const id = pickId(cam.current, e.clientX - rect.left, e.clientY - rect.top, readWorld())
      if (id) select(id)
      else noteLook()
    }
    if (pointers.current.size === 0) drag.current = null
  }

  return (
    <main className="flex h-full min-h-0 flex-col bg-shell">
      <h1 className="sr-only">Self Storage Tycoon</h1>
      <header className="safe-top z-30 shrink-0 border-b border-line bg-panel px-3 pb-2 text-ink">
        <div className="flex items-baseline justify-between gap-3">
          <div>
            <p className="font-display text-xl leading-none font-semibold tracking-tight">{snap.place}</p>
            <p className="mt-1 text-xs text-muted">
              {snap.clock} · Energy {snap.energy}
              {snap.override ? ` · ${snap.override}` : ""}
            </p>
            {snap.goalLine ? <p className="mt-0.5 text-xs font-semibold">{snap.goalLine}</p> : null}
            {snap.dayNote && <p className="mt-1 line-clamp-2 text-xs leading-snug text-muted">{snap.dayNote}</p>}
            {snap.goal && <p className="mt-0.5 text-xs font-semibold text-ink">{snap.goal}</p>}
            {snap.switchSite && (
              <button type="button" onClick={() => runAction(snap.switchSite!.id)} className="mt-1 min-h-11 text-left text-sm font-semibold">
                {snap.switchSite.label}
              </button>
            )}
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold tabular-nums">
              {snap.cash} <span className="text-xs font-normal text-muted">{snap.leased}</span>
            </p>
            {snap.books.owedLive && <p className="text-xs font-semibold">Owed {snap.books.owed}. Not cash.</p>}
            <p className="text-xs text-muted">
              Daily {snap.books.daily} · {snap.books.atRent || `Rent in ${snap.books.nextRent}`}
            </p>
          </div>
        </div>
        <div className="mt-1 grid grid-cols-7 gap-1">
          <SpeedButton speed={0} current={snap.speed} label="Pause" />
          <SpeedButton speed={1} current={snap.speed} label="1×" />
          <SpeedButton speed={2} current={snap.speed} label="2×" />
          <SpeedButton speed={4} current={snap.speed} label="4×" />
          <button
            type="button"
            onClick={() => {
              if (!saveGame()) return
              setSavedFlash(true)
              window.clearTimeout(savedTimer.current)
              savedTimer.current = window.setTimeout(() => setSavedFlash(false), 1600)
            }}
            className="inline-flex min-h-11 items-center justify-center rounded-lg border border-line bg-panel-2 px-0.5 text-xs font-semibold text-ink"
          >
            {savedFlash ? "Saved" : "Save"}
          </button>
          <button
            type="button"
            onClick={frame}
            aria-label="Frame the lot"
            className="inline-flex min-h-11 items-center justify-center rounded-lg border border-line bg-panel-2 px-0.5 text-xs font-semibold text-ink"
          >
            Center
          </button>
          <button
            type="button"
            onClick={toggleSound}
            aria-label={snap.sound ? "Sound off" : "Sound on"}
            aria-pressed={snap.sound}
            className={`inline-flex min-h-11 items-center justify-center rounded-lg px-0.5 text-xs font-semibold ${snap.sound ? "bg-ink text-panel" : "border border-line bg-panel-2 text-ink"}`}
          >
            {snap.sound ? "Sound" : "Muted"}
          </button>
        </div>
      </header>

      {snap.coach && !snap.welcome && (snap.coach.action?.id === "speed1" || (snap.sheet !== "inspect" && snap.sheet !== "build")) && (
        <section className="z-20 shrink-0 border-b border-line bg-panel px-3 py-2 text-ink">
          <p className="text-sm font-semibold">{snap.coach.title}</p>
          <p className="mt-0.5 line-clamp-2 text-sm leading-snug text-muted">{snap.coach.body}</p>
          {snap.coach.action && (snap.coach.action.id === "speed1" || !sheetHasAction(snap)) && (
            <div className="mt-2">
              <Btn wide tone="accent" onClick={() => runAction(snap.coach!.action!.id)}>
                {snap.coach.action.label}
              </Btn>
            </div>
          )}
        </section>
      )}

      <div className="relative min-h-0 flex-1 overflow-hidden">
        <canvas
          ref={canvasRef}
          aria-label={`${snap.place} Storage, overhead view`}
          className="absolute inset-0 h-full w-full touch-none"
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
        />

        {snap.toast && (
          <p className="pointer-events-none absolute inset-x-3 top-3 z-20 rounded-lg bg-ink px-3 py-2 text-center text-sm text-panel">
            {snap.toast}
          </p>
        )}

        {snap.welcome && (
          <section className="absolute inset-x-3 bottom-3 z-30 max-w-md rounded-lg border border-line bg-panel p-3 text-ink shadow-sm">
            <p className="font-display text-lg leading-tight font-semibold">Maple Street Storage</p>
            <p className="mt-1 text-sm leading-snug">
              {snap.saved
                ? "Your last game is still here. Sandbox is a separate gated lot, and it does not replace that save."
                : "Run the open facility, or start with a gated lot and build it yourself. Time stays paused."}
            </p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {snap.saved ? (
                <Btn tone="accent" onClick={() => { continueGame(); frameFront() }}>
                  Continue
                </Btn>
              ) : (
                <Btn tone="accent" onClick={look}>
                  Run the business
                </Btn>
              )}
              <Btn onClick={sandbox}>{snap.sandboxSaved ? "Continue sandbox" : "Sandbox"}</Btn>
            </div>
          </section>
        )}

        {snap.sheet !== "none" && snap.sheet !== "books" && snap.sheet !== "crew" && (
          <section ref={sheetRef} className="absolute inset-x-0 bottom-0 z-30 flex max-h-[min(46%,280px)] flex-col overflow-hidden border-t border-line bg-panel text-ink md:top-0 md:right-0 md:bottom-0 md:left-auto md:max-h-full md:w-96 md:overflow-y-auto md:border-t-0 md:border-l">
            <Sheet snap={snap} />
          </section>
        )}
      </div>

      <nav className="safe-bottom z-40 grid shrink-0 grid-cols-4 gap-1 border-t border-line bg-panel px-2 py-2 text-ink">
        <NavButton label="Site" active={snap.sheet === "none"} onClick={() => openSheet("none")}>
          <LocateFixed size={18} />
        </NavButton>
        <NavButton label="Build" active={snap.sheet === "build"} onClick={() => openSheet("build")}>
          <Building2 size={18} />
        </NavButton>
        <NavButton label="Books" active={snap.sheet === "books"} onClick={() => openSheet("books")}>
          <BookOpen size={18} />
        </NavButton>
        <NavButton label="Crew" active={snap.sheet === "crew"} onClick={() => openSheet("crew")}>
          <HardHat size={18} />
        </NavButton>
      </nav>
      {(snap.sheet === "books" || snap.sheet === "crew") && <Desk snap={snap} />}
    </main>
  )
}

function SpeedButton({ speed, current, label }: { speed: Speed; current: Speed; label: string }) {
  const on = current === speed
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={() => setSpeed(speed)}
      className={`inline-flex min-h-11 items-center justify-center rounded-lg px-0.5 text-xs font-semibold ${on ? "bg-ink text-panel" : "border border-line bg-panel-2 text-ink"}`}
    >
      {label}
    </button>
  )
}

function NavButton({
  label,
  active,
  onClick,
  children,
}: {
  label: string
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={`flex min-h-14 flex-col items-center justify-center gap-0.5 rounded-lg text-xs font-semibold ${active ? "bg-ink text-panel" : "text-ink"}`}
    >
      {children}
      {label}
    </button>
  )
}

function Btn({
  children,
  onClick,
  tone = "ghost",
  disabled = false,
  wide = false,
}: {
  children: React.ReactNode
  onClick: () => void
  tone?: "accent" | "ghost"
  disabled?: boolean
  wide?: boolean
}) {
  const cls = tone === "accent" ? "bg-accent text-ink" : "border border-line bg-panel-2 text-ink"
  return (
    <button type="button" disabled={disabled} onClick={onClick} className={`min-h-11 rounded-lg px-3 text-sm font-semibold disabled:opacity-40 ${wide ? "w-full" : ""} ${cls}`}>
      {children}
    </button>
  )
}

function sheetHasAction(snap: Snap) {
  if (snap.sheet === "inspect") return (snap.selection?.actions.length ?? 0) > 0 || Boolean(snap.selection?.price)
  if (snap.sheet === "build") return true
  return false
}

function Desk({ snap }: { snap: Snap }) {
  const books = snap.sheet === "books"
  return (
    <section className="fixed inset-0 z-50 flex flex-col bg-panel text-ink">
      <header className="safe-top shrink-0 border-b border-line px-4 pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-muted">{snap.place}</p>
            <h2 className="font-display text-2xl leading-tight font-semibold">{books ? "Books" : "Crew"}</h2>
            <p className="mt-1 text-sm leading-snug text-muted">
              {snap.resume === "stay paused" || !snap.resume
                ? "The clock stays paused when you leave."
                : `The clock is paused. Leaving returns you to ${snap.resume}.`}
            </p>
          </div>
          <button
            type="button"
            onClick={() => openSheet("none")}
            className="min-h-11 shrink-0 rounded-lg bg-ink px-3 text-sm font-semibold text-panel"
          >
            Back to the lot
          </button>
        </div>
        {snap.coach && (
          <div className="mt-3 rounded-lg bg-panel-2 px-3 py-2">
            <p className="text-sm font-semibold">{snap.coach.title}</p>
            <p className="mt-0.5 line-clamp-2 text-sm leading-snug text-muted">{snap.coach.body}</p>
            {snap.coach.action && (
              <div className="mt-2">
                <Btn wide tone="accent" onClick={() => runAction(snap.coach!.action!.id)}>
                  {snap.coach.action.label}
                </Btn>
              </div>
            )}
          </div>
        )}
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-4">
        {books ? <Books snap={snap} /> : <Crew snap={snap} />}
      </div>
      <nav className="safe-bottom grid shrink-0 grid-cols-4 gap-1 border-t border-line px-2 py-2">
        <NavButton label="Site" active={false} onClick={() => openSheet("none")}>
          <LocateFixed size={18} />
        </NavButton>
        <NavButton label="Build" active={false} onClick={() => openSheet("build")}>
          <Building2 size={18} />
        </NavButton>
        <NavButton label="Books" active={books} onClick={() => openSheet("books")}>
          <BookOpen size={18} />
        </NavButton>
        <NavButton label="Crew" active={!books} onClick={() => openSheet("crew")}>
          <HardHat size={18} />
        </NavButton>
      </nav>
    </section>
  )
}

function Stat({ k, v, hint }: { k: string; v: string; hint?: string }) {
  return (
    <div className="rounded-lg bg-panel-2 px-3 py-2">
      <p className="text-xs text-muted">{k}</p>
      <p className="text-lg font-semibold tabular-nums">{v}</p>
      {hint && <p className="text-xs leading-snug text-muted">{hint}</p>}
    </div>
  )
}

function Sheet({ snap }: { snap: Snap }) {
  return (
    <div className="contents md:block">
      <div className="flex shrink-0 items-start justify-between gap-3 px-4 pt-3">
        <h2 className="font-display text-xl leading-tight font-semibold">
          {snap.sheet === "build" && "Build"}
          {snap.sheet === "inspect" && (snap.selection?.title ?? "Inspect")}
        </h2>
        <button
          type="button"
          aria-label="Close"
          onClick={() => openSheet("none")}
          className="grid min-h-11 min-w-11 shrink-0 place-items-center rounded-lg border border-line bg-panel-2"
        >
          <X size={18} />
        </button>
      </div>
      <SheetActions snap={snap} />
      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-2">
        {snap.sheet === "inspect" && snap.selection && <InspectFacts snap={snap} />}
        {snap.sheet === "build" && <BuildFacts snap={snap} />}
      </div>
    </div>
  )
}

function InspectFacts({ snap }: { snap: Snap }) {
  const sel = snap.selection
  if (!sel) return null
  return (
    <div className="space-y-2">
      <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
        {sel.lines.map((line) => (
          <div key={line.k} className="contents">
            <dt className="text-muted">{line.k}</dt>
            <dd className="font-medium">{line.v}</dd>
          </div>
        ))}
      </dl>
      {sel.note && <p className="text-sm leading-snug text-muted">{sel.note}</p>}
      {sel.progress !== null && (
        <div className="h-2 overflow-hidden rounded-full bg-panel-2">
          <div className="h-full bg-accent" style={{ width: `${Math.round(sel.progress * 100)}%` }} />
        </div>
      )}
    </div>
  )
}

function SheetActions({ snap }: { snap: Snap }) {
  if (snap.sheet === "inspect" && snap.selection) {
    const sel = snap.selection
    if (!sel.actions.length && !sel.price) return null
    return (
      <div className="shrink-0 space-y-2 border-t border-line px-4 py-2">
        {sel.price && (
          <label className="block text-sm">
            <span className="font-medium">Asking rent {money(sel.price.value)} / month</span>
            <input
              className="mt-1 w-full accent-accent"
              type="range"
              min={sel.price.min}
              max={sel.price.max}
              value={sel.price.value}
              onChange={(e) => setAsking(sel.price!.key, Number(e.target.value))}
            />
          </label>
        )}
        <div className="flex flex-col gap-2">
          {sel.actions.map((action) => (
            <Btn key={action.id} wide tone={action.tone} onClick={() => (action.id === "make-ready" ? startMakeReady() : action.id === "repair" ? startRepair() : runAction(action.id))}>
              {action.label}
            </Btn>
          ))}
        </div>
      </div>
    )
  }
  if (snap.sheet !== "build") return null
  const build = snap.build
  const cedar = build.site === "cedar"
  return (
    <div className="flex shrink-0 flex-col gap-2 border-t border-line px-4 py-2">
      {!build.finished &&
        (cedar ? (
          <Btn wide tone="accent" disabled={!build.canConfirm} onClick={() => runAction("cedar-row")}>
            Add the Cedar row
          </Btn>
        ) : (
          <Btn wide tone="accent" disabled={!build.canConfirm} onClick={confirmBuild}>
            Confirm build
          </Btn>
        ))}
      {build.canCancel && (
        <Btn wide tone="ghost" onClick={cedar ? () => runAction("cancel-cedar-row") : cancelBuild}>
          Cancel build, refund {build.refund}
        </Btn>
      )}
      {build.commissioning && (
        <Btn wide tone="accent" onClick={cedar ? () => runAction("commission-cedar") : commission}>
          Commission row
        </Btn>
      )}
    </div>
  )
}

function BuildFacts({ snap }: { snap: Snap }) {
  const build = snap.build
  const cedar = build.site === "cedar"
  return (
    <div className="space-y-2 text-sm leading-snug">
      <p className="line-clamp-2 text-sm leading-snug">{build.reason}</p>
      <dl className="grid grid-cols-2 gap-y-1">
        <dt className="text-muted">Units</dt>
        <dd className="font-medium">{build.finished ? "Built" : cedar ? "2 at Cedar Court" : build.picks || "None yet"}</dd>
        <dt className="text-muted">Cost</dt>
        <dd className="font-medium">{build.cost}</dd>
        <dt className="text-muted">Added daily cost</dt>
        <dd className="font-medium">{build.daily}</dd>
        <dt className="text-muted">Time</dt>
        <dd className="font-medium">{build.duration}</dd>
      </dl>
      {build.progress !== null && (
        <div className="h-2 overflow-hidden rounded-full bg-panel-2">
          <div className="h-full bg-accent" style={{ width: `${Math.round(build.progress * 100)}%` }} />
        </div>
      )}
    </div>
  )
}

function Books({ snap }: { snap: Snap }) {
  const books = snap.books
  const groups = [
    ["look", "Needs a look"],
    ["empty", "Empty"],
    ["leased", "Leased"],
  ] as const
  return (
    <div className="mx-auto max-w-lg space-y-5 text-sm">
      <div className="grid grid-cols-2 gap-2">
        <Stat k="Cash" v={snap.cash} hint="Spendable" />
        <Stat k="Owed" v={books.owed} hint={books.owedHint} />
        <Stat k="Rent roll" v={books.roll} hint="Listed leases, per month. Not cash." />
        <Stat k="Daily cost" v={books.daily} hint="Comes out every day" />
        <Stat k="Next rent" v={books.nextRent} hint={`Last collection ${books.lastRent}, ${books.rentWhen.toLowerCase()}`} />
      </div>
      {(books.market || books.pass) && (
        <p className="rounded-lg border border-line px-3 py-2 leading-snug">
          {books.market}
          {books.pass ? <span className="mt-1 block font-semibold">{books.pass}</span> : null}
        </p>
      )}
      <p className="rounded-lg border border-line px-3 py-2 leading-relaxed">{books.month}</p>
      {books.ledger.length > 0 && (
        <section>
          <h3 className="text-xs font-semibold tracking-wide text-muted">Recent money</h3>
          <ul className="mt-2 divide-y divide-line rounded-lg border border-line">
            {books.ledger.map((row, index) => (
              <li key={`${row.text}-${index}`} className="flex items-baseline justify-between gap-3 px-3 py-2">
                <span>{row.text}</span>
                {row.amount && <span className="shrink-0 font-semibold tabular-nums">{row.amount}</span>}
              </li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-muted">Cash is what you can spend. Owed is billed and not collected. The month line is a guess if everyone pays.</p>
        </section>
      )}
      {books.cedar && (
        <div className="rounded-lg border border-line px-3 py-2">
          <p className="leading-relaxed">
            Cedar Court is {books.cedar.cost} from company cash. The quarter needs it open. Maple Street keeps its own lines.
          </p>
          <div className="mt-2">
            {books.cedar.ready ? (
              <Btn wide tone="accent" onClick={() => runAction("buy-cedar")}>
                Buy Cedar Court
              </Btn>
            ) : (
              <p className="text-muted">Not enough cash for Cedar Court.</p>
            )}
          </div>
        </div>
      )}
      {books.gap && (
        <p className="rounded-lg border border-line px-3 py-2 leading-relaxed">
          Before the next check, about {books.gap.before}. The rent roll is {books.roll}, so the check leaves about {books.gap.after} if nothing else is spent.
          {books.gap.short ? " That is still thin." : ""}
        </p>
      )}
      {groups.map(([group, title]) => {
        if (group !== "look") return null
        const rows = books.units.filter((unit) => unit.group === group)
        if (!rows.length) return null
        return (
          <section key={group}>
            <h3 className="text-xs font-semibold tracking-wide text-muted">
              {title} · {rows.length}
            </h3>
            <ul className="mt-1">
              {rows.map((unit) => (
                <li key={unit.id}>
                  <button
                    type="button"
                    onClick={() => select(unit.id)}
                    className="flex min-h-11 w-full items-center justify-between gap-3 rounded-lg px-1 text-left"
                  >
                    <span className="font-semibold">{unit.number}</span>
                    <span className="text-right text-muted">
                      {unit.line}
                      <span className="block text-ink">{unit.state}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )
      })}
      <section className="rounded-lg border border-line px-3 py-2 leading-relaxed">
        <h3 className="text-xs font-semibold tracking-wide text-muted">The property</h3>
        <p className="mt-1 font-semibold">{books.full}</p>
        <p className="mt-1 text-muted">{books.market}</p>
        {books.pass ? <p className="mt-1 text-muted">{books.pass}</p> : null}
      </section>
      {snap.sandbox ? (
        <section className="rounded-lg border border-line px-3 py-2">
          <h3 className="text-xs font-semibold tracking-wide text-muted">This sandbox</h3>
          <p className="mt-1 leading-snug">{snap.rules}</p>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Btn onClick={() => runAction("sandbox-business")}>Business cash</Btn>
            <Btn onClick={() => runAction("sandbox-free")}>Free build</Btn>
            <Btn onClick={() => runAction("instant-on")}>Instant on</Btn>
            <Btn onClick={() => runAction("instant-off")}>Instant off</Btn>
            <Btn onClick={() => runAction("upkeep-off")}>No new faults</Btn>
            <Btn onClick={() => runAction("upkeep-normal")}>Normal faults</Btn>
            <Btn onClick={() => runAction("upkeep-often")}>Faults sooner</Btn>
            <Btn onClick={() => runAction("goal-row")}>Goal: a new row</Btn>
            <Btn onClick={() => runAction("goal-profit")}>Goal: 30-day cash</Btn>
            <Btn onClick={() => runAction("goal-none")}>Clear goal</Btn>
          </div>
        </section>
      ) : null}
      <div className="grid grid-cols-2 gap-2">
        <Btn onClick={() => runAction("checkpoint")}>Save checkpoint</Btn>
        <Btn disabled={!snap.checkpoint} onClick={() => runAction("restore-checkpoint")}>
          Restore
        </Btn>
        {snap.sandbox ? (
          <Btn onClick={() => runAction("add-funds")}>Add $5,000</Btn>
        ) : null}
      </div>
      <section>
        <h3 className="text-xs font-semibold tracking-wide text-muted">Where the daily cost goes</h3>
        <ul className="mt-2 divide-y divide-line rounded-lg border border-line">
          {books.split.map((row) => (
            <li key={row.k} className="flex items-baseline justify-between gap-3 px-3 py-2">
              <span>{row.k}</span>
              <span className="font-semibold tabular-nums">{row.v}</span>
            </li>
          ))}
          <li className="flex items-baseline justify-between gap-3 px-3 py-2">
            <span>
              Construction
              <span className="block text-xs text-muted">Not part of the daily cost</span>
            </span>
            <span className="font-semibold tabular-nums">{books.construction}</span>
          </li>
          {books.injected ? (
            <li className="flex items-baseline justify-between gap-3 px-3 py-2">
              <span>
                Sandbox funds
                <span className="block text-xs text-muted">Not income</span>
              </span>
              <span className="font-semibold tabular-nums">{books.injected}</span>
            </li>
          ) : null}
        </ul>
      </section>
      {books.sites.length > 1 && (
        <section>
          <h3 className="text-xs font-semibold tracking-wide text-muted">By site</h3>
          <ul className="mt-2 space-y-2">
            {books.sites.map((site) => (
              <li key={site.name} className="rounded-lg bg-panel-2 px-3 py-2">
                <p className="font-semibold">{site.name}</p>
                <p className="text-muted">Rent {site.roll} · daily {site.daily}</p>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-muted">Company cash is shared. One site cannot hide inside the other.</p>
        </section>
      )}
      {books.choice && (
        <section className="rounded-lg border border-line px-3 py-2 leading-relaxed">
          <h3 className="text-xs font-semibold tracking-wide text-muted">Where the next dollar goes</h3>
          <p className="mt-1">
            Two more drive-up units at Cedar Court are {books.choice.cost}. Maple Street does not get them.
          </p>
          {books.choice.short ? (
            <p className="mt-1 text-muted">There is not enough cash for the row. Keeping the reserve leaves Cedar the size it is.</p>
          ) : (
            <>
              <p className="mt-1 text-muted">
                After the row: {books.choice.after}, about {books.choice.days} {books.choice.days === 1 ? "day" : "days"} of company operating cost.
                {books.choice.thin ? " The reserve would be thin." : ""}
              </p>
              <p className="mt-1 text-muted">Keep the reserve: cash stays {snap.cash}. Neither site gains units.</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Btn tone="accent" onClick={() => runAction("cedar-row")}>
                  Add the Cedar row
                </Btn>
                <Btn tone="ghost" onClick={() => runAction("keep-reserve")}>
                  Keep the reserve
                </Btn>
              </div>
            </>
          )}
        </section>
      )}
      <p className="rounded-lg border border-line px-3 py-2 leading-relaxed text-muted">{books.note}</p>
      {groups.map(([group, title]) => {
        if (group === "look") return null
        const rows = books.units.filter((unit) => unit.group === group)
        if (!rows.length) return null
        return (
          <section key={group}>
            <h3 className="text-xs font-semibold tracking-wide text-muted">
              {title} · {rows.length}
            </h3>
            <ul className="mt-1">
              {rows.map((unit) => (
                <li key={unit.id}>
                  <button
                    type="button"
                    onClick={() => select(unit.id)}
                    className="flex min-h-11 w-full items-center justify-between gap-3 rounded-lg px-1 text-left"
                  >
                    <span className="font-semibold">{unit.number}</span>
                    <span className="text-right text-muted">
                      {unit.line}
                      <span className="block text-ink">{unit.state}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )
      })}
    </div>
  )
}

function Crew({ snap }: { snap: Snap }) {
  return (
    <div className="mx-auto max-w-lg space-y-5 text-sm leading-relaxed">
      <section className="space-y-2">
        <h3 className="text-xs font-semibold tracking-wide text-muted">People</h3>
        <p className="text-muted">
          Energy {snap.energy} today. Jobs you start are queued and assigned in order, up to the energy you have. Each hire adds one.
        </p>
        <article className="rounded-lg bg-panel-2 px-3 py-2">
          <p className="font-semibold">Owner</p>
          <p className="text-muted">On site. One job at a time. No wage.</p>
        </article>
        <article className="rounded-lg bg-panel-2 px-3 py-2">
          <p className="font-semibold">Porter · {snap.crew.wage} a day</p>
          <p className="text-muted">Sweeps, carts, and the lot. Not the elevator.</p>
          <div className="mt-2">
            {snap.crew.porter ? (
              <p className="text-good">On the payroll.</p>
            ) : (
              <Btn tone="accent" onClick={hirePorter}>
                Hire Porter
              </Btn>
            )}
          </div>
        </article>
        {snap.crew.offerTech && (
          <article className="rounded-lg bg-panel-2 px-3 py-2">
            <p className="font-semibold">Tech · {snap.crew.techWage} a day</p>
            <p className="text-muted">Elevator, lights, and the plant.</p>
            <div className="mt-2">
              {snap.crew.tech ? (
                <p className="text-good">On the payroll.</p>
              ) : (
                <Btn tone="accent" onClick={hireTech}>
                  Hire Tech
                </Btn>
              )}
            </div>
          </article>
        )}
        {(snap.crew.tech2 || snap.crew.offerTech2) && (
          <article className="rounded-lg bg-panel-2 px-3 py-2">
            <p className="font-semibold">Second Tech · {snap.crew.techWage} a day</p>
            <p className="text-muted">Takes the next repair while the first Tech is still on a job.</p>
            <div className="mt-2">
              {snap.crew.tech2 ? (
                <p className="text-good">On the payroll.</p>
              ) : (
                <Btn tone="accent" onClick={hireTech2}>
                  Hire second Tech
                </Btn>
              )}
            </div>
          </article>
        )}
        {snap.crew.offerManager && (
          <article className="rounded-lg bg-panel-2 px-3 py-2">
            <p className="font-semibold">Manager · {snap.crew.managerWage} a day</p>
            <p className="text-muted">Stays in the office and queues routine work. Does not sweep, and does not override a dropped service plan.</p>
            <div className="mt-2">
              {snap.crew.manager ? (
                <div className="space-y-2">
                  <p className="text-good">On the payroll.</p>
                  <Btn tone="ghost" onClick={releaseManager}>
                    Release the Manager
                  </Btn>
                </div>
              ) : (
                <Btn tone="accent" onClick={hireManager}>
                  Hire a Manager
                </Btn>
              )}
            </div>
          </article>
        )}
      </section>
      {snap.crew.showPriority && (
        <section className="space-y-2">
          <h3 className="text-xs font-semibold tracking-wide text-muted">Who takes the next job</h3>
          <p className="text-muted">
            When one person can do either job, they take {snap.crew.priority === "equipment" ? "equipment" : "turnover"} first.
          </p>
          <div className="flex flex-wrap gap-2">
            <Btn tone={snap.crew.priority === "equipment" ? "accent" : "ghost"} onClick={() => setPriority("equipment")}>
              Equipment first
            </Btn>
            <Btn tone={snap.crew.priority === "turnover" ? "accent" : "ghost"} onClick={() => setPriority("turnover")}>
              Turnover first
            </Btn>
          </div>
          {snap.crew.canPlan && (
            <>
              <p className="text-muted">
                {snap.crew.plan
                  ? "Service plan is on. The next elevator visit is queued before a failure."
                  : "No service plan. The cab can fail if nobody services it."}
              </p>
              <Btn tone={snap.crew.plan ? "ghost" : "accent"} onClick={() => setServicePlan(!snap.crew.plan)}>
                {snap.crew.plan ? "Drop the service plan" : "Keep a service plan"}
              </Btn>
            </>
          )}
        </section>
      )}
      <section>
        <h3 className="text-xs font-semibold tracking-wide text-muted">Open work · {snap.crew.tasks.length}</h3>
        {snap.crew.tasks.length === 0 ? (
          <p className="mt-1 text-muted">Nothing queued.</p>
        ) : (
          <ul className="mt-2 space-y-2">
            {snap.crew.tasks.map((task) => (
              <li key={task.label} className="rounded-lg bg-panel-2 px-3 py-2">
                <div className="flex items-baseline justify-between gap-3">
                  <p className="font-medium">{task.label}</p>
                  <p className="tabular-nums text-muted">{task.pct}%</p>
                </div>
                <p className="text-muted">{task.who}</p>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-panel">
                  <div className="h-full bg-accent" style={{ width: `${task.pct}%` }} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section className="space-y-2 border-t border-line pt-3">
        <h3 className="text-xs font-semibold tracking-wide text-muted">Lot</h3>
        <div className="flex flex-wrap gap-2">
          <Btn tone="ghost" onClick={() => toggleInterior()}>
            {snap.interiorOpen ? "Close the indoor roof" : "Open the indoor roof"}
          </Btn>
          <Btn tone="ghost" onClick={armReset}>
            {snap.resetArmed ? "Confirm reset to opening day" : "Reset Maple Street"}
          </Btn>
        </div>
      </section>
    </div>
  )
}
