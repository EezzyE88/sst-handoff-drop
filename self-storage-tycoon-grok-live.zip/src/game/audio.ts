import type { World } from "@/game/types"

type Cue = "confirm" | "gate" | "cart" | "door" | "work" | "lift" | "rent" | "done" | "warn" | "foot" | "engine"

let ctx: AudioContext | null = null
let master: GainNode | null = null
let bedGain: GainNode | null = null
let air: BiquadFilterNode | null = null
let pad: OscillatorNode | null = null
let fifth: OscillatorNode | null = null
let noise: AudioBuffer | null = null
let unlocked = false
let prev: string | null = null
let last: Partial<Record<Cue, number>> = {}

function context(): AudioContext | null {
  if (!unlocked) return null
  if (!ctx) {
    try {
      const Ctx = window.AudioContext
      ctx = new Ctx()
    } catch {
      return null
    }
    master = ctx.createGain()
    master.gain.value = 0
    master.connect(ctx.destination)
    const len = ctx.sampleRate * 1
    noise = ctx.createBuffer(1, len, ctx.sampleRate)
    const data = noise.getChannelData(0)
    let v = 0
    for (let i = 0; i < len; i++) {
      v = v * 0.96 + (Math.random() * 2 - 1) * 0.04
      data[i] = v * 4
    }
  }
  if (ctx.state === "suspended") void ctx.resume()
  return ctx
}

export function unlockAudio() {
  unlocked = true
  context()
}

function allowed(kind: Cue, gap: number) {
  const audio = context()
  if (!audio) return false
  const now = audio.currentTime
  if ((last[kind] ?? 0) + gap > now) return false
  last[kind] = now
  return true
}

function tone(freq: number, dur: number, gain: number, type: OscillatorType = "sine") {
  const audio = context()
  if (!audio || !master) return
  const o = audio.createOscillator()
  const g = audio.createGain()
  o.type = type
  o.frequency.value = freq
  g.gain.setValueAtTime(gain, audio.currentTime)
  g.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + dur)
  o.connect(g)
  g.connect(master)
  o.start()
  o.stop(audio.currentTime + dur + 0.02)
}

function rustle(dur: number, gain: number, freq: number) {
  const audio = context()
  if (!audio || !master || !noise) return
  const src = audio.createBufferSource()
  src.buffer = noise
  src.loop = true
  const filter = audio.createBiquadFilter()
  filter.type = "bandpass"
  filter.frequency.value = freq
  filter.Q.value = 0.7
  const g = audio.createGain()
  g.gain.setValueAtTime(gain, audio.currentTime)
  g.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + dur)
  src.connect(filter)
  filter.connect(g)
  g.connect(master)
  src.start()
  src.stop(audio.currentTime + dur + 0.02)
}

function play(kind: Cue) {
  if (kind === "confirm" && allowed(kind, 0.2)) tone(494, 0.12, 0.04)
  else if (kind === "gate" && allowed(kind, 0.8)) {
    tone(180, 0.09, 0.03, "triangle")
    tone(420, 0.14, 0.02, "triangle")
  } else if (kind === "cart" && allowed(kind, 0.55)) rustle(0.18, 0.05, 900)
  else if (kind === "door" && allowed(kind, 0.4)) rustle(0.22, 0.04, 1400)
  else if (kind === "work" && allowed(kind, 0.7)) rustle(0.16, 0.035, 600)
  else if (kind === "lift" && allowed(kind, 1.4)) tone(96, 0.25, 0.02, "triangle")
  else if (kind === "rent" && allowed(kind, 2)) tone(330, 0.2, 0.03)
  else if (kind === "done" && allowed(kind, 0.8)) {
    tone(392, 0.12, 0.03)
    tone(523, 0.18, 0.025)
  } else if (kind === "warn" && allowed(kind, 3)) tone(196, 0.22, 0.028, "triangle")
  else if (kind === "foot" && allowed(kind, 0.42)) rustle(0.08, 0.02, 220)
  else if (kind === "engine" && allowed(kind, 1.1)) tone(72, 0.18, 0.015, "triangle")
}

function stamp(w: World) {
  const hour = Math.floor((w.day % 1) * 24)
  const doors = w.units.map((u) => Math.round(u.doorOpen * 4)).join("")
  const carts = w.carts.map((c) => c.phase[0]).join("")
  const work = w.tasks.map((t) => Math.floor(t.done)).join(",")
  return [
    hour,
    w.speed,
    w.gate > 0.6 ? 1 : 0,
    0,
    doors,
    carts,
    work,
    Math.round(w.cash),
    w.lightFault ? 1 : 0,
    w.cameraFault ? 1 : 0,
    w.keypadFault ? 1 : 0,
    w.hallDark ? 1 : 0,
    w.cab > 0.5 ? 1 : 0,
    w.visit?.stage ?? -1,
  ].join("|")
}

function bed(w: World) {
  const audio = context()
  if (!audio || !master || !noise) return
  if (!bedGain) {
    bedGain = audio.createGain()
    bedGain.gain.value = 0
    const src = audio.createBufferSource()
    src.buffer = noise
    src.loop = true
    const filter = audio.createBiquadFilter()
    filter.type = "lowpass"
    filter.frequency.value = 420
    air = filter
    src.connect(filter)
    filter.connect(bedGain)
    pad = audio.createOscillator()
    pad.type = "sine"
    pad.frequency.value = 110
    const padGain = audio.createGain()
    padGain.gain.value = 0.12
    pad.connect(padGain)
    padGain.connect(bedGain)
    fifth = audio.createOscillator()
    fifth.type = "sine"
    fifth.frequency.value = 165
    const fifthGain = audio.createGain()
    fifthGain.gain.value = 0.05
    fifth.connect(fifthGain)
    fifthGain.connect(bedGain)
    bedGain.connect(master)
    src.start()
    pad.start()
    fifth.start()
  }
  const hour = Math.floor((w.day % 1) * 24)
  const night = hour >= 19 || hour < 6
  const inside = w.roof > 0.5
  const moving = w.speed > 0
  const level = moving ? (night ? 0.014 : 0.02) * (inside ? 0.6 : 1) : 0.004
  bedGain.gain.setTargetAtTime(level, audio.currentTime, 0.5)
  air?.frequency.setTargetAtTime(night ? 260 : 480, audio.currentTime, 0.8)
  const chords = [98, 110, 123, 87]
  const note = chords[Math.floor(w.day * 6) % chords.length] ?? 110
  pad?.frequency.setTargetAtTime(note, audio.currentTime, 1.4)
  fifth?.frequency.setTargetAtTime(note * 1.5, audio.currentTime, 1.4)
}

function live(w: World) {
  if (w.speed <= 0) return
  if (w.carts.some((c) => c.phase === "follow" || c.phase === "return")) play("cart")
  if (w.movers.some((m) => m.visible && m.kind !== "car" && m.path.length > 0)) play("foot")
  if (w.movers.some((m) => m.visible && m.kind === "car" && m.path.length > 0)) play("engine")
}

export function setHeard(on: boolean) {
  if (on) {
    unlockAudio()
    const audio = context()
    if (audio && master) master.gain.setTargetAtTime(0.9, audio.currentTime, 0.05)
    play("confirm")
    return
  }
  if (ctx && master) master.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.05)
  prev = null
}

export function syncAudio(w: World) {
  if (!w.sound || !unlocked) {
    prev = stamp(w)
    return
  }
  const audio = context()
  if (!audio || !master) return
  if (master.gain.value < 0.2) master.gain.setTargetAtTime(0.9, audio.currentTime, 0.05)
  const next = stamp(w)
  if (prev && prev !== next) {
    const a = prev.split("|")
    const b = next.split("|")
    if (a[2] === "0" && b[2] === "1") play("gate")
    if (a[4] !== b[4]) play("door")
    if (a[5] !== b[5] && /[fr]/.test(b[5] ?? "")) play("cart")
    if (a[6] !== b[6]) play("work")
    if (Number(b[7]) > Number(a[7]) + 40) play("rent")
    if (a[8] !== b[8] || a[9] !== b[9] || a[10] !== b[10] || a[11] !== b[11]) {
      if (b[8] === "1" || b[9] === "1" || b[10] === "1" || b[11] === "1") play("warn")
    }
    if (a[12] !== b[12] && w.upperOpen) play("lift")
    if (a[6] !== b[6] && w.tasks.some((t) => t.done >= t.work && t.work > 0)) play("done")
  }
  prev = next
  bed(w)
  live(w)
}
