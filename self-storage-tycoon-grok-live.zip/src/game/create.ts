import { HOME, LAYOUT as L } from "@/game/layout"
import { MARKET } from "@/game/economy"
import type { Cart, Mover, Pad, Unit, World } from "@/game/types"

const NAMES = ["J. Okonkwo", "S. Patel", "R. Nguyen", "L. Brooks", "A. Chen", "D. Alvarez", "M. Ruiz", "K. Walsh"]

function mover(partial: Mover): Mover {
  return partial
}

function driveUnit(
  i: number,
  number: string,
  status: Unit["status"],
  lease: number | null,
  tenant: string | null,
  note: string | null,
): Unit {
  return {
    id: `u${number}`,
    number,
    product: "5x10",
    access: "drive-up",
    x: L.driveOriginX + i * L.drivePitch,
    y: L.driveY,
    w: L.driveW,
    d: L.driveD,
    h: 7.2,
    door: "s",
    status,
    lease,
    tenant,
    note,
    group: null,
    padId: null,
    buildCost: 0,
    progress: status === "makeReady" ? 0 : 1,
    doorOpen: 0,
    climate: false,
    floor: 1,
    z: 0,
    rentDue: status === "occupied" ? 30 : undefined,
  }
}

function interiorUnit(
  number: string,
  product: Unit["product"],
  x: number,
  w: number,
  lease: number,
  tenant: string,
): Unit {
  return {
    id: `u${number}`,
    number,
    product,
    access: "interior",
    x,
    y: 30,
    w,
    d: 12,
    h: 6.4,
    door: "s",
    status: "occupied",
    lease,
    tenant,
    note: null,
    group: null,
    padId: null,
    buildCost: 0,
    progress: 1,
    doorOpen: 0,
    climate: false,
    floor: 1,
    z: 0,
    rentDue: 30,
  }
}

export function emptyLot(w: World) {
  w.lot = "empty"
  w.units = w.units.filter((u) => u.site === "cedar")
  for (let i = 0; i < 8; i++) {
    const id = `drive${i}`
    if (w.pads.some((p) => p.id === id)) continue
    w.pads.push({
      id,
      index: 100 + i,
      x: L.driveOriginX + i * L.drivePitch,
      y: L.driveY,
      w: L.driveW,
      d: L.driveD,
    })
  }
}

export function createWorld(): World {
  const units: Unit[] = [
    driveUnit(0, "101", "occupied", 142, NAMES[0], null),
    driveUnit(1, "102", "occupied", 150, NAMES[1], null),
    driveUnit(2, "103", "occupied", 138, NAMES[2], null),
    driveUnit(3, "104", "occupied", 155, NAMES[3], null),
    driveUnit(4, "105", "occupied", 146, NAMES[4], null),
    driveUnit(5, "106", "occupied", 149, NAMES[5], null),
    driveUnit(6, "107", "makeReady", null, null, "Last tenant moved out yesterday"),
    driveUnit(7, "108", "occupied", 158, NAMES[6], null),
  ]

  const interiors: { n: string; product: Unit["product"]; w: number; lease: number; tenant: string }[] = [
    { n: "201", product: "5x10", w: 5.2, lease: 126, tenant: "P. Shah" },
    { n: "202", product: "5x10", w: 5.2, lease: 132, tenant: "C. Berg" },
    { n: "203", product: "5x10", w: 5.2, lease: 120, tenant: "H. Ito" },
    { n: "204", product: "5x10", w: 5.2, lease: 129, tenant: "N. Cole" },
    { n: "205", product: "10x10", w: 10, lease: 210, tenant: "F. Mendes" },
    { n: "206", product: "10x10", w: 10, lease: 225, tenant: "B. Adler" },
  ]
  let ix = 96
  for (const spec of interiors) {
    units.push(interiorUnit(spec.n, spec.product, ix, spec.w, spec.lease, spec.tenant))
    ix += spec.w + 0.45
  }

  const pads: Pad[] = []
  for (let i = 0; i < 6; i++) {
    pads.push({
      id: `pad${i}`,
      index: i,
      x: L.expOriginX + i * L.expPitch,
      y: L.expY,
      w: L.expW,
      d: L.expD,
    })
  }

  const carts: Cart[] = [0, 1, 2].map((i) => ({
    id: `cart${i}`,
    x: L.corral.x + 1.6 + i * 3.2,
    y: L.corral.y + 3.2,
    homeX: L.corral.x + 1.6 + i * 3.2,
    homeY: L.corral.y + 3.2,
    phase: "home" as const,
  }))

  const movers: Mover[] = [
    mover({
      id: "owner",
      kind: "person",
      role: "owner",
      x: HOME.owner.x,
      y: HOME.owner.y,
      path: [],
      speed: 15,
      fill: "#1e3a4c",
      wait: 0,
      visible: true,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    }),
    mover({
      id: "porter",
      kind: "person",
      role: "porter",
      x: HOME.porter.x,
      y: HOME.porter.y,
      path: [],
      speed: 16,
      fill: "#8a5a12",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    }),
    mover({
      id: "tech",
      kind: "person",
      role: "tech",
      x: HOME.tech.x,
      y: HOME.tech.y,
      path: [],
      speed: 15,
      fill: "#1f6f78",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    }),
    mover({
      id: "tech2",
      kind: "person",
      role: "tech2",
      x: HOME.tech2.x,
      y: HOME.tech2.y,
      path: [],
      speed: 15,
      fill: "#2a8a78",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    }),
    mover({
      id: "manager",
      kind: "person",
      role: "manager",
      x: HOME.manager.x,
      y: HOME.manager.y,
      path: [],
      speed: 12,
      fill: "#5c4a32",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    }),
    mover({
      id: "vcar",
      kind: "car",
      role: "customer",
      x: -8,
      y: 5,
      path: [],
      speed: 30,
      fill: "#d9d3c7",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: "sedan",
    }),
    mover({
      id: "vperson",
      kind: "person",
      role: "customer",
      x: 80,
      y: 30,
      path: [],
      speed: 13,
      fill: "#8e3d32",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    }),
    mover({
      id: "crew0",
      kind: "crew",
      role: "crew",
      x: 0,
      y: 0,
      path: [],
      speed: 0,
      fill: "#5c6b73",
      wait: 0,
      visible: false,
      facing: "y",
      working: true,
      heldCart: false,
      vehicle: null,
    }),
    mover({
      id: "crew1",
      kind: "crew",
      role: "crew",
      x: 0,
      y: 0,
      path: [],
      speed: 0,
      fill: "#3e4a52",
      wait: 0,
      visible: false,
      facing: "y",
      working: true,
      heldCart: false,
      vehicle: null,
    }),
  ]

  return {
    version: 2,
    speed: 0,
    day: 18 + 8 / 24,
    billedThrough: 18,
    daysToRent: 12,
    rentAge: 18,
    cash: 22400,
    prices: { ...MARKET },
    units,
    pads,
    tasks: [],
    movers,
    carts,
    visit: null,
    prospect: null,
    nextInterior: 9,
    lightFault: false,
    porter: false,
    camera: false,
    cameraFault: false,
    securedAt: 0,
    keypad: false,
    looseAt: 0,
    hallDark: false,
    hallAt: 0,
    keypadFault: false,
    keypadAt: 0,
    cartNote: false,
    cartPace: 0,
    dock: 0,
    hvac: "none",
    hvacProgress: 0,
    floor2: "none",
    elevator: "none",
    floorProgress: 0,
    elevatorProgress: 0,
    upperOpen: false,
    cabs: 1,
    secondCab: "none",
    secondProgress: 0,
    queueSeen: false,
    view: "maple",
    cedarWait: 0,
    cedarPassId: null,
    elevatorQueue: 0,
    cab: 0,
    elevWear: "good",
    wearAt: 0,
    upperAt: 0,
    tech: false,
    tech2: false,
    energy: 3,
    energyDay: 18,
    issueDay: 0,
    dayLeases: 0,
    dayPasses: 0,
    dayNote: "",
    steadyAt: 0,
    goalCash: 0,
    quarterTold: "",
    passes: 0,
    took: 0,
    passesSince: 0,
    tookSince: 0,
    priceNote: "",
    unmet: "",
    unmetAt: 0,
    misses: {},
    lastPass: "",
    expandLock: "",
    expandUntil: 0,
    ledger: [],
    priority: "equipment",
    servicePlan: false,
    turnoverAt: 0,
    turnoverId: null,
    delinquentAt: 0,
    lateId: "",
    lateUntil: 0,
    officeAt: 0,
    officeSeen: "",
    reviewSeen: false,
    heldRow: false,
    ledgerSeen: false,
    manager: false,
    managerSeen: false,
    managerAlert: null,
    gate: 0,
    roof: 0,
    roofHold: false,
    welcome: true,
    slot: "business",
    play: "business",
    lot: "starter",
    difficulty: "standard",
    demand: "normal",
    costs: "normal",
    upkeep: "normal",
    goal: "",
    goalMet: false,
    goalDay: 0,
    sandbox: false,
    openedCash: 22400,
    instant: false,
    injected: 0,
    sheet: "none",
    selectedId: null,
    buildPick: [],
    groupSeq: 1,
    milestones: {
      inspected107: false,
      makeReadyStarted: false,
      rentReady: false,
      leased: false,
      commissioned: false,
      cartSeen: false,
      repaired: false,
      hired: false,
      secured: false,
      cameraServiced: false,
      cartRecovered: false,
      hallLit: false,
      keypadServiced: false,
      climate: false,
      upper: false,
      serviced: false,
      turnover: false,
      turned: false,
      cycled: false,
      graduated: false,
    },
    sound: false,
    toast: null,
    toastTtl: 0,
    lastRent: 1980,
    constructionSpend: 0,
    rng: 20260518,
  }
}

export function ensureTech(movers: Mover[], hired: boolean) {
  let tech = movers.find((m) => m.id === "tech")
  if (!tech) {
    tech = mover({
      id: "tech",
      kind: "person",
      role: "tech",
      x: HOME.tech.x,
      y: HOME.tech.y,
      path: [],
      speed: 15,
      fill: "#1f6f78",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    })
    movers.push(tech)
  }
  tech.role = "tech"
  if (!tech.path) tech.path = []
  tech.visible = hired
}

export function ensureTech2(movers: Mover[], hired: boolean) {
  let tech = movers.find((m) => m.id === "tech2")
  if (!tech) {
    tech = mover({
      id: "tech2",
      kind: "person",
      role: "tech2",
      x: HOME.tech2.x,
      y: HOME.tech2.y,
      path: [],
      speed: 15,
      fill: "#2a8a78",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    })
    movers.push(tech)
  }
  tech.role = "tech2"
  if (!tech.path) tech.path = []
  tech.visible = hired
}

export function ensureManager(movers: Mover[], hired: boolean) {
  let manager = movers.find((m) => m.id === "manager")
  if (!manager) {
    manager = mover({
      id: "manager",
      kind: "person",
      role: "manager",
      x: HOME.manager.x,
      y: HOME.manager.y,
      path: [],
      speed: 12,
      fill: "#5c4a32",
      wait: 0,
      visible: false,
      facing: "y",
      working: false,
      heldCart: false,
      vehicle: null,
    })
    movers.push(manager)
  }
  manager.role = "manager"
  if (!manager.path) manager.path = []
  manager.visible = hired
}

export function makeCedar(): Unit[] {
  const rows: { number: string; status: Unit["status"]; lease: number | null; tenant: string | null; ask: number | null; note: string }[] = [
    { number: "C1", status: "occupied", lease: 140, tenant: "P. Ortiz", ask: null, note: "Drive-up on Cedar Court." },
    { number: "C2", status: "occupied", lease: 135, tenant: "N. Shah", ask: null, note: "Drive-up on Cedar Court." },
    { number: "C3", status: "occupied", lease: 150, tenant: "E. Grant", ask: null, note: "Drive-up on Cedar Court." },
    { number: "C4", status: "makeReady", lease: null, tenant: null, ask: 140, note: "Vacant at purchase. The site lead is sweeping it." },
  ]
  return rows.map((row, i) => ({
    id: `u${row.number}`,
    number: row.number,
    product: "5x10",
    access: "drive-up",
    x: 12 + i * 9,
    y: 22,
    w: 7.2,
    d: 14,
    h: 7.2,
    door: "s",
    status: row.status,
    lease: row.lease,
    tenant: row.tenant,
    note: row.note,
    group: null,
    padId: null,
    buildCost: 0,
    progress: row.status === "makeReady" ? 0 : 1,
    doorOpen: 0,
    climate: false,
    floor: 1,
    z: 0,
    site: "cedar",
    ask: row.ask,
  }))
}
