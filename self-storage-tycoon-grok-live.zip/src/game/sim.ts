import { DAY_SECONDS, PLAN_PARTS, SERVICE_PARTS, dailyCost, energyMax, isPass, marketFor, money, moneyCents, rentRoll, responseWait, siteStrain } from "@/game/economy"
import { CAR_NODES, EDGES, HOME, LAYOUT, NODES, PERSON_NODES, type NodeId } from "@/game/layout"
import { createWorld } from "@/game/create"
import type { Mover, ProductKey, StaffRole, Task, Unit, Visit, World } from "@/game/types"
import { productKey } from "@/game/types"

const NAMES = ["J. Okonkwo", "T. Singh", "R. Nguyen", "L. Brooks", "A. Vasquez", "C. Holm", "P. Ibrahim", "S. Keller"]

function rand(w: World): number {
  w.rng = (Math.imul(w.rng, 1664525) + 1013904223) >>> 0
  return w.rng / 4294967296
}

function pickName(w: World): string {
  return NAMES[Math.floor(rand(w) * NAMES.length)] ?? "A. Guest"
}

export function findUnit(w: World, id: string | null): Unit | undefined {
  if (!id) return undefined
  return w.units.find((u) => u.id === id)
}

export function moverBy(w: World, id: string): Mover | undefined {
  return w.movers.find((m) => m.id === id)
}

export function doorPoint(u: Unit): { x: number; y: number } {
  const cx = u.x + u.w / 2
  const cy = u.y + u.d / 2
  if (u.door === "s") return { x: cx, y: u.y + u.d + 1.5 }
  if (u.door === "n") return { x: cx, y: u.y - 1.5 }
  if (u.door === "e") return { x: u.x + u.w + 1.5, y: cy }
  return { x: u.x - 1.5, y: cy }
}

function nearest(ids: NodeId[], p: { x: number; y: number }): NodeId {
  let best: NodeId = ids[0] ?? "office"
  let score = Infinity
  for (const id of ids) {
    const n = NODES[id]
    const d = (n.x - p.x) ** 2 + (n.y - p.y) ** 2
    if (d < score) {
      score = d
      best = id
    }
  }
  return best
}

function bfs(start: NodeId, goal: NodeId, allow: Set<NodeId>): NodeId[] {
  if (start === goal) return [start]
  const q: NodeId[] = [start]
  const prev = new Map<NodeId, NodeId | null>([[start, null]])
  while (q.length) {
    const cur = q.shift()!
    for (const [a, b] of EDGES) {
      const nxt = a === cur ? b : b === cur ? a : null
      if (!nxt || !allow.has(nxt) || prev.has(nxt)) continue
      prev.set(nxt, cur)
      if (nxt === goal) {
        const path: NodeId[] = [nxt]
        let walk: NodeId | null = cur
        while (walk) {
          path.push(walk)
          walk = prev.get(walk) ?? null
        }
        path.reverse()
        return path
      }
      q.push(nxt)
    }
  }
  return [start]
}

export function route(from: { x: number; y: number }, to: { x: number; y: number }, nodes: NodeId[]): { x: number; y: number }[] {
  const allow = new Set(nodes)
  const start = nearest(nodes, from)
  const goal = nearest(nodes, to)
  const ids = bfs(start, goal, allow)
  const pts: { x: number; y: number }[] = ids.map((id) => ({ x: NODES[id].x, y: NODES[id].y }))
  pts.push({ x: to.x, y: to.y })
  if (pts.length && Math.hypot(pts[0]!.x - from.x, pts[0]!.y - from.y) < 0.4) pts.shift()
  return pts
}

function advance(m: Mover, dt: number) {
  if (m.wait > 0) {
    m.wait = Math.max(0, m.wait - dt)
    return
  }
  const target = m.path[0]
  if (!target) return
  const dx = target.x - m.x
  const dy = target.y - m.y
  const len = Math.hypot(dx, dy)
  if (len < 0.35) {
    m.x = target.x
    m.y = target.y
    m.path.shift()
    return
  }
  const step = Math.min(len, m.speed * dt)
  m.x += (dx / len) * step
  m.y += (dy / len) * step
  m.facing = Math.abs(dx) > Math.abs(dy) ? "x" : "y"
}

function cabBlocked(w: World) {
  return w.elevWear === "down" && w.cabs < 2
}

function isMaple(u: { site?: "maple" | "cedar" }) {
  return u.site !== "cedar"
}

function toast(w: World, text: string) {
  w.toast = text
  w.toastTtl = 3.6
}

function taskDest(w: World, task: Task): { x: number; y: number } {
  if (task.kind === "recover") {
    const cart = w.carts.find((c) => c.phase === "stray")
    return cart ? { x: cart.x, y: cart.y } : { x: 78, y: 40 }
  }
  if (task.targetId === "hall") return { x: LAYOUT.hall.x + 8, y: LAYOUT.hall.y + 4 }
  if (task.targetId === "keypad") return { x: 30, y: 15.5 }
  if (task.targetId === "camera") return { x: 30, y: 16 }
  if (task.kind === "service") return { x: 86, y: 52 }
  if (task.kind === "repair") return { x: LAYOUT.light.x, y: LAYOUT.light.y + 2.5 }
  const unit = findUnit(w, task.targetId)
  return unit ? doorPoint(unit) : HOME.owner
}

function finishTask(w: World, task: Task) {
  w.tasks = w.tasks.filter((t) => t.id !== task.id)
  const who = task.assignee ? moverBy(w, task.assignee) : undefined
  if (who) who.working = false
  if (task.kind === "makeReady") {
    const unit = findUnit(w, task.targetId)
    if (unit) {
      unit.status = "rentReady"
      unit.tenant = null
      unit.lease = null
      clearMiss(w, unit)
    }
    w.milestones.rentReady = true
    if (unit && unit.number !== "107") {
      if (!w.milestones.turned) {
        w.milestones.turned = true
        w.turnoverAt = w.day
      } else if (!w.milestones.cycled) {
        w.milestones.cycled = true
        maybeGraduate(w)
      }
    }
    toast(w, `Unit ${unit?.number ?? ""} is rent-ready.`)
    return
  }
  if (task.kind === "service") {
    const failed = w.elevWear === "down"
    const bill = failed ? SERVICE_PARTS : PLAN_PARTS
    w.elevWear = "good"
    w.upperAt = w.day
    w.milestones.serviced = true
    w.cash -= bill
    refreshProspect(w)
    toast(
      w,
      failed
        ? `Elevator serviced after it stopped. Parts ${money(bill)}.`
        : `Elevator serviced before it failed. Parts ${money(bill)}.`,
    )
    return
  }
  if (task.kind === "recover") {
    const cart = w.carts.find((c) => c.phase === "stray")
    if (cart) cart.phase = "return"
    w.milestones.cartRecovered = true
    toast(w, "Cart is back in the corral.")
    return
  }
  if (task.targetId === "hall") {
    w.hallDark = false
    w.milestones.hallLit = true
    toast(w, "Hall light is back. The indoor hallway is lit.")
    return
  }
  if (task.targetId === "keypad") {
    w.keypadFault = false
    w.milestones.keypadServiced = true
    toast(w, "Keypad is clear. The gate arm can rise all the way.")
    return
  }
  if (task.targetId === "camera") {
    w.cameraFault = false
    w.milestones.cameraServiced = true
    toast(w, "Gate camera is back. The apron is covered again.")
    return
  }
  w.lightFault = false
  w.milestones.repaired = true
  toast(w, "Gate light is back on.")
}

function techJob(task: Task) {
  return task.kind === "service" || task.targetId === "camera" || task.targetId === "hall" || task.targetId === "keypad"
}

function canTake(w: World, role: StaffRole, task: Task): boolean {
  if (task.kind === "recover") return role === "owner" || role === "porter"
  if (role === "porter") return task.kind === "makeReady" || (task.kind === "repair" && !techJob(task))
  if (role === "tech" || role === "tech2") return techJob(task) || (task.kind === "repair" && task.targetId === "light")
  if (techJob(task) && (w.tech || w.tech2)) return false
  return true
}

function taskRank(w: World, task: Task): number {
  const equipment = task.kind === "service" || task.kind === "repair"
  if (w.priority === "equipment") return equipment ? 0 : 1
  return equipment ? 1 : 0
}

function assignOpen(w: World) {
  const roles: StaffRole[] = []
  if (w.tech) roles.push("tech")
  if (w.tech2) roles.push("tech2")
  if (w.porter) roles.push("porter")
  roles.push("owner")
  const visible = roles.filter((role) => moverBy(w, role)?.visible)
  let guard = 0
  while (w.energy > 0 && guard++ < 12) {
    const open = w.tasks.filter((t) => t.assignee === null)
    let picked: { task: Task; role: StaffRole; depth: number; rank: number; at: number } | null = null
    for (let at = 0; at < open.length; at++) {
      const task = open[at]
      for (const role of visible) {
        if (!canTake(w, role, task)) continue
        const depth = w.tasks.filter((t) => t.assignee === role).length
        const rank = taskRank(w, task)
        if (
          !picked ||
          rank < picked.rank ||
          (rank === picked.rank && depth < picked.depth) ||
          (rank === picked.rank && depth === picked.depth && at < picked.at)
        ) {
          picked = { task, role, depth, rank, at }
        }
      }
    }
    if (!picked) break
    w.energy -= 1
    picked.task.assignee = picked.role
    if (w.energy === 0 && w.tasks.some((t) => t.assignee === null)) {
      toast(w, "The rest of the queue waits until morning.")
    }
  }
}

function tickWorkers(w: World, dt: number) {
  assignOpen(w)
  const roles: StaffRole[] = []
  if (w.tech) roles.push("tech")
  if (w.tech2) roles.push("tech2")
  if (w.porter) roles.push("porter")
  roles.push("owner")
  for (const role of roles) {
    const m = moverBy(w, role)
    if (!m || !m.visible) continue
    const task = w.tasks.find((t) => t.assignee === role)
    if (!task) {
      m.working = false
      if (m.path.length === 0) {
        const home = HOME[role]
        if (Math.hypot(m.x - home.x, m.y - home.y) > 1.3) m.path = route(m, home, PERSON_NODES)
      }
      advance(m, dt)
      continue
    }
    const dest = taskDest(w, task)
    const near = m.path.length === 0 && Math.hypot(m.x - dest.x, m.y - dest.y) < 1.8
    if (!near && m.path.length === 0) m.path = route(m, dest, PERSON_NODES)
    advance(m, dt)
    const arrived = m.path.length === 0 && Math.hypot(m.x - dest.x, m.y - dest.y) < 1.8
    m.working = arrived
    if (arrived) {
      task.done += dt
      if (task.done >= task.work) finishTask(w, task)
    }
  }
}

function tickHvac(w: World, dt: number) {
  if (w.hvac !== "building" || w.hvacProgress >= 1) return
  const before = w.hvacProgress
  w.hvacProgress = Math.min(1, w.hvacProgress + dt / 14)
  if (before < 1 && w.hvacProgress >= 1) {
    toast(w, "HVAC plant is in. Commission it before the climate rate applies.")
  }
}

function tickVertical(w: World, dt: number) {
  if (w.floor2 === "building" && w.floorProgress < 1) {
    const before = w.floorProgress
    w.floorProgress = Math.min(1, w.floorProgress + dt / 18)
    if (before < 1 && w.floorProgress >= 1) {
      w.floor2 = "built"
      toast(w, w.elevator === "built" ? "Second floor is in. Open it when you are ready." : "Second floor is built. It still needs an elevator.")
    }
  }
  if (w.elevator === "building" && w.elevatorProgress < 1) {
    const before = w.elevatorProgress
    w.elevatorProgress = Math.min(1, w.elevatorProgress + dt / 12)
    if (before < 1 && w.elevatorProgress >= 1) {
      w.elevator = "built"
      toast(w, w.floor2 === "built" ? "Elevator is in. Open floor 2 when you are ready." : "Elevator is in. It needs a second floor.")
    }
  }
  if (w.secondCab === "building" && w.secondProgress < 1) {
    const before = w.secondProgress
    w.secondProgress = Math.min(1, w.secondProgress + dt / 14)
    if (before < 1 && w.secondProgress >= 1) {
      w.secondCab = "built"
      w.cabs = 2
      toast(w, "Second cab is in. It did not add units. If one cab fails, the other still runs.")
    }
  }
  if (w.elevatorQueue > 0.3) w.queueSeen = true
  if (w.elevatorQueue > 0 && !cabBlocked(w)) {
    const rate = w.cabs >= 2 ? (w.elevWear === "down" ? 0.65 : w.elevWear === "due" ? 0.9 : 1.8) : w.elevWear === "due" ? 0.4 : 1
    w.elevatorQueue = Math.max(0, w.elevatorQueue - dt * rate)
  }
}

function queueServiceTask(w: World): boolean {
  if (w.tasks.some((t) => t.kind === "service")) return false
  w.tasks.push({
    id: "task-elev",
    kind: "service",
    targetId: "elevator",
    label: "Service the elevator",
    work: 2.8,
    done: 0,
    assignee: null,
  })
  assignOpen(w)
  return true
}

function tickWear(w: World) {
  if (!w.upperOpen || w.elevator !== "built") return
  if (!w.upperAt) w.upperAt = w.day
  const servicing = w.tasks.some((t) => t.kind === "service")
  if (w.elevWear === "good") {
    if (w.upkeep === "off") return
    const gap = !w.milestones.serviced ? (w.upkeep === "often" ? 0.35 : 0.7) : w.servicePlan ? 12 : w.upkeep === "often" ? 2.2 : 4.5
    if (w.day < w.upperAt + gap) return
    w.elevWear = "due"
    w.wearAt = w.day
    if (w.servicePlan && queueServiceTask(w)) toast(w, "Service plan queued the elevator before it failed.")
    else toast(w, "The elevator is due for service.")
    return
  }
  if (w.elevWear === "due" && w.servicePlan && !servicing && queueServiceTask(w)) {
    toast(w, "Service plan queued the elevator before it failed.")
    return
  }
  if (w.elevWear === "due" && !w.servicePlan && !servicing && w.day >= w.wearAt + 0.65) {
    w.elevWear = "down"
    refreshProspect(w)
    toast(
      w,
      w.cabs >= 2
        ? "One cab is down. The second cab is still taking carts. Service the failed one."
        : "The elevator is down. Carts cannot reach floor 2 until it is serviced.",
    )
  }
}

function beginMoveout(w: World, victim: Unit) {
  w.visit = {
    kind: "moveout",
    stage: -1,
    wait: 0,
    unitId: victim.id,
    name: victim.tenant ?? "Tenant",
    cartId: null,
    since: w.day,
  }
  if (!w.milestones.turnover) {
    w.milestones.turnover = true
    w.turnoverId = victim.id
    w.turnoverAt = w.day
  }
  enterStage(w, 0)
  toast(w, `${victim.tenant ?? "A tenant"} is moving out of unit ${victim.number}.`)
}

function tickFirstTurnover(w: World) {
  if (
    w.milestones.turnover &&
    !w.milestones.turned &&
    !w.visit &&
    !w.units.some((u) => isMaple(u) && u.status === "makeReady") &&
    w.day > w.turnoverAt + 1.5
  ) {
    w.milestones.turnover = false
  }
  if (w.milestones.turnover || !w.upperOpen) return
  if (w.visit) return
  if (w.elevWear === "good" && w.day < (w.upperAt || 0) + 1.4) return
  const victim = w.units.find(
    (u) =>
      isMaple(u) &&
      u.access === "drive-up" &&
      u.status === "occupied" &&
      u.number !== "107" &&
      w.prospect?.unitId !== u.id,
  )
  if (!victim) return
  beginMoveout(w, victim)
}

function tickTurnover(w: World) {
  if (!w.milestones.turned || w.milestones.cycled) return
  if (cabBlocked(w)) return
  if (w.visit) return
  if (w.units.some((u) => isMaple(u) && u.status === "makeReady")) return
  if (w.day < w.turnoverAt + 0.85) return
  const victim = w.units.find(
    (u) =>
      isMaple(u) &&
      u.access === "drive-up" &&
      u.status === "occupied" &&
      u.number !== "107" &&
      u.id !== w.turnoverId &&
      w.prospect?.unitId !== u.id,
  )
  if (!victim) return
  beginMoveout(w, victim)
}

function vacate(w: World, unit: Unit, paid: boolean) {
  const lease = unit.lease ?? 0
  const name = unit.tenant ?? "The tenant"
  const number = unit.number
  unit.behind = false
  unit.locked = false
  w.lateId = unit.id
  w.lateUntil = w.day + 18
  if (paid) {
    const missed = unit.owed && unit.owed > 0 ? unit.owed : lease
    w.cash += missed + 35
    unit.owed = 0
    unit.rentDue = Math.floor(w.day) + 30
    pushLedger(w, `Unit ${number} paid ${money(missed)} plus a $35 late fee.`, missed + 35)
    toast(w, `${name} paid unit ${number}, plus a $35 late fee.`)
    return
  }
  const written = unit.owed && unit.owed > 0 ? unit.owed : lease
  unit.status = "makeReady"
  unit.tenant = null
  unit.lease = null
  unit.rentDue = undefined
  unit.owed = 0
  unit.progress = 0
  unit.note = "Left without paying. Needs a sweep before it can rent again."
  pushLedger(w, `Unit ${number} left. ${money(written)} written off. Not cash.`, 0)
  toast(w, `${name} left unit ${number} without paying. ${money(written)} is written off. It needs a sweep.`)
}

function tickDelinquentMark(w: World) {
  if (w.units.some((u) => u.behind && u.status === "occupied")) return
  if (!w.milestones.turned) return
  if (w.units.some((u) => isMaple(u) && u.status === "makeReady")) return
  if (!w.delinquentAt) {
    w.delinquentAt = w.day + 1.15
    return
  }
  if (w.day < w.delinquentAt) return
  const moving = w.visit?.kind === "moveout" ? w.visit.unitId : null
  const unit = w.units.find(
    (u) =>
      isMaple(u) &&
      u.status === "occupied" &&
      u.access === "drive-up" &&
      u.number !== "107" &&
      u.id !== w.turnoverId &&
      u.id !== moving &&
      !(u.id === w.lateId && w.day < w.lateUntil),
  )
  if (!unit) return
  unit.behind = true
  unit.locked = false
  if (typeof unit.rentDue !== "number" || unit.rentDue > Math.floor(w.day)) unit.rentDue = Math.floor(w.day)
  w.delinquentAt = w.day
  toast(w, `Unit ${unit.number} did not pay. The lease is behind. The missed rent is owed, not cash.`)
}

function tickDelinquentResolve(w: World) {
  const late = w.units.find((u) => u.behind && u.status === "occupied")
  if (!late) return
  const wait = late.locked ? 0.55 : 1.35
  if (w.day < w.delinquentAt + wait) return
  const pay = !!late.locked && rand(w) < 0.72
  vacate(w, late, pay)
  w.delinquentAt = w.day + (pay ? 10 : 6)
}

function tickManager(w: World) {
  if (!w.manager) {
    w.managerAlert = null
    return
  }
  const notes: string[] = []
  for (const unit of w.units) {
    if (!isMaple(unit)) continue
    if (unit.status !== "makeReady") continue
    if (w.tasks.some((t) => t.kind === "makeReady" && t.targetId === unit.id)) continue
    queueTask(w, {
      id: `task-${unit.number}`,
      kind: "makeReady",
      targetId: unit.id,
      label: `Make-ready · ${unit.number}`,
      work: 2.4,
      done: 0,
      assignee: null,
    })
    notes.push(unit.number)
  }
  if (w.lightFault && !w.tasks.some((t) => t.targetId === "light")) {
    queueTask(w, {
      id: "task-light",
      kind: "repair",
      targetId: "light",
      label: "Replace gate lamp",
      work: 2.2,
      done: 0,
      assignee: null,
    })
    notes.push("the gate lamp")
  }
  if (notes.length) {
    const hands = w.porter || w.tech ? "Staff can take it." : "It waits on you until someone is hired."
    toast(w, `Manager queued ${notes.join(", ")}. ${hands}`)
  }
  const elevOpen =
    (w.elevWear === "due" || w.elevWear === "down") && !w.servicePlan && !w.tasks.some((t) => t.kind === "service")
  if (elevOpen) {
    if (w.managerAlert !== "elev" && notes.length === 0) {
      toast(w, "The elevator needs service and there is no plan. The Manager will not start that visit.")
    }
    w.managerAlert = "elev"
  } else w.managerAlert = null
}

function maybeGraduate(w: World) {
  if (w.milestones.graduated) return
  const m = w.milestones
  if (!m.rentReady || !m.leased || !m.commissioned || !m.cartSeen || !m.repaired || !m.hired || !m.climate || !m.upper || !m.serviced || !m.turned || !m.cycled) return
  if (!w.servicePlan && !w.tech) return
  w.milestones.graduated = true
  if (!w.steadyAt) {
    w.steadyAt = Math.floor(w.day)
    w.goalCash = Math.round(w.cash + 3000)
  }
  toast(w, `Maple Street is steady. The quarter runs to day ${w.steadyAt + 90}. Hold ${money(w.goalCash)} and open Cedar. A short month fails it.`)
}

function tickConstruction(w: World, dt: number) {
  const groups = new Map<string, Unit[]>()
  for (const unit of w.units) {
    if (unit.status !== "constructing" || !unit.group) continue
    const list = groups.get(unit.group) ?? []
    list.push(unit)
    groups.set(unit.group, list)
  }
  for (const list of groups.values()) {
    const dur = 16 + list.length * 4.5
    const before = list.some((u) => u.progress < 1)
    for (const unit of list) unit.progress = Math.min(1, unit.progress + dt / dur)
    if (before && list.every((u) => u.progress >= 1)) {
      for (const unit of list) {
        unit.progress = 1
        unit.status = "uncommissioned"
      }
      const cedar = list[0]?.site === "cedar"
      toast(w, cedar ? "Cedar Court row is built. Commission it before those units can lease." : "Construction finished. Commission the row before it can lease.")
    }
  }
  const active = w.units.filter((u) => u.status === "constructing" && u.site !== "cedar")
  const crew = w.movers.filter((m) => m.role === "crew")
  if (!active.length) {
    for (const c of crew) c.visible = false
    return
  }
  const anchor = active[0]!
  crew.forEach((c, i) => {
    c.visible = true
    c.working = true
    c.x = anchor.x + 1.5 + i * 3.2
    c.y = anchor.y + anchor.d + 2.2
  })
}

export function applyInstant(w: World) {
  if (w.play !== "free" || !w.instant) return
  const groups = new Map<string, Unit[]>()
  for (const unit of w.units) {
    if (unit.status !== "constructing" || !unit.group) continue
    const list = groups.get(unit.group) ?? []
    list.push(unit)
    groups.set(unit.group, list)
  }
  for (const list of groups.values()) {
    if (!list.some((unit) => unit.progress < 1)) continue
    for (const unit of list) {
      unit.progress = 1
      unit.status = "uncommissioned"
    }
    const cedar = list[0]?.site === "cedar"
    toast(w, cedar ? "Cedar Court row is built. Commission it before those units can lease." : "Construction finished. Commission the row before it can lease.")
  }
  if (w.hvac === "building" && w.hvacProgress < 1) {
    w.hvacProgress = 1
    toast(w, "HVAC plant is in. Commission it before the climate rate applies.")
  }
  if (w.floor2 === "building" && w.floorProgress < 1) {
    w.floorProgress = 1
    w.floor2 = "built"
    toast(w, w.elevator === "built" ? "Second floor is in. Open it when you are ready." : "Second floor is built. It still needs an elevator.")
  }
  if (w.elevator === "building" && w.elevatorProgress < 1) {
    w.elevatorProgress = 1
    w.elevator = "built"
    toast(w, w.floor2 === "built" ? "Elevator is in. Open floor 2 when you are ready." : "Elevator is in. It needs a second floor.")
  }
  if (w.secondCab === "building" && w.secondProgress < 1) {
    w.secondProgress = 1
    w.secondCab = "built"
    w.cabs = 2
    toast(w, "Second cab is in. It did not add units. If one cab fails, the other still runs.")
  }
}

function tickCedar(w: World, dt: number) {
  const units = w.units.filter((u) => u.site === "cedar")
  if (!units.length) return
  for (const unit of units) {
    if (unit.status !== "makeReady") continue
    unit.progress = Math.min(1, unit.progress + dt / 0.7)
    if (unit.progress >= 1) {
      unit.status = "rentReady"
      unit.progress = 1
      toast(w, `Cedar Court swept unit ${unit.number}. It can rent.`)
    }
  }
  const ready = units.find((u) => u.status === "rentReady")
  if (!ready) {
    w.cedarWait = 0
    return
  }
  const market = 145
  const ask = ready.ask ?? market
  if (isPass(ask, market, w.demand)) {
    if (w.cedarPassId !== ready.id) {
      w.cedarPassId = ready.id
      toast(w, `Cedar Court unit ${ready.number} is priced past the market. Prospects are passing.`)
    }
    return
  }
  if (w.cedarPassId === ready.id) w.cedarPassId = null
  w.cedarWait += dt
  if (w.cedarWait < 1.1) return
  w.cedarWait = 0
  ready.status = "occupied"
  ready.lease = ask
  ready.tenant = pickName(w)
  ready.ask = null
  const first = takeFirstRent(w, ready)
  toast(w, `Cedar Court leased unit ${ready.number} to ${ready.tenant}. First payment ${money(first)}.`)
  w.took += 1
  w.tookSince += 1
  w.dayLeases += 1
}

function tickBilling(w: World) {
  let guard = 0
  while (Math.floor(w.day) > w.billedThrough && guard++ < 3) {
    w.billedThrough += 1
    const today = w.billedThrough
    const cost = dailyCost(w)
    w.cash -= cost
    w.rentAge += 1
    const paid = collectDueRent(w, today)
    if (paid.amount > 0 || paid.skipped) {
      w.lastRent = paid.amount
      w.rentAge = 0
      toast(
        w,
        paid.skipped
          ? `Rent posted · ${money(paid.amount)}. Unit ${paid.skipped} did not pay ${money(paid.skippedAmount)}. That amount is owed, not cash.`
          : `Rent posted · ${money(paid.amount)}`,
      )
    }
    const skip = paid.skipped ? ` Unit ${paid.skipped} skipped ${money(paid.skippedAmount)}.` : ""
    pushLedger(w, `Rent ${money(paid.amount)} in. Costs ${moneyCents(cost)} out.${skip}`, paid.amount - cost)
    const next = w.units
      .filter((u) => u.status === "occupied" && typeof u.rentDue === "number")
      .map((u) => u.rentDue as number)
    w.daysToRent = next.length ? Math.max(0, Math.min(...next) - today) : 30
    if (w.expandLock && today >= w.expandUntil) {
      w.expandLock = ""
      w.expandUntil = 0
    }
  }
}

function collectDueRent(w: World, today: number) {
  let amount = 0
  let skipped = ""
  let skippedAmount = 0
  for (const unit of w.units) {
    if (unit.status !== "occupied") continue
    if (typeof unit.rentDue !== "number") unit.rentDue = today + Math.max(0, w.daysToRent) - 1
    if (unit.rentDue > today) continue
    if (unit.behind) {
      const bill = unit.lease ?? 0
      unit.owed = (unit.owed ?? 0) + bill
      skippedAmount += bill
      if (!skipped) skipped = unit.number
      unit.rentDue = today + 30
      continue
    }
    amount += unit.lease ?? 0
    unit.rentDue = today + 30
  }
  w.cash += amount
  return { amount, skipped, skippedAmount }
}

function takeFirstRent(w: World, unit: Unit) {
  const pay = Math.round(unit.lease ?? 0)
  w.cash += pay
  w.lastRent = pay
  w.rentAge = 0
  unit.rentDue = Math.floor(w.day) + 30
  unit.owed = 0
  pushLedger(w, `Unit ${unit.number} move-in ${money(pay)}.`, pay)
  const next = w.units
    .filter((u) => u.status === "occupied" && typeof u.rentDue === "number")
    .map((u) => u.rentDue as number)
  if (next.length) w.daysToRent = Math.max(0, Math.min(...next) - Math.floor(w.day))
  return pay
}

function tickLoose(w: World) {
  if (!w.milestones.cartSeen || w.milestones.cartRecovered) return
  if (w.carts.some((c) => c.phase === "stray")) return
  if (!w.looseAt) {
    w.looseAt = w.day + 0.3
    return
  }
  if (w.day < w.looseAt) return
  const cart = w.carts.find((c) => c.phase === "home")
  if (!cart) return
  cart.phase = "stray"
  cart.x = 78
  cart.y = 40
  toast(w, "A cart was left by the loading door. It belongs in the corral.")
}

function tickHall(w: World) {
  if (w.hallDark || w.milestones.hallLit || !w.milestones.cartRecovered) return
  if (!w.hallAt) {
    w.hallAt = w.day + 0.4
    return
  }
  if (w.day < w.hallAt) return
  w.hallDark = true
  toast(w, "The indoor hall light is out. Open the roof. The hallway is dark.")
}

function tickBusyDay(w: World) {
  if (!w.milestones.graduated || !w.reviewSeen) return
  const day = Math.floor(w.day)
  if (!w.issueDay) {
    w.issueDay = day
    return
  }
  if (w.issueDay === day) return
  w.issueDay = day
  if (w.upkeep === "off") return
  if (rand(w) > (w.upkeep === "often" ? 0.9 : 0.7)) return
  const open =
    (w.lightFault ? 1 : 0) +
    (w.hallDark ? 1 : 0) +
    (w.keypadFault ? 1 : 0) +
    (w.carts.some((c) => c.phase === "stray") ? 1 : 0)
  if (open >= 3) return
  const staffed = w.porter || w.tech
  const count = staffed && rand(w) < 0.5 ? 2 : 1
  const notes: string[] = []
  for (let i = 0; i < count && open + notes.length < 3; i++) {
    const note = raiseIssue(w)
    if (!note) break
    notes.push(note)
  }
  if (notes.length > 1) toast(w, `A few things need you today: ${notes.join(" and ")}. Queue them.`)
  else if (notes.length === 1) toast(w, notes[0])
}

function raiseIssue(w: World): string | null {
  const options: (() => string)[] = []
  if (!w.lightFault && !w.tasks.some((t) => t.targetId === "light")) {
    options.push(() => {
      w.lightFault = true
      return "The gate lamp is out again."
    })
  }
  if (!w.hallDark && w.milestones.hallLit && !w.tasks.some((t) => t.targetId === "hall")) {
    options.push(() => {
      w.hallDark = true
      return "The hall light is out again."
    })
  }
  if (w.keypad && !w.keypadFault && w.milestones.keypadServiced && !w.tasks.some((t) => t.targetId === "keypad")) {
    options.push(() => {
      w.keypadFault = true
      return "The keypad is sticking again."
    })
  }
  const cart = w.carts.find((c) => c.phase === "home")
  if (cart && w.milestones.cartRecovered && !w.tasks.some((t) => t.kind === "recover")) {
    options.push(() => {
      cart.phase = "stray"
      cart.x = 78
      cart.y = 40
      return "A cart was left by the loading door again."
    })
  }
  if (!options.length) return null
  return options[Math.floor(rand(w) * options.length)]()
}

function tickKeypad(w: World) {
  if (!w.keypad || w.keypadFault || w.milestones.keypadServiced || w.cameraFault) return
  const due = w.milestones.cameraServiced ? w.securedAt + 1.1 : w.keypadAt + 1
  if (!due || w.day < due) return
  w.keypadFault = true
  toast(w, "The gate keypad is sticking. The arm only rises part way.")
}

function tickSecurity(w: World) {
  if (!w.camera || !w.keypad || w.cameraFault || w.milestones.cameraServiced) return
  if (!w.securedAt) return
  if (w.day < w.securedAt + 0.45) return
  w.cameraFault = true
  toast(w, "The gate camera is offline. The apron is a blind spot until it is serviced.")
}

const OFFERS: { key: ProductKey; label: string }[] = [
  { key: "drive-up:5x5", label: "a 5×5" },
  { key: "drive-up:5x10", label: "a 5×10 drive-up" },
  { key: "interior:5x10", label: "an interior 5×10" },
  { key: "interior:10x10", label: "a 10×10" },
  { key: "upper:5x10", label: "an upper 5×10" },
]

function offerable(w: World) {
  return OFFERS.filter((ask) => {
    if (ask.key === "upper:5x10") return w.upperOpen
    if (ask.key === "drive-up:5x5") {
      return (
        w.units.some((u) => isMaple(u) && productKey(u) === ask.key) || w.pads.some((pad) => !padTaken(w, pad.id))
      )
    }
    return w.units.some((u) => isMaple(u) && productKey(u) === ask.key)
  })
}

function syncUnmet(w: World) {
  let best = 0
  let label = ""
  for (const ask of offerable(w)) {
    const count = w.misses?.[ask.key] ?? 0
    if (count > best) {
      best = count
      label = ask.label
    }
  }
  w.unmet = best > 0 ? `${best} asked for ${label}. None were ready.` : ""
}

export function clearMiss(w: World, unit: Unit) {
  if (!isMaple(unit)) return
  if (!w.misses) w.misses = {}
  const key = productKey(unit)
  if (!w.misses[key]) return
  w.misses[key] = 0
  syncUnmet(w)
}

function recordMiss(w: World, ask: { key: ProductKey; label: string }) {
  if (!w.misses) w.misses = {}
  const count = (w.misses[ask.key] ?? 0) + 1
  w.misses[ask.key] = count
  syncUnmet(w)
  const lean = w.demand === "busy" ? 0.75 : w.demand === "quiet" ? 1.35 : 1
  w.unmetAt = w.day + (4 * lean) / DAY_SECONDS
  const busy = w.toast && w.toastTtl > 0.4 && !w.toast.includes("asked for")
  if (!busy) toast(w, `${count} asked for ${ask.label}. None were ready.`)
}

function lightSchedule(w: World) {
  if (w.lightFault || w.milestones.repaired) return
  if (!w.milestones.makeReadyStarted) return
  if (w.upkeep === "off") return
  if (w.day < (w.upkeep === "often" ? 18.15 : 18 + 8 / 24 + 0.2)) return
  w.lightFault = true
  toast(w, "A light at the gate is out.")
}

function considerProspect(w: World, dt: number) {
  if (!w.prospect) {
    if (w.unmetAt && w.day < w.unmetAt) return
    let ready: Unit | undefined
    if (!w.milestones.leased) {
      const readyUnits = w.units.filter((u) => isMaple(u) && u.status === "rentReady")
      ready =
        readyUnits.find((u) => {
          const key = productKey(u)
          return !isPass(w.prices[key], marketFor(key, w.hvac === "live", cabBlocked(w)), w.demand)
        }) ?? readyUnits[0]
    } else {
      const offers = offerable(w)
      if (!offers.length) return
      const ask = offers[Math.floor(rand(w) * offers.length)]!
      const readyUnits = w.units.filter((u) => isMaple(u) && u.status === "rentReady" && productKey(u) === ask.key)
      const fair = (list: Unit[]) =>
        list.find((u) => {
          const key = productKey(u)
          return !isPass(w.prices[key], marketFor(key, w.hvac === "live", cabBlocked(w)), w.demand)
        }) ?? list[0]
      if (!readyUnits.length) {
        recordMiss(w, ask)
        const others = w.units.filter((u) => isMaple(u) && u.status === "rentReady" && productKey(u) !== ask.key)
        ready = others.length ? fair(others) : undefined
        if (!ready) return
      } else ready = fair(readyUnits)
    }
    if (!ready) return
    const key = productKey(ready)
    const ask = w.prices[key]
    const market = marketFor(key, w.hvac === "live", cabBlocked(w))
    const pricePass = isPass(ask, market, w.demand)
    const strain = siteStrain(w)
    const moodPass = !pricePass && strain.pass > 0 && rand(w) < strain.pass
    const pass = pricePass || moodPass
    w.prospect = {
      unitId: ready.id,
      wait: responseWait(ask, market, pricePass) + (pass ? 0 : strain.extraWait),
      name: pickName(w),
      pass,
    }
    toast(
      w,
      pricePass
        ? `Asking rent on unit ${ready.number} is high for this market.`
        : moodPass
          ? `A prospect looked at unit ${ready.number} and is leaving. ${strain.reason ? strain.reason[0]!.toUpperCase() + strain.reason.slice(1) : "The lot looks neglected"}.`
          : strain.reason
            ? `A prospect is considering unit ${ready.number}, slowly. ${strain.reason[0]!.toUpperCase() + strain.reason.slice(1)}.`
            : ready.floor === 2 && cabBlocked(w)
              ? `A prospect is considering unit ${ready.number}. The elevator makes this a slower trip.`
              : `A prospect is considering unit ${ready.number}.`,
    )
    return
  }
  w.prospect.wait -= dt
  if (w.prospect.wait > 0) return
  const unit = findUnit(w, w.prospect.unitId)
  if (!unit || unit.status !== "rentReady") {
    w.prospect = null
    return
  }
  const key = productKey(unit)
  const pass = w.prospect.pass || isPass(w.prices[key], marketFor(key, w.hvac === "live", cabBlocked(w)), w.demand)
  const strain = siteStrain(w)
  const pricePass = isPass(w.prices[key], marketFor(key, w.hvac === "live", cabBlocked(w)), w.demand)
  w.visit = {
    kind: pass ? "pass" : "lease",
    stage: -1,
    wait: 0,
    unitId: unit.id,
    name: w.prospect.name,
    cartId: null,
    line: pass && !pricePass ? strain.reason ?? "the lot looks neglected" : undefined,
  }
  w.prospect = null
  const car = moverBy(w, "vcar")
  if (car) {
    car.fill = pass ? "#1e3a4c" : "#8e3d32"
    car.vehicle = pass ? "sedan" : "pickup"
  }
  enterStage(w, 0)
}

function complaintOf(w: World): { reason: string; line: string } | null {
  if (w.keypadFault) return { reason: "keypad", line: "My gate code isn't working." }
  if (w.lightFault) return { reason: "light", line: "The light by the gate is out." }
  if (w.hallDark) return { reason: "hall", line: "The hallway by my unit is dark." }
  if (w.elevWear === "down") return { reason: "elevator", line: "I've been waiting on the elevator." }
  const late = w.units.find((u) => u.behind && u.status === "occupied" && !u.locked)
  if (late) return { reason: "rent", line: `I need to sort the rent on unit ${late.number}.` }
  return null
}

function tryOffice(w: World): boolean {
  if (w.welcome || !w.milestones.makeReadyStarted) return false
  const issue = complaintOf(w)
  if (!issue) {
    w.officeAt = 0
    w.officeSeen = ""
    return false
  }
  if (w.officeSeen === issue.reason) return false
  if (!w.officeAt) {
    w.officeAt = w.day + 0.28
    return false
  }
  if (w.day < w.officeAt) return false
  w.officeSeen = issue.reason
  w.officeAt = 0
  const tenant = w.units.find((u) => u.status === "occupied" && u.tenant)
  w.visit = {
    kind: "office",
    stage: -1,
    wait: 0,
    unitId: null,
    name: tenant?.tenant ?? pickName(w),
    cartId: null,
    line: issue.line,
  }
  const car = moverBy(w, "vcar")
  if (car) {
    car.fill = "#5c6a72"
    car.vehicle = "sedan"
  }
  enterStage(w, 0)
  return true
}

function startInterior(w: World) {
  const occupied = w.units.filter((u) => u.access === "interior" && u.status === "occupied")
  const upper = occupied.filter((u) => u.floor === 2)
  const pool = upper.length ? upper : occupied
  const unit = pool[Math.floor(rand(w) * pool.length)] ?? pool[0]
  if (!unit) return
  w.visit = {
    kind: "interior",
    stage: -1,
    wait: 0,
    unitId: unit.id,
    name: unit.tenant ?? "Tenant",
    cartId: null,
  }
  const car = moverBy(w, "vcar")
  if (car) {
    car.fill = "#d9d3c7"
    car.vehicle = "sedan"
  }
  enterStage(w, 0)
}

function enterStage(w: World, stage: number) {
  const v = w.visit
  if (!v) return
  v.stage = stage
  v.wait = 0
  const car = moverBy(w, "vcar")
  const person = moverBy(w, "vperson")
  if (!car || !person) return

  if (v.kind === "interior") {
    interiorStage(w, v, car, person, stage)
    return
  }
  if (v.kind === "moveout") {
    moveoutStage(w, v, car, stage)
    return
  }
  if (v.kind === "office") {
    officeStage(w, v, car, person, stage)
    return
  }
  if (v.kind === "lease") {
    leaseStage(w, v, car, stage)
    return
  }
  passStage(w, v, car, stage)
}

function interiorStage(w: World, v: Visit, car: Mover, person: Mover, stage: number) {
  const unit = findUnit(w, v.unitId)
  if (stage === 0) {
    car.visible = true
    car.x = NODES.streetW.x
    car.y = NODES.streetW.y
    car.path = route(car, NODES.gateIn, CAR_NODES)
    person.visible = false
    person.heldCart = false
    return
  }
  if (stage === 1) {
    car.path = route(car, NODES.apron, CAR_NODES)
    return
  }
  if (stage === 2) {
    person.visible = true
    person.x = car.x
    person.y = car.y + 1
    person.fill = "#8e3d32"
    person.path = route(person, NODES.corral, PERSON_NODES)
    return
  }
  if (stage === 3) {
    const cart = w.carts.find((c) => c.phase === "home")
    if (!cart) {
      person.path = []
      person.heldCart = false
      if (!w.cartNote) {
        w.cartNote = true
        toast(w, "No cart is free. The customer is waiting at the corral.")
      }
      return
    }
    w.cartNote = false
    cart.phase = "follow"
    v.cartId = cart.id
    person.heldCart = true
    const dest = unit ? doorPoint(unit) : NODES.hall
    person.path = route(person, dest, PERSON_NODES)
    return
  }
  if (stage === 4) {
    if (unit?.floor === 2 && cabBlocked(w)) {
      w.milestones.cartSeen = true
      toast(w, "The elevator is down. This cart turns around. Floor 2 has to wait.")
      v.stage = 5
      v.wait = 0.5
      return
    }
    const slow = w.cabs >= 2 ? (w.elevWear === "down" ? 5.2 : w.elevWear === "due" ? 3.2 : 2.2) : w.elevWear === "due" ? 6.2 : 4.4
    v.wait = unit?.floor === 2 ? slow : 2.3
    w.milestones.cartSeen = true
    if (unit?.floor === 2) {
      w.elevatorQueue = Math.max(w.elevatorQueue, slow)
      if (w.elevWear === "down" && w.cabs >= 2) toast(w, "One cab is down. The other is taking this cart.")
      else if (w.elevWear === "due") toast(w, "The cab is slow. It is due for service.")
      else if (w.cabs < 2) toast(w, "A cart is in the elevator. The next one waits. One cab is the capacity.")
    }
    return
  }
  if (stage === 5) {
    person.path = route(person, NODES.vest, PERSON_NODES)
    return
  }
  if (stage === 6) {
    person.path = route(person, NODES.corral, PERSON_NODES)
    return
  }
  if (stage === 7) {
    if (v.cartId) {
      const cart = w.carts.find((c) => c.id === v.cartId)
      if (cart && w.milestones.cartRecovered && rand(w) < 0.28) {
        cart.phase = "stray"
        cart.x = 78
        cart.y = 40
        toast(w, "The customer left the cart by the loading door.")
      } else if (cart) cart.phase = "return"
      v.cartId = null
    }
    person.heldCart = false
    person.path = route(person, { x: car.x, y: car.y + 1 }, PERSON_NODES)
    return
  }
  if (stage === 8) {
    person.visible = false
    car.path = route(car, { x: -10, y: 5 }, CAR_NODES)
    return
  }
  car.visible = false
  person.visible = false
  w.visit = null
  w.nextInterior = Math.max(w.nextInterior, 30)
}

function emptyUnit(w: World, unit: Unit) {
  if (unit.status !== "occupied") return
  if (unit.owed && unit.owed > 0) {
    pushLedger(w, `Unit ${unit.number} moved out. ${money(unit.owed)} written off. Not cash.`, 0)
    unit.owed = 0
  }
  unit.status = "makeReady"
  unit.tenant = null
  unit.lease = null
  unit.behind = false
  unit.locked = false
  unit.progress = 0
  unit.note = "Moved out. Needs a sweep before it can rent again."
  toast(w, `Unit ${unit.number} is empty. It needs a sweep before it can rent.`)
}

function moveoutStage(w: World, v: Visit, car: Mover, stage: number) {
  const unit = findUnit(w, v.unitId)
  if (stage === 0) {
    car.visible = true
    car.x = NODES.streetW.x
    car.y = NODES.streetW.y
    car.vehicle = "pickup"
    car.fill = "#c4a574"
    const dest = unit ? doorPoint(unit) : NODES.apron
    car.path = route(car, dest, CAR_NODES)
    return
  }
  if (stage === 1) {
    v.wait = 2.6
    return
  }
  if (stage === 2) {
    if (unit) emptyUnit(w, unit)
    car.path = route(car, { x: -10, y: 5 }, CAR_NODES)
    return
  }
  car.visible = false
  w.visit = null
  w.nextInterior = Math.max(w.nextInterior, 16)
}

function officeStage(w: World, v: Visit, car: Mover, person: Mover, stage: number) {
  if (stage === 0) {
    car.visible = true
    car.x = NODES.streetW.x
    car.y = NODES.streetW.y
    car.vehicle = "sedan"
    car.fill = "#5c6a72"
    car.path = route(car, NODES.gateIn, CAR_NODES)
    person.visible = false
    person.heldCart = false
    return
  }
  if (stage === 1) {
    person.visible = true
    person.x = car.x
    person.y = car.y + 1
    person.fill = "#3d4c5c"
    person.path = route(person, NODES.office, PERSON_NODES)
    return
  }
  if (stage === 2) {
    v.wait = 2.4
    toast(w, `${v.name} at the office: "${v.line ?? "I need help at the office."}"`)
    return
  }
  if (stage === 3) {
    person.visible = false
    car.path = route(car, { x: -10, y: 5 }, CAR_NODES)
    return
  }
  car.visible = false
  person.visible = false
  w.visit = null
}

function leaseStage(w: World, v: Visit, car: Mover, stage: number) {
  const unit = findUnit(w, v.unitId)
  if (stage === 0) {
    car.visible = true
    car.x = NODES.streetW.x
    car.y = NODES.streetW.y
    const dest = unit?.access === "drive-up" ? doorPoint(unit) : NODES.apron
    car.path = route(car, dest, CAR_NODES)
    return
  }
  if (stage === 1) {
    v.wait = 2.1
    return
  }
  if (stage === 2) {
    if (unit && unit.status === "rentReady") {
      const key: ProductKey = productKey(unit)
      unit.status = "occupied"
      unit.tenant = v.name
      unit.lease = Math.round(w.prices[key])
      const first = takeFirstRent(w, unit)
      w.milestones.leased = true
      if (unit.floor === 2) {
        w.elevatorQueue = Math.max(w.elevatorQueue, 5)
        toast(w, `${v.name} leased unit ${unit.number}. First payment ${money(first)}. The elevator queue picked up.`)
      } else toast(w, `${v.name} leased unit ${unit.number}. First payment ${money(first)}.`)
      w.took += 1
      w.tookSince += 1
      w.dayLeases += 1
    }
    car.path = route(car, { x: -10, y: 5 }, CAR_NODES)
    return
  }
  car.visible = false
  w.visit = null
  w.nextInterior = Math.max(w.nextInterior, 12)
}

function passStage(w: World, v: Visit, car: Mover, stage: number) {
  if (stage === 0) {
    car.visible = true
    car.x = NODES.streetW.x
    car.y = NODES.streetW.y
    car.path = route(car, NODES.gateIn, CAR_NODES)
    return
  }
  if (stage === 1) {
    v.wait = 1.4
    return
  }
  if (stage === 2) {
    const unit = findUnit(w, v.unitId)
    const down = unit?.floor === 2 && cabBlocked(w)
    const why = v.line ? v.line[0]!.toUpperCase() + v.line.slice(1) : ""
    toast(
      w,
      why
        ? `Prospect passed on unit ${unit?.number ?? ""}. ${why}.`.replace("  ", " ")
        : down
          ? `Prospect passed on unit ${unit?.number ?? ""}. Floor 2 is a poor trip while the elevator is down.`
          : `Prospect passed. Asking rent on unit ${unit?.number ?? ""} is high for this market.`.replace("  ", " "),
    )
    w.passes += 1
    w.passesSince += 1
    w.dayPasses += 1
    w.lastPass = v.line ? v.line : down ? "the elevator is down" : "asking rent"
    car.path = route(car, { x: -10, y: 5 }, CAR_NODES)
    return
  }
  car.visible = false
  w.visit = null
}

function activeMover(w: World, v: Visit): Mover | undefined {
  if (v.kind === "office") {
    if (v.stage === 1) return moverBy(w, "vperson")
    if (v.stage === 0 || v.stage === 3) return moverBy(w, "vcar")
    return undefined
  }
  const carStages = v.kind === "interior" ? new Set([0, 1, 8]) : new Set([0, 2])
  if (v.kind === "interior" && !carStages.has(v.stage) && v.stage !== 4) return moverBy(w, "vperson")
  if (v.kind !== "interior" && v.stage === 1) return undefined
  if (carStages.has(v.stage) || v.kind !== "interior") return moverBy(w, "vcar")
  return undefined
}

function tickVisit(w: World, dt: number) {
  if (w.visit) {
    const v = w.visit
    if (v.kind === "moveout" && v.stage < 2 && v.since != null && w.day - v.since > 1.2) {
      const unit = findUnit(w, v.unitId)
      if (unit) emptyUnit(w, unit)
      const car = moverBy(w, "vcar")
      if (car) {
        car.visible = false
        car.path = []
      }
      w.visit = null
      w.nextInterior = Math.max(w.nextInterior, 16)
      return
    }
    if (v.kind === "interior" && v.stage === 3 && !v.cartId) {
      const cart = w.carts.find((c) => c.phase === "home")
      if (!cart) {
        if (!w.cartNote) {
          w.cartNote = true
          toast(w, "No cart is free. The customer is waiting at the corral.")
        }
        w.cartPace += dt
        const person = moverBy(w, "vperson")
        if (person) {
          const swing = Math.sin(w.cartPace * 1.6)
          person.x = NODES.corral.x + swing * 1.4
          person.y = NODES.corral.y + (swing > 0 ? -2.2 : 0.4)
          person.path = []
          person.visible = true
        }
        return
      }
      enterStage(w, 3)
      return
    }
    if (v.wait > 0) {
      v.wait -= dt
      if (v.wait > 0) return
      enterStage(w, v.stage + 1)
      return
    }
    const mover = activeMover(w, v)
    if (!mover) {
      enterStage(w, v.stage + 1)
      return
    }
    advance(mover, dt)
    if (mover.path.length === 0) enterStage(w, v.stage + 1)
    return
  }
  if (tryOffice(w)) return
  w.nextInterior -= dt
  if (w.nextInterior <= 0) {
    w.nextInterior = 34
    startInterior(w)
    return
  }
  if (w.milestones.leased || w.units.some((u) => isMaple(u) && u.status === "rentReady")) considerProspect(w, dt)
}

function tickCarts(w: World, dt: number) {
  const person = moverBy(w, "vperson")
  for (const cart of w.carts) {
    if (cart.phase === "follow" && person?.visible) {
      cart.x = person.x - 0.8
      cart.y = person.y + 0.9
    } else if (cart.phase === "stray") {
      const task = w.tasks.find((t) => t.kind === "recover" && t.done > 0)
      const who = task?.assignee ? moverBy(w, task.assignee) : undefined
      if (who?.working) {
        cart.x = who.x + 1.1
        cart.y = who.y + 0.4
      }
    } else if (cart.phase === "return") {
      const dx = cart.homeX - cart.x
      const dy = cart.homeY - cart.y
      const len = Math.hypot(dx, dy)
      if (len < 0.25) {
        cart.x = cart.homeX
        cart.y = cart.homeY
        cart.phase = "home"
      } else {
        const step = Math.min(len, 14 * dt)
        cart.x += (dx / len) * step
        cart.y += (dy / len) * step
      }
    }
  }
}

function tickQuarter(w: World) {
  if (!w.steadyAt || w.quarterTold) return
  if (w.day < w.steadyAt + 90) return
  const cedar = w.units.some((u) => u.site === "cedar" && u.status !== "uncommissioned")
  const month = rentRoll(w.units) - dailyCost(w) * 30
  const held = w.cash >= w.goalCash && cedar && month >= 0
  w.quarterTold = held ? "held" : "slipped"
  toast(
    w,
    held
      ? `The quarter held. ${money(w.goalCash)} by day ${w.steadyAt + 90}, Cedar open, and the month was not short.`
      : "The quarter slipped. Cash, Cedar, or the month missed the mark.",
  )
}

function closeDay(w: World): string {
  const fault = siteStrain(w).reason
  const lead = fault ? fault.charAt(0).toUpperCase() + fault.slice(1) : ""
  if (w.dayLeases > 0 && w.dayPasses > 0) return `Yesterday: ${w.dayLeases} leased, ${w.dayPasses} drove past.`
  if (w.dayLeases > 0 && lead) return `Yesterday: ${w.dayLeases} leased. ${lead}.`
  if (w.dayLeases > 0) return `Yesterday: ${w.dayLeases} leased. The lot was in good shape.`
  if (w.dayPasses > 0 && lead) return `Yesterday: ${w.dayPasses} drove past. ${lead}.`
  if (w.dayPasses > 0) return `Yesterday: ${w.dayPasses} drove past. Asking rent may be high.`
  if (lead) return `Yesterday was quiet. ${lead}.`
  return "Yesterday was quiet."
}

function simulate(w: World, dt: number) {
  w.day += dt / DAY_SECONDS
  const today = Math.floor(w.day)
  if (w.energyDay !== today) {
    w.dayNote = closeDay(w)
    w.dayLeases = 0
    w.dayPasses = 0
    w.energyDay = today
    w.energy = energyMax(w)
  }
  tickDelinquentMark(w)
  tickBilling(w)
  tickDelinquentResolve(w)
  lightSchedule(w)
  tickSecurity(w)
  tickLoose(w)
  tickHall(w)
  tickKeypad(w)
  tickBusyDay(w)
  tickConstruction(w, dt)
  tickHvac(w, dt)
  tickVertical(w, dt)
  tickWear(w)
  tickFirstTurnover(w)
  tickTurnover(w)
  tickManager(w)
  tickCedar(w, dt)
  tickWorkers(w, dt)
  tickVisit(w, dt)
  tickCarts(w, dt)
  maybeGraduate(w)
  tickQuarter(w)
  w.cash = Math.round(w.cash * 100) / 100
}

let gatePhase = 0

function frameDt(realDt: number): number {
  if (!Number.isFinite(realDt) || realDt <= 0) return 0
  return Math.min(0.05, realDt)
}

function finiteOr(n: number, fallback = 0): number {
  return Number.isFinite(n) ? n : fallback
}

export function present(w: World, realDt: number) {
  const frame = frameDt(realDt)
  if (w.toastTtl > 0) {
    w.toastTtl = finiteOr(w.toastTtl) - frame
    if (w.toastTtl <= 0) w.toast = null
  }
  const carNear = w.movers.some(
    (m) => m.kind === "car" && m.visible && m.x > 6 && m.x < 40 && m.y > 1 && m.y < 26,
  )
  if (!Number.isFinite(gatePhase)) gatePhase = 0
  gatePhase += frame
  const gateTarget = carNear ? (w.keypadFault ? 0.42 + Math.sin(gatePhase * 11) * 0.07 : 1) : 0
  const gateRate = w.keypadFault && carNear ? 8 : w.keypadFault ? 1.15 : 3.5
  w.gate = finiteOr(w.gate)
  w.gate += (gateTarget - w.gate) * Math.min(1, frame * gateRate)

  const holder = w.movers.find((m) => m.heldCart && m.visible)
  const atDock = !!holder && holder.x > 88 && holder.x < 112 && holder.y > 16 && holder.y < 52
  w.dock = finiteOr(w.dock)
  w.dock += ((atDock ? 1 : 0) - w.dock) * Math.min(1, frame * 2.6)
  const inside = w.visit?.kind === "interior" && w.visit.stage >= 3 && !!w.visit.cartId && w.visit.stage <= 6
  const roofTarget = w.roofHold || inside ? 1 : 0
  w.roof = finiteOr(w.roof)
  w.roof += (roofTarget - w.roof) * Math.min(1, frame * 2.4)
  if (w.upperOpen && !cabBlocked(w)) {
    const pace = w.elevWear === "due" ? 0.1 : w.elevWear === "down" ? 0.12 : w.cabs >= 2 ? 0.34 : 0.22
    w.cab = finiteOr(w.cab)
    w.cab = (w.cab + frame * pace) % 1
  }

  for (const unit of w.units) {
    let target = 0
    if (unit.status === "makeReady") {
      const task = w.tasks.find((t) => t.kind === "makeReady" && t.targetId === unit.id)
      const tidy = task ? Math.min(1, task.done / task.work) : unit.site === "cedar" ? unit.progress : 0
      unit.progress = tidy
      target = tidy > 0.66 ? 0.14 : 0.72
    }
    if (w.visit?.unitId === unit.id && (w.visit.kind === "lease" || w.visit.kind === "moveout") && w.visit.stage === 1) target = 0.78
    unit.doorOpen = finiteOr(unit.doorOpen)
    unit.doorOpen += (target - unit.doorOpen) * Math.min(1, frame * 3)
  }
}

let accum = 0

export function advanceWorld(w: World, realDt: number) {
  if (!Number.isFinite(accum) || accum < 0) accum = 0
  const frame = frameDt(realDt)
  present(w, frame)
  if (w.speed <= 0) return
  const add = frame * w.speed
  if (Number.isFinite(add) && add > 0) accum += add
  const step = 1 / 30
  let guard = 0
  while (accum >= step && guard++ < 8) {
    accum -= step
    simulate(w, step)
  }
}

export function resetAccum() {
  accum = 0
}

export function queueService(w: World): boolean {
  return queueServiceTask(w)
}

export function queueTask(w: World, task: Task): boolean {
  if (w.tasks.some((t) => t.kind === task.kind && t.targetId === task.targetId)) return false
  w.tasks.push(task)
  assignOpen(w)
  return true
}

export function pushLedger(w: World, text: string, amount: number) {
  if (!Array.isArray(w.ledger)) w.ledger = []
  w.ledger.unshift({ text, amount: Math.round(amount * 100) / 100 })
  if (w.ledger.length > 8) w.ledger.length = 8
}

export function owedBalance(w: World): number {
  return w.units.reduce((sum, unit) => sum + (Number.isFinite(unit.owed) ? (unit.owed as number) : 0), 0)
}

export function freshWorld(): World {
  resetAccum()
  return createWorld()
}

export function refreshProspect(w: World) {
  if (!w.prospect) return
  const unit = findUnit(w, w.prospect.unitId)
  if (!unit) return
  const key = productKey(unit)
  const market = marketFor(key, w.hvac === "live", cabBlocked(w))
  const pass = isPass(w.prices[key], market, w.demand)
  w.prospect.pass = pass
  w.prospect.wait = responseWait(w.prices[key], market, pass)
}

export function padTaken(w: World, padId: string): boolean {
  return w.units.some((u) => u.padId === padId)
}
