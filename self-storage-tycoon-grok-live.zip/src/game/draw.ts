import { LAYOUT as L } from "@/game/layout"
import type { Door, Unit, World } from "@/game/types"

export interface Camera {
  ox: number
  oy: number
  scale: number
}

const INK = "#1c2833"
const CREAM = "#f4efe6"
const DOOR = "#245f96"
const DOOR_READY = "#f6f1e6"
const DOOR_WAIT = "#d5dde4"
const DOOR_WORK = "#c9843a"
const ROOF = "#7c848c"
const WALL = "#e7dfd2"
const WALL_S = "#ddd3c4"
const WALL_E = "#cfc4b2"
const ASPHALT = "#3e4348"
const YARD = "#cbb892"
const CONCRETE = "#d9d3c6"

function hourOf(day: number) {
  return (day % 1) * 24
}

function gradeOf(hour: number) {
  if (hour >= 7 && hour < 17) return { top: "#8ea4ab", mid: "#7d9272", bot: "#5f734c", wash: 0 }
  if (hour >= 17 && hour < 20) return { top: "#c4896a", mid: "#8d735c", bot: "#3f5344", wash: 0.1 }
  if (hour >= 5 && hour < 7) return { top: "#d7b08a", mid: "#8ea08a", bot: "#5a6e48", wash: 0.05 }
  return { top: "#1b2836", mid: "#243246", bot: "#1a2822", wash: 0.22 }
}

function clouds(ctx: CanvasRenderingContext2D, width: number, now: number, night: boolean) {
  ctx.fillStyle = night ? "rgba(210,220,230,0.08)" : "rgba(244,239,230,0.42)"
  for (let i = 0; i < 4; i++) {
    const x = ((now * 14 + i * 220) % (width + 200)) - 80
    const y = 18 + (i % 3) * 26
    ctx.beginPath()
    ctx.ellipse(x, y, 78, 16, 0, 0, Math.PI * 2)
    ctx.ellipse(x + 36, y - 6, 46, 14, 0, 0, Math.PI * 2)
    ctx.fill()
  }
}

function birds(ctx: CanvasRenderingContext2D, width: number, now: number) {
  ctx.strokeStyle = "rgba(28,40,51,0.45)"
  ctx.lineWidth = 1.25
  for (let i = 0; i < 3; i++) {
    const x = ((now * 28 + i * 160) % (width + 40)) - 20
    const y = 36 + i * 14 + Math.sin(now * 2 + i) * 4
    const flap = Math.sin(now * 8 + i) * 4
    ctx.beginPath()
    ctx.moveTo(x - 6, y)
    ctx.quadraticCurveTo(x - 3, y - 4 - flap, x, y)
    ctx.quadraticCurveTo(x + 3, y - 4 - flap, x + 6, y)
    ctx.stroke()
  }
}

function skyBody(ctx: CanvasRenderingContext2D, width: number, height: number, hour: number) {
  const night = hour >= 20 || hour < 5
  const low = (hour >= 5 && hour < 7) || (hour >= 17 && hour < 20)
  const across = night ? 0.72 : hour < 7 ? 0.12 : hour < 17 ? 0.18 + ((hour - 7) / 10) * 0.5 : 0.78
  const x = width * across
  const y = height * (night ? 0.14 : low ? 0.2 : 0.11)
  const r = Math.max(8, Math.min(width, height) * 0.028)
  ctx.fillStyle = night ? "rgba(232,236,244,0.16)" : "rgba(243,231,184,0.38)"
  ctx.beginPath()
  ctx.arc(x, y, r * 2.6, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = night ? "#e7eef6" : low ? "#f3d2a2" : "#f7f1d8"
  ctx.beginPath()
  ctx.arc(x, y, r, 0, Math.PI * 2)
  ctx.fill()
}

function nightWash(ctx: CanvasRenderingContext2D, width: number, height: number, wash: number) {
  if (wash <= 0) return
  ctx.fillStyle = `rgba(12,18,28,${wash})`
  ctx.fillRect(0, 0, width, height)
}

export function project(cam: Camera, x: number, y: number, z: number) {
  return {
    sx: (x - y) * cam.scale + cam.ox,
    sy: (x + y) * cam.scale * 0.5 - z * cam.scale + cam.oy,
  }
}

export function screenToWorld(cam: Camera, sx: number, sy: number) {
  const a = (sx - cam.ox) / cam.scale
  const b = (sy - cam.oy) / (cam.scale * 0.5)
  return { x: (a + b) / 2, y: (b - a) / 2 }
}

export type FrameFocus = "front" | "site" | "pads" | "cedar"

export function frameCamera(
  cam: Camera,
  width: number,
  height: number,
  opts?: { focus?: FrameFocus; insetBottom?: number; at?: { x: number; y: number; w: number; d: number } },
) {
  const focus = opts?.focus ?? "site"
  const insetBottom = opts?.insetBottom ?? 0
  const at = opts?.at
  const corners = at
    ? [
        [at.x, at.y],
        [at.x + at.w, at.y],
        [at.x, at.y + at.d],
        [at.x + at.w, at.y + at.d],
      ]
    : focus === "front"
      ? [
          [18, 6],
          [86, 6],
          [18, 58],
          [86, 58],
        ]
      : focus === "pads"
        ? [
            [8, 56],
            [70, 56],
            [8, 98],
            [70, 98],
          ]
        : focus === "cedar"
          ? [
              [2, 0],
              [80, 0],
              [2, 48],
              [80, 48],
            ]
          : [
            [2, 0],
            [142, 0],
            [2, 98],
            [142, 98],
          ]
  let minA = Infinity
  let maxA = -Infinity
  let minB = Infinity
  let maxB = -Infinity
  for (const [x, y] of corners) {
    const a = x - y
    const b = (x + y) * 0.5
    minA = Math.min(minA, a)
    maxA = Math.max(maxA, a)
    minB = Math.min(minB, b)
    maxB = Math.max(maxB, b)
  }
  const pad = 16
  const usableH = Math.max(80, height - insetBottom)
  const spanA = maxA - minA
  const spanB = maxB - minB
  const fitW = (width - pad * 2) / spanA
  const fitH = (usableH - pad * 2) / spanB
  let scale = Math.min(fitW, fitH)
  if (focus === "front" && fitH > fitW * 1.45) {
    scale = Math.min(fitH * 0.9, fitW * 1.75)
  }
  cam.scale = Math.max(1.35, Math.min(scale, 18))
  cam.ox = width / 2 - ((minA + maxA) / 2) * cam.scale
  cam.oy = usableH / 2 - ((minB + maxB) / 2) * cam.scale
}

export function focusAt(world: World, id: string | null) {
  if (!id) return null
  const hits = hitList(world).filter((hit) => hit.id === id)
  if (!hits.length) return null
  const hit = hits.reduce((a, b) => (a.w * a.d >= b.w * b.d ? a : b))
  return { x: hit.x - 6, y: hit.y - 6, w: hit.w + 14, d: hit.d + 14 }
}

function poly(ctx: CanvasRenderingContext2D, pts: { sx: number; sy: number }[], fill: string, stroke?: string) {
  ctx.beginPath()
  ctx.moveTo(pts[0]!.sx, pts[0]!.sy)
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i]!.sx, pts[i]!.sy)
  ctx.closePath()
  ctx.fillStyle = fill
  ctx.fill()
  if (stroke) {
    ctx.strokeStyle = stroke
    ctx.lineWidth = 1
    ctx.stroke()
  }
}

function ground(ctx: CanvasRenderingContext2D, cam: Camera, x: number, y: number, w: number, d: number, fill: string) {
  const paved = fill === ASPHALT || fill === "#4a4f55"
  poly(
    ctx,
    [project(cam, x, y, 0.04), project(cam, x + w, y, 0.04), project(cam, x + w, y + d, 0.04), project(cam, x, y + d, 0.04)],
    fill,
    paved ? "rgba(22,26,30,0.45)" : undefined,
  )
}

function prism(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  x: number,
  y: number,
  z: number,
  w: number,
  d: number,
  h: number,
  top: string,
  south: string,
  east: string,
) {
  if (z < 0.2 && h > 0.5) {
    const c = project(cam, x + w / 2, y + d / 2, 0)
    ctx.fillStyle = "rgba(28,40,51,0.16)"
    ctx.beginPath()
    ctx.ellipse(c.sx + cam.scale * 0.35, c.sy + cam.scale * 0.55, Math.max(4, cam.scale * Math.min(7, (w + d) * 0.18)), Math.max(2, cam.scale * 0.38), 0, 0, Math.PI * 2)
    ctx.fill()
  }
  poly(
    ctx,
    [project(cam, x, y + d, z), project(cam, x + w, y + d, z), project(cam, x + w, y + d, z + h), project(cam, x, y + d, z + h)],
    south,
  )
  poly(
    ctx,
    [project(cam, x + w, y, z), project(cam, x + w, y + d, z), project(cam, x + w, y + d, z + h), project(cam, x + w, y, z + h)],
    east,
  )
  poly(
    ctx,
    [
      project(cam, x, y, z + h),
      project(cam, x + w, y, z + h),
      project(cam, x + w, y + d, z + h),
      project(cam, x, y + d, z + h),
    ],
    top,
  )
}

function doorColor(u: Unit): string {
  if (u.status === "makeReady") return DOOR_WORK
  if (u.status === "rentReady") return DOOR_READY
  if (u.status === "uncommissioned") return DOOR_WAIT
  if (u.status === "constructing") return "#b7b1a6"
  return DOOR
}

function drawDoor(ctx: CanvasRenderingContext2D, cam: Camera, u: Unit, face: Door) {
  const open = u.doorOpen
  const insetX = u.w * 0.16
  const dh = Math.min(u.h * 0.78, 5.4)
  const z0 = (u.z || 0) + 0.35
  if (face === "s") {
    const yy = u.y + u.d + 0.08
    const hingeX = u.x + insetX
    const dw = u.w - insetX * 2
    const swing = open * Math.min(3.2, dw * 0.9)
    const freeX = hingeX + dw * (1 - open * 0.25)
    const freeY = yy + swing
    poly(
      ctx,
      [
        project(cam, hingeX, yy, z0),
        project(cam, freeX, freeY, z0),
        project(cam, freeX, freeY, z0 + dh),
        project(cam, hingeX, yy, z0 + dh),
      ],
      doorColor(u),
      u.status === "rentReady" ? "#2a6b45" : "rgba(28,40,51,0.22)",
    )
    const num = project(cam, (hingeX + freeX) / 2, (yy + freeY) / 2, z0 + dh * 0.78)
    ctx.strokeStyle = "rgba(28,40,51,0.22)"
    ctx.lineWidth = 1
    for (let i = 1; i <= 3; i++) {
      const z = z0 + dh * (i / 5)
      const left = project(cam, hingeX, yy, z)
      const right = project(cam, freeX, freeY, z)
      ctx.beginPath()
      ctx.moveTo(left.sx, left.sy)
      ctx.lineTo(right.sx, right.sy)
      ctx.stroke()
    }
    if (!u.locked) {
      const pull = project(cam, freeX - dw * 0.16, freeY, z0 + dh * 0.46)
      ctx.fillStyle = u.status === "makeReady" ? "#8d6b45" : "#e0b03a"
      ctx.fillRect(pull.sx, pull.sy, Math.max(2, cam.scale * 0.1), Math.max(5, cam.scale * 0.32))
    }
    if (u.locked) {
      const latch = project(cam, freeX - dw * 0.12, freeY, z0 + dh * 0.42)
      ctx.fillStyle = "#8d3a32"
      ctx.fillRect(latch.sx - 1, latch.sy, Math.max(3, cam.scale * 0.22), Math.max(7, cam.scale * 0.5))
    } else if (u.behind) {
      const tag = project(cam, (hingeX + freeX) / 2, (yy + freeY) / 2, z0 + dh + 0.8)
      label(ctx, cam, tag.sx, tag.sy, "LATE", 0.8, CREAM, "#8d3a32")
    }
    if (u.number && (cam.scale >= 5 || u.id === shownId)) plate(ctx, cam, num.sx, num.sy, u.number, u.status === "occupied" ? CREAM : INK, u.status === "occupied" ? INK : CREAM)
  }
}

function drawQueue(ctx: CanvasRenderingContext2D, cam: Camera, world: World) {
  world.tasks.forEach((task, index) => {
    let x = 0
    let y = 0
    let z = 2.6
    if (task.targetId === "light") {
      x = L.light.x
      y = L.light.y
    } else if (task.targetId === "hall") {
      x = L.building.x + 12
      y = L.building.y + L.building.d
      z = 9.4
    } else if (task.targetId === "keypad" || task.targetId === "camera") {
      x = 30
      y = 16
      z = 3.4
    } else if (task.kind === "recover" || task.targetId === "cart") {
      const cart = world.carts.find((c) => c.phase === "stray")
      if (!cart) return
      x = cart.x
      y = cart.y
      z = 3.4
    } else if (task.kind === "service") {
      x = 86
      y = 52
      z = 6
    } else {
      const unit = world.units.find((u) => u.id === task.targetId)
      if (!unit) return
      if ((world.view === "cedar") !== (unit.site === "cedar")) return
      x = unit.x + unit.w / 2
      y = unit.y
      z = (unit.z || 0) + 3.2
    }
    const p = project(cam, x, y, z)
    label(ctx, cam, p.sx, p.sy - 16, String(index + 1), 1.2, CREAM, "#245f96")
  })
}

function plate(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  sx: number,
  sy: number,
  text: string,
  fill: string,
  paper: string,
) {
  const px = Math.max(9, cam.scale * 0.95)
  ctx.font = `600 ${px}px Outfit, sans-serif`
  const w = ctx.measureText(text).width + px * 0.7
  const h = px + 4
  ctx.fillStyle = paper
  ctx.strokeStyle = "rgba(28,40,51,0.35)"
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.roundRect(sx - w / 2, sy - h / 2, w, h, 3)
  ctx.fill()
  ctx.stroke()
  label(ctx, cam, sx, sy, text, 0.95, fill)
}

function label(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  sx: number,
  sy: number,
  text: string,
  size: number,
  fill: string,
  halo?: string,
) {
  const px = Math.max(9, cam.scale * size)
  ctx.font = `600 ${px}px Outfit, sans-serif`
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"
  if (halo) {
    ctx.lineWidth = 3
    ctx.strokeStyle = halo
    ctx.strokeText(text, sx, sy)
  }
  ctx.fillStyle = fill
  ctx.fillText(text, sx, sy)
}

function footprint(ctx: CanvasRenderingContext2D, cam: Camera, x: number, y: number, w: number, d: number, color: string, dash: boolean) {
  const pts = [project(cam, x, y, 0.15), project(cam, x + w, y, 0.15), project(cam, x + w, y + d, 0.15), project(cam, x, y + d, 0.15)]
  ctx.beginPath()
  ctx.moveTo(pts[0]!.sx, pts[0]!.sy)
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i]!.sx, pts[i]!.sy)
  ctx.closePath()
  ctx.setLineDash(dash ? [5, 4] : [])
  ctx.strokeStyle = color
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.setLineDash([])
}

function fence(ctx: CanvasRenderingContext2D, cam: Camera, x1: number, y1: number, x2: number, y2: number) {
  const a = project(cam, x1, y1, 0)
  const b = project(cam, x2, y2, 0)
  const a2 = project(cam, x1, y1, 2.4)
  const b2 = project(cam, x2, y2, 2.4)
  ctx.strokeStyle = "rgba(36,48,58,0.55)"
  ctx.lineWidth = Math.max(1, cam.scale * 0.1)
  ctx.beginPath()
  ctx.moveTo(a.sx, a.sy)
  ctx.lineTo(b.sx, b.sy)
  ctx.moveTo(a2.sx, a2.sy)
  ctx.lineTo(b2.sx, b2.sy)
  const mid = project(cam, (x1 + x2) / 2, (y1 + y2) / 2, 1.2)
  const mid0 = project(cam, (x1 + x2) / 2, (y1 + y2) / 2, 0)
  ctx.moveTo(mid0.sx, mid0.sy)
  ctx.lineTo(project(cam, (x1 + x2) / 2, (y1 + y2) / 2, 2.4).sx, mid.sy - cam.scale * 0.4)
  ctx.stroke()
  const posts = 4
  for (let i = 0; i <= posts; i++) {
    const t = i / posts
    const px = x1 + (x2 - x1) * t
    const py = y1 + (y2 - y1) * t
    const foot = project(cam, px, py, 0)
    const cap = project(cam, px, py, 2.5)
    ctx.strokeStyle = "#5c6670"
    ctx.lineWidth = Math.max(1.5, cam.scale * 0.14)
    ctx.beginPath()
    ctx.moveTo(foot.sx, foot.sy)
    ctx.lineTo(cap.sx, cap.sy)
    ctx.stroke()
  }
}

function tree(ctx: CanvasRenderingContext2D, cam: Camera, x: number, y: number, now: number) {
  const sway = Math.sin(now * 0.7 + x * 0.2) * cam.scale * 0.35
  const foot = project(cam, x, y, 0)
  const top = project(cam, x, y, 6.2)
  ctx.strokeStyle = "#4d4030"
  ctx.lineWidth = Math.max(2, cam.scale * 0.28)
  ctx.beginPath()
  ctx.moveTo(foot.sx, foot.sy)
  ctx.lineTo(top.sx + sway * 0.3, top.sy)
  ctx.stroke()
  ctx.fillStyle = "rgba(28,40,51,0.12)"
  ctx.beginPath()
  ctx.ellipse(foot.sx, foot.sy, cam.scale * 1.1, cam.scale * 0.4, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = "#4f6840"
  ctx.beginPath()
  ctx.ellipse(top.sx + sway, top.sy, cam.scale * 2.3, cam.scale * 1.25, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = "#6e8654"
  ctx.beginPath()
  ctx.ellipse(top.sx - cam.scale * 0.45 + sway, top.sy - cam.scale * 0.35, cam.scale * 1.35, cam.scale * 0.75, 0, 0, Math.PI * 2)
  ctx.fill()
}

let shownId: string | null = null

function drawUnit(ctx: CanvasRenderingContext2D, cam: Camera, u: Unit) {
  const h = u.status === "constructing" ? 0.4 + u.h * Math.max(0.08, u.progress) : u.h
  const ghost = u.status === "constructing" && u.progress < 0.35
  if (ghost) {
    ground(ctx, cam, u.x, u.y, u.w, u.d, "rgba(196,146,42,0.28)")
    footprint(ctx, cam, u.x, u.y, u.w, u.d, "#c4922a", true)
    return
  }
  const base = u.z || 0
  const top = u.climate ? "#6f9aa6" : u.status === "uncommissioned" ? "#b7bec6" : u.floor === 2 ? "#9aa7b2" : ROOF
  prism(ctx, cam, u.x, u.y, base, u.w, u.d, h, top, u.climate ? "#d5e6ea" : WALL_S, u.climate ? "#b7d0d6" : WALL_E)
  ctx.strokeStyle = "rgba(28,40,51,0.18)"
  ctx.lineWidth = 1
  ctx.beginPath()
  const r0 = project(cam, u.x + 0.4, u.y + u.d * 0.35, base + h + 0.05)
  const r1 = project(cam, u.x + u.w - 0.4, u.y + u.d * 0.35, base + h + 0.05)
  ctx.moveTo(r0.sx, r0.sy)
  ctx.lineTo(r1.sx, r1.sy)
  ctx.stroke()
  if (u.progress > 0.45 || u.status !== "constructing") drawDoor(ctx, cam, u, u.door)
  if (u.status === "makeReady") drawMess(ctx, cam, u)
}

function drawMess(ctx: CanvasRenderingContext2D, cam: Camera, u: Unit) {
  const tidy = u.progress
  const z = u.z || 0
  if (tidy < 0.34) {
    prism(ctx, cam, u.x + 1.1, u.y + u.d - 1.6, z, 1.5, 1.3, 1.1, "#c4a574", "#b08960", "#8d6b45")
    prism(ctx, cam, u.x + u.w - 2.8, u.y + 1.4, z, 1.8, 1.2, 0.7, "#d7d1c6", "#c9c2b6", "#b7b0a4")
  } else if (tidy < 0.67) {
    prism(ctx, cam, u.x + u.w / 2 - 0.5, u.y + u.d - 1.2, z, 1.1, 0.8, 0.25, "#cfc6b8", "#b7aea0", "#a3988c")
  }
  const stage = tidy < 0.34 ? "Haul out" : tidy < 0.67 ? "Sweep" : "Door check"
  const p = project(cam, u.x + u.w / 2, u.y + u.d / 2, z + u.h + 1.3)
  label(ctx, cam, p.sx, p.sy, stage, 1.05, INK, CREAM)
}

function person(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  x: number,
  y: number,
  fill: string,
  working: boolean,
  walking: boolean,
  now: number,
  prop: "broom" | "spark" | null,
) {
  const s = Math.max(cam.scale, 1.8)
  const cycle = walking ? Math.sin(now * 9) : working ? Math.sin(now * 7) : Math.sin(now * 1.5) * 0.15
  const lift = walking ? Math.abs(Math.sin(now * 9)) : working ? Math.abs(Math.sin(now * 7)) * 0.45 : 0.15
  const bob = -lift * Math.max(1.6, s * 0.32)
  const step = cycle * Math.max(3.2, s * 0.85)
  const lean = walking ? Math.max(1.4, s * 0.28) : 0
  const feet = project(cam, x, y, 0)
  ctx.fillStyle = "rgba(28,40,51,0.16)"
  ctx.beginPath()
  ctx.ellipse(feet.sx, feet.sy, s * 0.95, s * 0.38, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.strokeStyle = "#2a241c"
  ctx.lineWidth = Math.max(2, s * 0.22)
  ctx.lineCap = "round"
  ctx.beginPath()
  ctx.moveTo(feet.sx - s * 0.15, feet.sy - s * 0.55 + bob)
  ctx.lineTo(feet.sx - s * 0.15 + step, feet.sy + s * 0.02)
  ctx.moveTo(feet.sx + s * 0.15, feet.sy - s * 0.55 + bob)
  ctx.lineTo(feet.sx + s * 0.15 - step, feet.sy + s * 0.02)
  ctx.stroke()
  const hip = project(cam, x, y, 2.1)
  const chest = project(cam, x, y, 3.6)
  ctx.strokeStyle = fill
  ctx.lineWidth = Math.max(4, s * 0.85)
  ctx.beginPath()
  ctx.moveTo(hip.sx + lean * 0.3, hip.sy + bob)
  ctx.lineTo(chest.sx + lean, chest.sy + bob)
  ctx.stroke()
  const head = project(cam, x, y, 4.7)
  ctx.fillStyle = "#f0d2b8"
  ctx.beginPath()
  ctx.arc(head.sx + lean, head.sy + bob, Math.max(2.8, s * 0.42), 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = fill
  ctx.beginPath()
  ctx.ellipse(head.sx + lean, head.sy - s * 0.3 + bob, s * 0.44, s * 0.18, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = INK
  ctx.beginPath()
  ctx.arc(head.sx + lean + s * 0.12, head.sy + bob, Math.max(1, s * 0.08), 0, Math.PI * 2)
  ctx.fill()
  ctx.strokeStyle = fill
  ctx.lineWidth = Math.max(2, s * 0.2)
  ctx.beginPath()
  ctx.moveTo(chest.sx + lean, chest.sy + bob)
  ctx.lineTo(chest.sx + lean - s * 0.55 - step * 0.55, chest.sy + s * 0.62 + bob)
  ctx.moveTo(chest.sx + lean, chest.sy + bob)
  ctx.lineTo(chest.sx + lean + s * 0.55 + step * 0.55, chest.sy + s * 0.62 + bob)
  ctx.stroke()
  if (working && prop === "broom") {
    const sweep = Math.sin(now * 7)
    ctx.strokeStyle = "#8d6b45"
    ctx.lineWidth = Math.max(2, s * 0.16)
    ctx.beginPath()
    ctx.moveTo(chest.sx + lean + sweep * s * 0.4, chest.sy + bob)
    ctx.lineTo(feet.sx + sweep * Math.max(8, s * 1.6), feet.sy)
    ctx.stroke()
    ctx.fillStyle = "rgba(90,80,60,0.35)"
    ctx.beginPath()
    ctx.ellipse(feet.sx + sweep * Math.max(6, s * 1.2), feet.sy, s * 0.85, s * 0.32, 0, 0, Math.PI * 2)
    ctx.fill()
  } else if (working && prop === "spark") {
    const hot = Math.sin(now * 14) > 0
    ctx.fillStyle = hot ? "#f3e7b8" : "#c4922a"
    ctx.beginPath()
    ctx.arc(chest.sx + lean + s * 0.95, chest.sy + bob, Math.max(2, s * 0.22), 0, Math.PI * 2)
    ctx.fill()
    ctx.globalAlpha = hot ? 0.45 : 0.15
    ctx.beginPath()
    ctx.arc(chest.sx + lean + s * 0.95, chest.sy + bob, Math.max(4, s * 0.45), 0, Math.PI * 2)
    ctx.fill()
    ctx.globalAlpha = 1
  }
}

function wheel(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  x: number,
  y: number,
  z: number,
  now: number,
  moving: boolean,
) {
  const p = project(cam, x, y, z)
  const rx = Math.max(2.2, cam.scale * 0.26)
  const ry = Math.max(1.15, rx * 0.48)
  ctx.fillStyle = "#1c2833"
  ctx.beginPath()
  ctx.ellipse(p.sx, p.sy, rx, ry, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = "#9aa4ad"
  ctx.beginPath()
  ctx.ellipse(p.sx, p.sy, rx * 0.34, ry * 0.34, 0, 0, Math.PI * 2)
  ctx.fill()
  if (!moving) return
  const a = now * 9
  ctx.strokeStyle = "#e7eef2"
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.moveTo(p.sx + Math.cos(a) * rx * 0.72, p.sy + Math.sin(a) * ry * 0.72)
  ctx.lineTo(p.sx - Math.cos(a) * rx * 0.72, p.sy - Math.sin(a) * ry * 0.72)
  ctx.stroke()
}

function cartSprite(ctx: CanvasRenderingContext2D, cam: Camera, x: number, y: number, now: number, rolling: boolean) {
  const hop = rolling ? Math.abs(Math.sin(now * 8)) * Math.max(0.8, cam.scale * 0.15) : 0
  ctx.save()
  ctx.translate(0, -hop)
  prism(ctx, cam, x, y, 0.45, 1.7, 2.4, 0.85, "#e4e7ea", "#c5cacf", "#b0b6bc")
  const handleA = project(cam, x + 0.85, y + 2.3, 0.9)
  const handleB = project(cam, x + 0.85, y + 2.3, 3.2)
  ctx.strokeStyle = INK
  ctx.lineWidth = Math.max(1.5, cam.scale * 0.16)
  ctx.beginPath()
  ctx.moveTo(handleA.sx, handleA.sy)
  ctx.lineTo(handleB.sx, handleB.sy)
  ctx.stroke()
  for (const [wx, wy] of [
    [x + 0.3, y + 0.4],
    [x + 1.4, y + 0.4],
    [x + 0.3, y + 2],
    [x + 1.4, y + 2],
  ] as const) {
    wheel(ctx, cam, wx, wy, 0.28, now, rolling)
  }
  ctx.restore()
}

function vehicle(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  x: number,
  y: number,
  facing: "x" | "y",
  fill: string,
  kind: "sedan" | "pickup" | "van",
  now = 0,
  moving = false,
) {
  const len = kind === "van" ? 8.4 : kind === "pickup" ? 7.8 : 6.6
  const wid = 3.2
  const h = kind === "van" ? 3.2 : 2.35
  const w = facing === "x" ? len : wid
  const d = facing === "y" ? len : wid
  const x0 = x - w / 2
  const y0 = y - d / 2
  const hop = moving ? Math.abs(Math.sin(now * 12)) * Math.max(0.7, cam.scale * 0.14) : 0
  ctx.save()
  ctx.translate(0, -hop)
  ctx.fillStyle = "rgba(28,40,51,0.2)"
  const sh = project(cam, x, y, 0)
  ctx.beginPath()
  ctx.ellipse(sh.sx, sh.sy + 2, cam.scale * (kind === "van" ? 2.4 : 1.9), cam.scale * 0.7, 0, 0, Math.PI * 2)
  ctx.fill()
  prism(ctx, cam, x0, y0, 0.45, w, d, h * 0.55, fill, fill, fill)
  const cabW = facing === "x" ? w * 0.38 : w
  const cabD = facing === "y" ? d * 0.38 : d
  prism(ctx, cam, x0 + (facing === "x" ? w * 0.55 : 0.15), y0 + (facing === "y" ? d * 0.55 : 0.15), 0.45, cabW, cabD, h, "#d7e4e2", fill, fill)
  for (const [wx, wy] of [
    [x0 + 0.6, y0 + 0.5],
    [x0 + w - 1.1, y0 + 0.5],
    [x0 + 0.6, y0 + d - 0.8],
    [x0 + w - 1.1, y0 + d - 0.8],
  ] as const) {
    wheel(ctx, cam, wx, wy, 0.3, now, moving)
  }
  if (moving) {
    const puff = project(cam, facing === "x" ? x - w * 0.35 : x, facing === "y" ? y - d * 0.35 : y, 0.4)
    ctx.fillStyle = `rgba(90,84,74,${0.12 + Math.abs(Math.sin(now * 8)) * 0.18})`
    ctx.beginPath()
    ctx.ellipse(puff.sx, puff.sy, cam.scale * 0.7, cam.scale * 0.28, 0, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.restore()
}

function drawHvac(ctx: CanvasRenderingContext2D, cam: Camera, world: World, now: number) {
  if (world.hvac === "none") return
  const x = 88
  const y = 40
  const w = 5.6
  const d = 4.4
  const h = world.hvac === "live" || world.hvacProgress >= 1 ? 3.3 : 0.5 + 2.8 * world.hvacProgress
  const shell = world.hvac === "live" ? "#d5e7ea" : "#c5ced4"
  prism(ctx, cam, x, y, 0, w, d, h, shell, "#8aa0a8", "#738890")
  const top = project(cam, x + w / 2, y + d / 2, h + 0.15)
  if (world.hvac === "live") {
    ctx.save()
    ctx.translate(top.sx, top.sy)
    ctx.rotate(now * 2.4)
    ctx.strokeStyle = "#1e3a4c"
    ctx.lineWidth = Math.max(2, cam.scale * 0.16)
    ctx.beginPath()
    ctx.moveTo(-cam.scale * 0.9, 0)
    ctx.lineTo(cam.scale * 0.9, 0)
    ctx.moveTo(0, -cam.scale * 0.42)
    ctx.lineTo(0, cam.scale * 0.42)
    ctx.stroke()
    ctx.restore()
    return
  }
  label(ctx, cam, top.sx, top.sy - Math.max(10, cam.scale * 0.8), world.hvacProgress >= 1 ? "READY" : "HVAC", 1, INK, CREAM)
}

function storyHeight(w: World): number {
  const base = L.building.h
  if (w.upperOpen || w.floor2 === "built") return base + 8.6
  if (w.floor2 === "building") return base + 8.6 * Math.max(0.08, w.floorProgress)
  return base
}

function drawElevator(ctx: CanvasRenderingContext2D, cam: Camera, world: World, now: number) {
  if (world.elevator === "none" && !world.upperOpen) return
  const x = 89
  const y = 50
  const w = 3.4
  const d = 5
  const full = storyHeight(world)
  const h = world.elevator === "building" && world.elevatorProgress < 1 ? Math.max(2, full * world.elevatorProgress) : full
  const shell = world.elevWear === "down" ? "#c4b2a4" : world.elevWear === "due" ? "#e4d2a4" : "#d7dee3"
  prism(ctx, cam, x, y, 0, w, d, h, shell, "#8ea0aa", "#73828c")
  if ((world.upperOpen || world.elevator === "built") && !(world.elevWear === "down" && world.cabs < 2)) {
    if (world.elevWear !== "down") {
      const cabZ = world.upperOpen ? 1.2 + world.cab * Math.max(2, h - 4) : 1.2
      prism(ctx, cam, x + 0.45, y + 0.45, cabZ, w - 0.9, d - 0.9, 2.4, "#e7eef2", "#c5d0d6", "#b7c4cb")
      const lit = project(cam, x + w * 0.72, y + d * 0.2, cabZ + 1.7)
      ctx.fillStyle = Math.sin(now * 5) > 0 ? "#f3e7b8" : "#8a93a0"
      ctx.beginPath()
      ctx.arc(lit.sx, lit.sy, Math.max(1.6, cam.scale * 0.16), 0, Math.PI * 2)
      ctx.fill()
    } else {
      prism(ctx, cam, x + 0.45, y + 0.45, 1.2, w - 0.9, d - 0.9, 2.4, "#efe4d8", "#d7c6b4", "#cbb8a4")
    }
  } else if (world.elevWear === "down") {
    prism(ctx, cam, x + 0.45, y + 0.45, 1.2, w - 0.9, d - 0.9, 2.4, "#efe4d8", "#d7c6b4", "#cbb8a4")
  }
  const tag = project(cam, x + w / 2, y + d, h + 0.8)
  const text = world.elevWear === "down" ? "OUT" : world.elevWear === "due" ? "DUE" : world.upperOpen ? (world.elevatorQueue > 0.3 && world.cabs < 2 ? "WAIT" : "CAB") : world.elevatorProgress >= 1 || world.elevator === "built" ? "CAB" : "LIFT"
  label(ctx, cam, tag.sx, tag.sy, text, 0.9, INK, CREAM)
  if (world.tasks.some((t) => t.kind === "service" && t.done > 0)) {
    const panel = project(cam, x + w / 2, y + d, 2.2)
    ctx.fillStyle = "#c4922a"
    ctx.fillRect(panel.sx, panel.sy, Math.max(4, cam.scale * 0.35), Math.max(6, cam.scale * 0.7))
  }
  if (world.secondCab === "none") return
  const sx = 136
  const sy = 46
  const sh = world.secondCab === "building" && world.secondProgress < 1 ? Math.max(2, full * world.secondProgress) : full
  prism(ctx, cam, sx, sy, 0, w, d, sh, "#d7dee3", "#8ea0aa", "#73828c")
  if (world.secondCab === "built") {
    const cabZ = world.upperOpen ? 1.2 + ((world.cab + 0.45) % 1) * Math.max(2, sh - 4) : 1.2
    prism(ctx, cam, sx + 0.45, sy + 0.45, cabZ, w - 0.9, d - 0.9, 2.4, "#e7eef2", "#c5d0d6", "#b7c4cb")
    const lit2 = project(cam, sx + w * 0.72, sy + d * 0.2, cabZ + 1.7)
    ctx.fillStyle = Math.sin(now * 5 + 1.4) > 0 ? "#f3e7b8" : "#8a93a0"
    ctx.beginPath()
    ctx.arc(lit2.sx, lit2.sy, Math.max(1.6, cam.scale * 0.16), 0, Math.PI * 2)
    ctx.fill()
  }
  const tag2 = project(cam, sx + w / 2, sy + d, sh + 0.8)
  const text2 = world.secondCab === "building" && world.secondProgress < 1 ? `${Math.round(world.secondProgress * 100)}%` : "CAB 2"
  label(ctx, cam, tag2.sx, tag2.sy, text2, 0.9, INK, CREAM)
}

function drawBuilding(ctx: CanvasRenderingContext2D, cam: Camera, w: World) {
  const b = L.building
  const bh = storyHeight(w)
  const lift = Math.max(0, Math.min(1, w.roof))
  if (lift > 0.18) {
    ctx.save()
    ctx.globalAlpha = Math.min(1, (lift - 0.18) / 0.42)
    drawInterior(ctx, cam, w, b)
    ctx.restore()
  }
  if (lift < 0.88) {
    ctx.save()
    ctx.globalAlpha = lift < 0.18 ? 1 : Math.max(0, 1 - (lift - 0.18) / 0.55)
    prism(ctx, cam, b.x, b.y, 0, b.w, b.d, bh, "#8b939b", "#d9d0c2", "#c9bfae")
    const p = project(cam, b.x + b.w * 0.45, b.y + b.d * 0.72, bh * 0.55)
    label(ctx, cam, p.sx, p.sy, "INDOOR", 1.4, CREAM, INK)
    if (cam.scale >= 5 && w.hvac === "live") label(ctx, cam, p.sx, p.sy + Math.max(14, cam.scale * 1.3), "CLIMATE", 0.95, "#d5eef2", "#1e3a4c")
    if (cam.scale >= 5 && w.upperOpen) label(ctx, cam, p.sx, p.sy + Math.max(28, cam.scale * 2.4), "FLOOR 2", 0.9, CREAM, INK)
    const door = project(cam, b.x - 0.05, b.y + 28, 2.2)
    ctx.fillStyle = "#1e3a4c"
    ctx.fillRect(door.sx - cam.scale * 1.1, door.sy - cam.scale * 1.4, cam.scale * 2.2, cam.scale * 2.2)
    ctx.restore()
  }
  if (lift > 0.02 && lift < 0.96) {
    ctx.save()
    ctx.globalAlpha = Math.max(0.12, 1 - lift)
    prism(ctx, cam, b.x, b.y, bh - 0.35 + lift * 6.5, b.w, b.d, 0.45, ROOF, ROOF, ROOF)
    ctx.restore()
  }
}

function drawInterior(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  w: World,
  b: { x: number; y: number; w: number; d: number },
) {
  ground(ctx, cam, b.x, b.y, b.w, b.d, "#ece7de")
  poly(
    ctx,
    [
      project(cam, b.x, b.y, 0),
      project(cam, b.x + b.w, b.y, 0),
      project(cam, b.x + b.w, b.y, 3.2),
      project(cam, b.x, b.y, 3.2),
    ],
    "#e4dccd",
  )
  poly(
    ctx,
    [
      project(cam, b.x, b.y, 0),
      project(cam, b.x, b.y + b.d, 0),
      project(cam, b.x, b.y + b.d, 3.2),
      project(cam, b.x, b.y, 3.2),
    ],
    "#d5cbbd",
  )
  const hall = L.hall
  ground(ctx, cam, hall.x, hall.y, hall.w, hall.d, w.hallDark ? "#2a3036" : w.hvac === "live" ? "#d5e7ea" : "#f7f4ee")
  prism(ctx, cam, hall.x + hall.w / 2, hall.y + 3, 0, 0.6, 0.6, 4.2, "#2a3238", "#2a3238", "#22282d")
  if (!w.hallDark) prism(ctx, cam, hall.x + hall.w / 2 - 0.3, hall.y + 2.7, 4.2, 1.2, 1.1, 0.35, "#f3e7b8", "#f3e7b8", "#e4d7a4")
  if (w.hallDark && w.roof > 0.45) {
    const dark = project(cam, hall.x + hall.w / 2, hall.y + 4, 6)
    label(ctx, cam, dark.sx, dark.sy, "DARK", 0.9, CREAM, "#8d3a32")
  }
  ground(ctx, cam, L.vestibule.x, L.vestibule.y, L.vestibule.w, L.vestibule.d, "#e7e2d8")
  const units = w.units.filter((u) => u.access === "interior").sort((a, c) => a.x - c.x)
  for (const u of units) drawUnit(ctx, cam, u)
}

function workProp(world: World, m: { working: boolean; role: string }): "broom" | "spark" | null {
  if (!m.working) return null
  const task = world.tasks.find((t) => t.assignee === m.role)
  if (!task) return null
  if (task.kind === "makeReady") return "broom"
  if (task.kind === "repair" || task.kind === "service") return "spark"
  return null
}

function drawCoverage(ctx: CanvasRenderingContext2D, cam: Camera, world: World, now: number) {
  const origin = project(cam, 29.7, 12.7, 3.6)
  const swing = world.cameraFault ? 0 : Math.sin(now * 0.7) * 3
  const left = project(cam, 16, 16, 0)
  const right = project(cam, 36 + swing * 0.2, 30, 0)
  ctx.save()
  ctx.globalAlpha = world.cameraFault ? 0.14 : 0.18
  ctx.fillStyle = world.cameraFault ? "#8d3a32" : "#7ec8d4"
  ctx.beginPath()
  ctx.moveTo(origin.sx, origin.sy)
  ctx.lineTo(left.sx, left.sy)
  ctx.lineTo(right.sx, right.sy)
  ctx.closePath()
  ctx.fill()
  ctx.restore()
}

function lane(ctx: CanvasRenderingContext2D, cam: Camera, x: number, y: number, along: "x" | "y", count: number) {
  ctx.strokeStyle = "rgba(217,211,195,0.55)"
  ctx.lineWidth = Math.max(1, cam.scale * 0.12)
  ctx.setLineDash([cam.scale * 0.7, cam.scale * 0.55])
  ctx.beginPath()
  for (let i = 0; i < count; i++) {
    const t = i / count
    const ax = along === "x" ? x + t * 18 : x
    const ay = along === "y" ? y + t * 10 : y
    const a = project(cam, ax, ay, 0.08)
    const b = project(cam, ax + (along === "x" ? 2.2 : 0), ay + (along === "y" ? 1.6 : 0), 0.08)
    ctx.moveTo(a.sx, a.sy)
    ctx.lineTo(b.sx, b.sy)
  }
  ctx.stroke()
  ctx.setLineDash([])
}

function drawDock(ctx: CanvasRenderingContext2D, cam: Camera, open: number) {
  const y = L.vestibule.y + 5
  const leaf = 3.4
  const slide = leaf * Math.max(0, Math.min(1, open))
  prism(ctx, cam, L.building.x - 0.35, y - slide, 0, 0.4, leaf, 6.4, "#d7d0c4", "#c9c2b4", "#b7b0a2")
  prism(ctx, cam, L.building.x - 0.35, y + leaf + slide, 0, 0.4, leaf, 6.4, "#d7d0c4", "#c9c2b4", "#b7b0a2")
}

function drawCedar(ctx: CanvasRenderingContext2D, cam: Camera, world: World) {
  ground(ctx, cam, 2, 8, 78, 42, YARD)
  ground(ctx, cam, -4, 0, 88, 10, ASPHALT)
  ground(ctx, cam, 8, 16, 68, 8, ASPHALT)
  const street = project(cam, 40, 4, 0.2)
  label(ctx, cam, street.sx, street.sy, "CEDAR COURT", 1.5, "#d9d3c3")
  fence(ctx, cam, 6, 12, 78, 12)
  fence(ctx, cam, 78, 12, 78, 48)
  fence(ctx, cam, 78, 48, 6, 48)
  fence(ctx, cam, 6, 48, 6, 12)
  prism(ctx, cam, 8, 12, 0, 10, 6, 5.2, "#6e767e", WALL, "#e3dacb")
  const office = project(cam, 13, 18, 5.4)
  label(ctx, cam, office.sx, office.sy, "OFFICE", 0.9, INK, CREAM)
  const spots = [
    { number: "C5", x: 50 },
    { number: "C6", x: 59 },
  ]
  for (const spot of spots) {
    if (world.units.some((unit) => unit.number === spot.number)) continue
    footprint(ctx, cam, spot.x, 22, 7.2, 14, "rgba(28,40,51,0.35)", true)
  }
  const pads = project(cam, 58, 20, 0.4)
  if (!world.units.some((unit) => unit.number === "C5")) label(ctx, cam, pads.sx, pads.sy, "ADD", 0.9, INK, CREAM)
  let tagged = false
  for (const unit of world.units) {
    if (unit.site !== "cedar") continue
    drawUnit(ctx, cam, unit)
    if (tagged || (unit.status !== "constructing" && unit.status !== "uncommissioned")) continue
    tagged = true
    const p = project(cam, unit.x + unit.w / 2, unit.y - 1.2, unit.h + 1.4)
    const text = unit.status === "constructing" ? `${Math.round(unit.progress * 100)}%` : "Commission"
    label(ctx, cam, p.sx, p.sy, text, 1.05, INK, CREAM)
  }
}

export function drawWorld(ctx: CanvasRenderingContext2D, world: World, cam: Camera, now: number, reduced: boolean) {
  shownId = world.selectedId
  const { width, height } = ctx.canvas
  const dpr = ctx.getTransform().a || 1
  ctx.clearRect(0, 0, width / dpr, height / dpr)
  const hour = hourOf(world.day)
  const grade = gradeOf(hour)
  const sky = ctx.createLinearGradient(0, 0, 0, height / dpr)
  sky.addColorStop(0, grade.top)
  sky.addColorStop(0.45, grade.mid)
  sky.addColorStop(1, grade.bot)
  ctx.fillStyle = sky
  ctx.fillRect(0, 0, width / dpr, height / dpr)
  if (!reduced) {
    clouds(ctx, width / dpr, now, hour >= 19 || hour < 5)
    if (hour >= 6 && hour < 19) birds(ctx, width / dpr, now)
    skyBody(ctx, width / dpr, height / dpr, hour)
  }
  if (world.view === "cedar") {
    drawCedar(ctx, cam, world)
    nightWash(ctx, width / dpr, height / dpr, grade.wash)
    return
  }

  ground(ctx, cam, L.yard.x, L.yard.y, L.yard.w, L.yard.d, YARD)
  ground(ctx, cam, L.street.x, L.street.y, L.street.w, L.street.d, ASPHALT)
  ground(ctx, cam, L.aisle.x, L.aisle.y, L.aisle.w, L.aisle.d, ASPHALT)
  ground(ctx, cam, L.spur.x, L.spur.y, L.spur.w, L.spur.d, ASPHALT)
  ground(ctx, cam, L.expAisle.x, L.expAisle.y, L.expAisle.w, L.expAisle.d, ASPHALT)
  ground(ctx, cam, L.connector.x, L.connector.y, L.connector.w, L.connector.d, ASPHALT)
  ground(ctx, cam, 66, 18, 26, 32, "#4a4f55")
  ground(ctx, cam, 36, 30, 22, 8, CONCRETE)
  lane(ctx, cam, 20, 5, "x", 8)
  lane(ctx, cam, 40, 54, "x", 4)

  const street = project(cam, 70, 5, 0.2)
  label(ctx, cam, street.sx, street.sy, "MAPLE STREET", 1.5, "#d9d3c3")

  fence(ctx, cam, 8, 10, 16, 10)
  fence(ctx, cam, 28, 10, 136, 10)
  fence(ctx, cam, 136, 10, 136, 98)
  fence(ctx, cam, 136, 98, 8, 98)
  fence(ctx, cam, 8, 98, 8, 10)

  tree(ctx, cam, 12, 20, reduced ? 0 : now)
  tree(ctx, cam, 128, 12, reduced ? 0 : now)
  tree(ctx, cam, 18, 92, reduced ? 0 : now)

  for (const pad of world.pads) {
    if (world.units.some((u) => u.padId === pad.id)) continue
    const picked = world.buildPick.includes(pad.id)
    if (picked && world.sheet === "build") {
      ctx.globalAlpha = 0.55
      prism(ctx, cam, pad.x, pad.y, 0, pad.w, pad.d, 7, ROOF, WALL_S, WALL_E)
      ctx.globalAlpha = 1
    }
    footprint(ctx, cam, pad.x, pad.y, pad.w, pad.d, picked ? "#c4922a" : "rgba(28,40,51,0.35)", true)
  }
  const expLabel = project(cam, 36, 78, 0.4)
  if (world.lot !== "empty" && !world.units.some((u) => u.padId)) label(ctx, cam, expLabel.sx, expLabel.sy, "EXPANSION", 1.3, INK, CREAM)

  const g = world.gate
  const armA = project(cam, 16, 12, 2.3)
  const armB = project(cam, 16 + 11 * (1 - g), 12, 2.3 + 5.5 * g)
  ctx.strokeStyle = "#1c2833"
  ctx.lineWidth = Math.max(5, cam.scale * 0.42)
  ctx.lineCap = "round"
  ctx.beginPath()
  ctx.moveTo(armA.sx, armA.sy)
  ctx.lineTo(armB.sx, armB.sy)
  ctx.stroke()
  ctx.strokeStyle = "#e0b03a"
  ctx.lineWidth = Math.max(3, cam.scale * 0.26)
  ctx.beginPath()
  ctx.moveTo(armA.sx, armA.sy)
  ctx.lineTo(armB.sx, armB.sy)
  ctx.stroke()
  for (let i = 1; i <= 4; i++) {
    const t = i / 5
    ctx.fillStyle = i % 2 === 0 ? "#1c2833" : "#f3e7b8"
    ctx.beginPath()
    ctx.arc(
      armA.sx + (armB.sx - armA.sx) * t,
      armA.sy + (armB.sy - armA.sy) * t,
      Math.max(2, cam.scale * 0.14),
      0,
      Math.PI * 2,
    )
    ctx.fill()
  }
  ctx.fillStyle = "#e0b03a"
  ctx.beginPath()
  ctx.arc(armB.sx, armB.sy, Math.max(3, cam.scale * 0.22), 0, Math.PI * 2)
  ctx.fill()
  prism(ctx, cam, 29.2, 13, 0, 1.3, 1.3, 3.3, "#1e3a4c", "#1e3a4c", "#162c3a")
  const pad = project(cam, 30.1, 14.4, 1.55)
  ctx.fillStyle = world.keypadFault ? "#c4922a" : world.keypad ? (g > 0.35 ? "#3d9a62" : "#2a6b45") : "#5c6a72"
  ctx.fillRect(pad.sx - cam.scale * 0.28, pad.sy - cam.scale * 0.22, Math.max(4, cam.scale * 0.55), Math.max(3, cam.scale * 0.4))
  if (world.keypadFault) {
    const stuck = project(cam, 30.1, 14.4, 3.6)
    label(ctx, cam, stuck.sx, stuck.sy, "STUCK", 0.85, CREAM, "#8a5a12")
  }
  if (world.camera) {
    prism(ctx, cam, 29.35, 12.15, 3.35, 0.85, 0.7, 0.55, "#1c2833", "#1c2833", "#141c22")
    const lens = project(cam, 29.7, 12.7, 3.7)
    const blink = world.cameraFault && (!reduced ? now % 0.8 < 0.4 : true)
    ctx.fillStyle = world.cameraFault ? (blink ? "#c45a4a" : "#5c4038") : "#7ec8d4"
    ctx.beginPath()
    ctx.arc(lens.sx, lens.sy, Math.max(2, cam.scale * 0.16), 0, Math.PI * 2)
    ctx.fill()
    drawCoverage(ctx, cam, world, reduced ? 0 : now)
    if (world.cameraFault) {
      const tag = project(cam, 29.7, 12.7, 5.2)
      label(ctx, cam, tag.sx, tag.sy, "OFFLINE", 0.85, CREAM, "#8d3a32")
    }
  } else if (world.milestones.repaired) {
    footprint(ctx, cam, 16, 14, 16, 14, "rgba(141,58,50,0.55)", true)
    const blind = project(cam, 24, 22, 0.4)
    label(ctx, cam, blind.sx, blind.sy, "BLIND", 0.9, "#8d3a32", CREAM)
  }

  prism(ctx, cam, L.monument.x, L.monument.y, 0, L.monument.w, L.monument.d, L.monument.h, "#1e3a4c", "#1e3a4c", "#162c3a")
  const mon = project(cam, L.monument.x + L.monument.w / 2, L.monument.y + L.monument.d, L.monument.h * 0.62)
  label(ctx, cam, mon.sx, mon.sy, "MAPLE ST", 0.95, CREAM)

  const office = L.office
  prism(ctx, cam, office.x, office.y, 0, office.w, office.d, office.h, "#6e767e", WALL, "#e3dacb")
  drawDoor(ctx, cam, {
    id: "office-door",
    number: "",
    product: "5x10",
    access: "interior",
    x: office.x + 8,
    y: office.y,
    w: 6,
    d: office.d,
    h: office.h,
    door: "s",
    status: "occupied",
    lease: null,
    tenant: null,
    note: null,
    group: null,
    padId: null,
    buildCost: 0,
    progress: 1,
    doorOpen: 0.05,
    climate: false,
    floor: 1,
    z: 0,
  }, "s")
  const off = project(cam, office.x + 12, office.y + office.d, office.h * 0.72)
  label(ctx, cam, off.sx, off.sy, "OFFICE", 1.2, INK, CREAM)
  for (const wx of [office.x + 4, office.x + 15]) {
    const win = project(cam, wx, office.y + office.d, 4.2)
    const night = hour >= 19 || hour < 6
    ctx.globalAlpha = night && !reduced ? 0.72 + Math.sin(now * 1.6 + wx) * 0.28 : 1
    ctx.fillStyle = night ? "#f3e7b8" : "#c5ddd9"
    ctx.fillRect(win.sx - cam.scale * 0.55, win.sy - cam.scale * 0.35, cam.scale * 1.15, cam.scale * 0.7)
    ctx.strokeStyle = "#1e3a4c"
    ctx.lineWidth = 1
    ctx.strokeRect(win.sx - cam.scale * 0.55, win.sy - cam.scale * 0.35, cam.scale * 1.15, cam.scale * 0.7)
    ctx.globalAlpha = 1
  }

  const lampWork = world.tasks.some((t) => t.targetId === "light" && t.done > 0)
  const lampOn = !world.lightFault || (lampWork && (reduced ? false : now % 0.5 < 0.25))
  prism(ctx, cam, L.light.x, L.light.y, 0, 0.7, 0.7, 7.2, "#2a3238", "#2a3238", "#22282d")
  prism(ctx, cam, L.light.x - 0.5, L.light.y - 0.4, 7.2, 1.8, 1.5, 0.7, lampOn ? "#f3e7b8" : "#3a4046", lampOn ? "#f3e7b8" : "#3a4046", "#2c3238")
  if (lampOn) {
    const glow = project(cam, L.light.x, L.light.y, 6.4)
    const pulse = reduced ? 1 : 0.82 + Math.sin(now * 2.4) * 0.18
    ctx.fillStyle = "rgba(243,231,184,0.28)"
    ctx.beginPath()
    ctx.ellipse(glow.sx, glow.sy, cam.scale * 2.6 * pulse, cam.scale * 1.15 * pulse, 0, 0, Math.PI * 2)
    ctx.fill()
  }
  if (world.lightFault) {
    const lp = project(cam, L.light.x, L.light.y, 8.6)
    label(ctx, cam, lp.sx, lp.sy, "OUT", 1, CREAM, "#8d3a32")
  }

  for (const unit of world.units) {
    if (unit.site === "cedar") continue
    if (unit.access === "drive-up") drawUnit(ctx, cam, unit)
  }
  const tagged = new Set<string>()
  for (const unit of world.units) {
    if (unit.site === "cedar") continue
    if (unit.access !== "drive-up") continue
    if (unit.status !== "constructing" && unit.status !== "uncommissioned") continue
    const key = `${unit.group ?? unit.id}:${unit.status}`
    if (tagged.has(key)) continue
    tagged.add(key)
    const mates = world.units.filter((u) => `${u.group ?? u.id}:${u.status}` === key)
    const anchor = mates.reduce((a, b) => (a.x <= b.x ? a : b))
    const p = project(cam, anchor.x + anchor.w / 2, anchor.y - 1.2, (anchor.z || 0) + anchor.h + 1.4)
    const text = anchor.status === "constructing" ? `${Math.round(anchor.progress * 100)}%` : "Commission"
    label(ctx, cam, p.sx, p.sy, text, 1.05, INK, CREAM)
  }

  const bare = world.lot === "empty"
  if (!bare) {
  const canopy = L.canopy
  for (const [px, py] of [
    [canopy.x + 1, canopy.y + 1],
    [canopy.x + canopy.w - 1.5, canopy.y + 1],
    [canopy.x + 1, canopy.y + canopy.d - 1.5],
    [canopy.x + canopy.w - 1.5, canopy.y + canopy.d - 1.5],
  ] as const) {
    prism(ctx, cam, px, py, 0, 0.6, 0.6, canopy.h, "#c4922a", "#c4922a", "#a87a1e")
  }
  ctx.globalAlpha = 0.55
  prism(ctx, cam, canopy.x, canopy.y, canopy.h, canopy.w, canopy.d, 0.35, "#3d6d86", "#3d6d86", "#31586d")
  ctx.globalAlpha = 1
  }

  ground(ctx, cam, L.corral.x, L.corral.y, L.corral.w, L.corral.d, "#b7c0b0")
  for (const cart of world.carts) {
    if (cart.phase === "home" || cart.phase === "return" || cart.phase === "follow" || cart.phase === "stray") {
      cartSprite(ctx, cam, cart.x, cart.y, reduced ? 0 : now, cart.phase === "follow" || cart.phase === "return")
    }
    if (cart.phase === "stray") {
      const tag = project(cam, cart.x, cart.y, 2.2)
      label(ctx, cam, tag.sx, tag.sy, "OUT", 0.9, CREAM, "#8d3a32")
    }
  }

  if (!bare) {
  drawDock(ctx, cam, world.dock)
  drawBuilding(ctx, cam, world)
  if (world.hallDark && world.roof < 0.45) {
    const dark = project(cam, L.building.x + 12, L.building.y + L.building.d, 8)
    label(ctx, cam, dark.sx, dark.sy, "HALL DARK", 0.9, CREAM, "#8d3a32")
  }
  drawQueue(ctx, cam, world)
  drawElevator(ctx, cam, world, reduced ? 0 : now)
  drawHvac(ctx, cam, world, reduced ? 0 : now)
  }

  if (!bare) {
  const u103 = world.units.find((u) => u.number === "103")
  if (u103 && !world.movers.some((m) => m.id === "vcar" && m.visible && Math.hypot(m.x - (u103.x + 3), m.y - (u103.y + u103.d + 4)) < 6)) {
    vehicle(ctx, cam, u103.x + u103.w / 2, u103.y + u103.d + 4.2, "y", "#8e3d32", "pickup")
  }
  vehicle(ctx, cam, 40, 37.2, "x", "#1e3a4c", "sedan")
  }

  const movers = [...world.movers].filter((m) => m.visible)
  movers.sort((a, b) => a.x + a.y - (b.x + b.y))
  for (const m of movers) {
    if (m.kind === "car" && m.vehicle) vehicle(ctx, cam, m.x, m.y, m.facing, m.fill, m.vehicle, reduced ? 0 : now, m.path.length > 0)
    else person(ctx, cam, m.x, m.y, m.fill, m.working, m.path.length > 0, reduced ? 0 : now, workProp(world, m))
    if (m.id === "vperson" && world.visit?.kind === "office" && world.visit.stage >= 1 && world.visit.stage <= 2) {
      const tag = project(cam, m.x, m.y, 6.4)
      label(ctx, cam, tag.sx, tag.sy, "OFFICE", 0.85, CREAM, INK)
    }
    if (m.id === "vperson" && world.visit?.kind === "interior" && world.visit.stage === 3 && !world.visit.cartId) {
      const tag = project(cam, m.x, m.y, 6.2)
      label(ctx, cam, tag.sx, tag.sy, "NO CART", 0.85, CREAM, "#8d3a32")
    }
  }

  if (world.selectedId) {
    const hit = boundsFor(world, world.selectedId)
    if (hit) footprint(ctx, cam, hit.x, hit.y, hit.w, hit.d, CREAM, false)
    if (hit) footprint(ctx, cam, hit.x + 0.15, hit.y + 0.15, hit.w - 0.3, hit.d - 0.3, "#c4922a", false)
  }

  const focus = world.units.find((u) => u.status === "makeReady" && u.site !== "cedar")
  if (focus && !reduced) {
    const pulse = 0.35 + Math.sin(now * 3) * 0.15
    ctx.globalAlpha = 0.35 + pulse * 0.3
    footprint(ctx, cam, focus.x - 0.4, focus.y - 0.4, focus.w + 0.8, focus.d + 0.8, "#c4922a", false)
    ctx.globalAlpha = 1
  } else if (focus) {
    footprint(ctx, cam, focus.x - 0.3, focus.y - 0.3, focus.w + 0.6, focus.d + 0.6, "#c4922a", false)
  }
  nightWash(ctx, width / dpr, height / dpr, grade.wash)
}

interface Bounds {
  id: string
  x: number
  y: number
  w: number
  d: number
  pri: number
}

function boundsFor(world: World, id: string): Bounds | undefined {
  const hits = hitList(world).filter((hit) => hit.id === id)
  if (!hits.length) return undefined
  return hits.reduce((a, b) => (a.w * a.d >= b.w * b.d ? a : b))
}

function hitList(world: World): Bounds[] {
  if (world.view === "cedar") {
    const list = world.units
      .filter((unit) => unit.site === "cedar")
      .map((unit) => ({ id: unit.id, x: unit.x, y: unit.y, w: unit.w, d: unit.d, pri: 6 }))
    if (!world.units.some((unit) => unit.number === "C5")) {
      list.push({ id: "cedar-pad-5", x: 50, y: 22, w: 7.2, d: 14, pri: 9 })
      list.push({ id: "cedar-pad-6", x: 59, y: 22, w: 7.2, d: 14, pri: 9 })
    }
    return list
  }
  const list: Bounds[] = []
  const build = world.sheet === "build"
  for (const unit of world.units) {
    if (unit.site === "cedar") continue
    if (unit.access === "interior" && world.roof < 0.45) continue
    list.push({ id: unit.id, x: unit.x, y: unit.y, w: unit.w, d: unit.d, pri: unit.number === "107" ? 8 : 6 })
  }
  if (build) {
    for (const pad of world.pads) {
      if (world.units.some((u) => u.padId === pad.id)) continue
      list.push({ id: pad.id, x: pad.x, y: pad.y, w: pad.w, d: pad.d, pri: 9 })
    }
  }
  if (world.hvac !== "none") {
    list.push({ id: "building", x: 88, y: 40, w: 5.6, d: 4.4, pri: 8 })
  }
  if (world.elevator !== "none" || world.upperOpen) {
    list.push({ id: "building", x: 88, y: 49, w: 5.2, d: 8, pri: 8 })
  }
  list.push({ id: "light", x: L.light.x - 1.5, y: L.light.y - 1.5, w: 4, d: 4, pri: 7 })
  list.push({ id: "corral", x: L.corral.x, y: L.corral.y, w: L.corral.w, d: L.corral.d, pri: 5 })
  list.push({ id: "gate", x: L.gate.x, y: L.gate.y, w: L.gate.w, d: L.gate.d + 4, pri: 4 })
  list.push({ id: "office", x: L.office.x, y: L.office.y, w: L.office.w, d: L.office.d, pri: 3 })
  if (world.lot !== "empty") list.push({ id: "building", x: L.building.x, y: L.building.y, w: L.building.w, d: L.building.d, pri: 2 })
  return list
}

export function pickId(cam: Camera, sx: number, sy: number, world: World): string | null {
  const p = screenToWorld(cam, sx, sy)
  let best: Bounds | null = null
  let bestArea = Infinity
  for (const hit of hitList(world)) {
    if (p.x < hit.x || p.y < hit.y || p.x > hit.x + hit.w || p.y > hit.y + hit.d) continue
    const area = hit.w * hit.d
    if (!best || hit.pri > best.pri || (hit.pri === best.pri && area < bestArea)) {
      best = hit
      bestArea = area
    }
  }
  return best?.id ?? null
}
