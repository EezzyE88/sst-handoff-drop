import { setHeard } from "@/game/audio"
import { BUILD_COST, CAMERA_COST, CAMERA_DAILY, CART_COST, CART_MAX, CEDAR_COST, CEDAR_ROW_COST, ELEVATOR_COST, ELEVATOR_DAILY, FLOOR_COST, HVAC_COST, HVAC_DAILY, KEYPAD_COST, MANAGER_DAILY, MARKET, PLAN_PARTS, PORTER_DAILY, SECOND_CAB_COST, SECOND_CAB_DAILY, SERVICE_PARTS, TECH_DAILY, UPPER_DOWN, clockLabel, costLines, dailyCost, energyMax, marketFor, money, moneyCents, rentRoll, siteStrain } from "@/game/economy"
import { emptyLot, ensureManager, ensureTech, ensureTech2, makeCedar } from "@/game/create"
import { freshWorld, padTaken, queueService, queueTask, refreshProspect, advanceWorld, findUnit, pushLedger, owedBalance, clearMiss, applyInstant } from "@/game/sim"
import type { ProductKey, Sheet, Speed, StaffRole, Unit, World } from "@/game/types"
import { productKey } from "@/game/types"

const KEY = "sst.maple.v1"
const SAND = "sst.maple.sandbox.v1"
const BAK = `${KEY}.bak`
const CHECK = "sst.maple.checkpoint"

let loadedSave = false
let saveHold = false
let pendingBiz: World | null = null
let pendingSand: World | null = null

export interface Line {
  k: string
  v: string
}

export interface Action {
  id: string
  label: string
  tone: "accent" | "ghost"
}

export interface Snap {
  clock: string
  dayNote: string
  goal: string
  energy: string
  cash: string
  leased: string
  welcome: boolean
  saved: boolean
  sandboxSaved: boolean
  override: string
  rules: string
  goalLine: string
  sandbox: boolean
  checkpoint: boolean
  toast: string | null
  sound: boolean
  sheet: Sheet
  interiorOpen: boolean
  speed: Speed
  place: string
  switchSite: Action | null
  coach: { title: string; body: string; action: Action | null } | null
  selection: {
    title: string
    lines: Line[]
    note: string | null
    actions: Action[]
    price: { key: ProductKey; value: number; min: number; max: number; market: number } | null
    progress: number | null
  } | null
  books: {
    roll: string
    daily: string
    lastRent: string
    rentWhen: string
    nextRent: string
    atRent: string
    gap: { before: string; after: string; short: boolean } | null
    month: string
    construction: string
    injected: string
    note: string
    market: string
    pass: string
    full: string
    owed: string
    owedHint: string
    owedLive: boolean
    ledger: { text: string; amount: string }[]
    split: { k: string; v: string }[]
    sites: { name: string; roll: string; daily: string }[]
    choice: { cost: string; after: string; days: number; thin: boolean; short: boolean } | null
    cedar: { cost: string; ready: boolean } | null
    units: { id: string; number: string; state: string; line: string; group: "look" | "empty" | "leased" }[]
  }
  resume: string
  crew: {
    porter: boolean
    tech: boolean
    tech2: boolean
    wage: string
    techWage: string
    offerTech: boolean
    offerTech2: boolean
    showPriority: boolean
    priority: "equipment" | "turnover"
    plan: boolean
    canPlan: boolean
    manager: boolean
    offerManager: boolean
    managerWage: string
    tasks: { label: string; who: string; pct: number }[]
  }
  build: {
    picks: number
    cost: string
    daily: string
    duration: string
    reason: string
    canConfirm: boolean
    canCancel: boolean
    refund: string
    commissioning: boolean
    progress: number | null
    site: "maple" | "cedar"
    finished: boolean
  }
  resetArmed: boolean
}

let world: World = freshWorld()
let resetArmed = false
let resumeSpeed: Speed | null = null
let snap: Snap = toSnap(world)
let booted = false
let saveAt = 0
const listeners = new Set<() => void>()

function publish() {
  world.cash = Math.round(world.cash * 100) / 100
  snap = toSnap(world)
  for (const fn of listeners) fn()
}

export function subscribe(fn: () => void) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

export function getSnapshot() {
  return snap
}

export function getServerSnapshot() {
  return snap
}

function hydrate(w: World) {
  w.version = 3
  if (w.play !== "free") w.play = "business"
  if (w.slot !== "sandbox") w.slot = "business"
  if (w.lot !== "empty") w.lot = "starter"
  if (w.difficulty !== "relaxed" && w.difficulty !== "hard" && w.difficulty !== "custom") w.difficulty = "standard"
  if (w.demand !== "quiet" && w.demand !== "normal" && w.demand !== "busy") {
    w.demand = w.difficulty === "hard" ? "busy" : w.difficulty === "relaxed" ? "quiet" : "normal"
  }
  if (w.costs !== "low" && w.costs !== "normal" && w.costs !== "high") {
    w.costs = w.difficulty === "hard" ? "high" : w.difficulty === "relaxed" ? "low" : "normal"
  }
  if (w.upkeep !== "off" && w.upkeep !== "normal" && w.upkeep !== "often") {
    w.upkeep = w.difficulty === "hard" ? "often" : "normal"
  }
  if (w.goal !== "leased8" && w.goal !== "profit" && w.goal !== "row") w.goal = ""
  if (w.goalMet !== true) w.goalMet = false
  if (typeof w.goalDay !== "number") w.goalDay = 0
  if (w.sandbox !== true) w.sandbox = false
  if (typeof w.openedCash !== "number" || !Number.isFinite(w.openedCash)) w.openedCash = w.cash
  if (w.instant !== true) w.instant = false
  if (typeof w.injected !== "number" || !Number.isFinite(w.injected)) w.injected = 0
  if (!w.milestones) w.milestones = {} as World["milestones"]
  if (!w.prices) w.prices = { ...MARKET }
  if (!Array.isArray(w.movers)) w.movers = []
  if (!Array.isArray(w.tasks)) w.tasks = []
  if (!Array.isArray(w.carts)) w.carts = []
  if (!Array.isArray(w.units)) w.units = []
  if (!w.camera) w.camera = false
  if (!w.cameraFault) w.cameraFault = false
  if (typeof w.securedAt !== "number") w.securedAt = w.camera && w.keypad ? w.day : 0
  if (!w.milestones.cameraServiced) w.milestones.cameraServiced = false
  if (!w.milestones.cartRecovered) w.milestones.cartRecovered = false
  if (!w.milestones.hallLit) w.milestones.hallLit = false
  if (!w.milestones.keypadServiced) w.milestones.keypadServiced = false
  if (typeof w.looseAt !== "number") w.looseAt = 0
  if (!w.hallDark) w.hallDark = false
  if (typeof w.hallAt !== "number") w.hallAt = 0
  if (!w.keypadFault) w.keypadFault = false
  if (typeof w.keypadAt !== "number") w.keypadAt = w.keypad ? w.day : 0
  if (!w.cartNote) w.cartNote = false
  if (typeof w.cartPace !== "number") w.cartPace = 0
  if (typeof w.dock !== "number") w.dock = 0
  if (!w.keypad) w.keypad = false
  if (w.hvac !== "building" && w.hvac !== "live") w.hvac = "none"
  if (typeof w.hvacProgress !== "number") w.hvacProgress = w.hvac === "live" ? 1 : 0
  if (w.floor2 !== "building" && w.floor2 !== "built") w.floor2 = "none"
  if (w.elevator !== "building" && w.elevator !== "built") w.elevator = "none"
  if (typeof w.floorProgress !== "number") w.floorProgress = w.floor2 === "built" ? 1 : 0
  if (typeof w.elevatorProgress !== "number") w.elevatorProgress = w.elevator === "built" ? 1 : 0
  if (!w.upperOpen) w.upperOpen = false
  if (w.secondCab !== "building" && w.secondCab !== "built") w.secondCab = "none"
  if (typeof w.secondProgress !== "number") w.secondProgress = w.secondCab === "built" ? 1 : 0
  if (w.secondCab === "built") w.cabs = 2
  if (w.cabs !== 2) w.cabs = 1
  if (!w.queueSeen) w.queueSeen = false
  if (w.view !== "cedar") w.view = "maple"
  if (!w.units.some((u) => u.site === "cedar")) w.view = "maple"
  if (typeof w.cedarWait !== "number") w.cedarWait = 0
  if (w.cedarPassId === undefined) w.cedarPassId = null
  if (typeof w.elevatorQueue !== "number") w.elevatorQueue = 0
  if (typeof w.cab !== "number") w.cab = 0
  if (w.prices["upper:5x10"] == null || w.prices["upper:5x10"] === 108) w.prices["upper:5x10"] = MARKET["upper:5x10"]
  if (w.prices["drive-up:5x5"] === 79) w.prices["drive-up:5x5"] = MARKET["drive-up:5x5"]
  for (const unit of w.units) {
    if (!unit.climate) unit.climate = false
    if (unit.floor !== 2) unit.floor = 1
    if (typeof unit.z !== "number") unit.z = 0
    if (!unit.behind) unit.behind = false
    if (!unit.locked) unit.locked = false
    if (typeof unit.owed !== "number" || !Number.isFinite(unit.owed) || unit.owed < 0) {
      unit.owed = unit.behind && unit.status === "occupied" ? (unit.lease ?? 0) : 0
    }
    if (unit.status === "occupied" && typeof unit.rentDue !== "number") {
      unit.rentDue = Math.floor(w.day) + Math.max(0, w.daysToRent)
    }
  }
  if (typeof w.delinquentAt !== "number") w.delinquentAt = 0
  if (typeof w.lateUntil !== "number") w.lateUntil = 0
  if (typeof w.lateId !== "string") w.lateId = ""
  if (typeof w.officeAt !== "number") w.officeAt = 0
  if (typeof w.officeSeen !== "string") w.officeSeen = ""
  if (!w.milestones.secured) w.milestones.secured = w.camera && w.keypad
  if (!w.milestones.climate) w.milestones.climate = w.hvac === "live"
  if (!w.milestones.upper) w.milestones.upper = w.upperOpen
  if (!w.milestones.serviced) w.milestones.serviced = false
  if (!w.milestones.turnover) w.milestones.turnover = false
  if (!w.milestones.turned) w.milestones.turned = false
  if (!w.milestones.cycled) w.milestones.cycled = false
  if (!w.milestones.graduated) w.milestones.graduated = false
  if (typeof w.turnoverAt !== "number") w.turnoverAt = 0
  if (typeof w.turnoverId !== "string") w.turnoverId = null
  if (!w.reviewSeen) w.reviewSeen = false
  if (!w.heldRow) w.heldRow = false
  if (!w.ledgerSeen) w.ledgerSeen = false
  if (!w.manager) w.manager = false
  if (!w.managerSeen) w.managerSeen = false
  if (typeof w.managerAlert !== "string") w.managerAlert = null
  if (!w.tech) w.tech = false
  if (!w.tech2) w.tech2 = false
  if (typeof w.energy !== "number") w.energy = energyMax(w)
  if (typeof w.energyDay !== "number") w.energyDay = Math.floor(w.day)
  if (typeof w.dayLeases !== "number") w.dayLeases = 0
  if (typeof w.dayPasses !== "number") w.dayPasses = 0
  if (typeof w.dayNote !== "string") w.dayNote = ""
  if (typeof w.steadyAt !== "number") w.steadyAt = w.milestones.graduated ? Math.floor(w.day) : 0
  if (typeof w.goalCash !== "number") w.goalCash = w.steadyAt ? Math.round(w.cash + 3000) : 0
  if (w.quarterTold !== "held" && w.quarterTold !== "slipped") w.quarterTold = ""
  if (typeof w.issueDay !== "number") w.issueDay = 0
  if (typeof w.passes !== "number") w.passes = 0
  if (typeof w.took !== "number") w.took = 0
  if (typeof w.passesSince !== "number") w.passesSince = 0
  if (typeof w.tookSince !== "number") w.tookSince = 0
  if (typeof w.priceNote !== "string") w.priceNote = ""
  if (typeof w.unmet !== "string") w.unmet = ""
  if (typeof w.unmetAt !== "number") w.unmetAt = 0
  if (!w.misses || typeof w.misses !== "object") {
    w.misses = {}
    w.unmetAt = 0
    if (typeof w.unmet !== "string" || w.unmet.startsWith("People asked")) w.unmet = ""
  }
  for (const key of ["drive-up:5x5", "drive-up:5x10", "interior:5x10", "interior:10x10", "upper:5x10"] as const) {
    const count = w.misses[key]
    if (typeof count !== "number" || !Number.isFinite(count) || count < 0) w.misses[key] = 0
  }
  if (typeof w.lastPass !== "string") w.lastPass = ""
  if (w.expandLock !== "plant" && w.expandLock !== "up") w.expandLock = ""
  if (typeof w.expandUntil !== "number" || !Number.isFinite(w.expandUntil)) w.expandUntil = 0
  if (!Array.isArray(w.ledger)) w.ledger = []
  if (w.priority !== "equipment" && w.priority !== "turnover") w.priority = "equipment"
  if (!w.servicePlan) w.servicePlan = false
  if (w.elevWear !== "due" && w.elevWear !== "down") w.elevWear = "good"
  if (typeof w.wearAt !== "number") w.wearAt = 0
  if (typeof w.upperAt !== "number") w.upperAt = w.upperOpen ? w.day : 0
  ensureTech(w.movers, w.tech)
  ensureTech2(w.movers, w.tech2)
  ensureManager(w.movers, w.manager)
  ensureUpperUnits(w)
}

const UPPER_SPECS = [
  { n: "401", x: 98, y: 22 },
  { n: "402", x: 108, y: 22 },
  { n: "403", x: 118, y: 22 },
  { n: "404", x: 98, y: 36 },
  { n: "405", x: 108, y: 36 },
  { n: "406", x: 118, y: 36 },
]

function ensureUpperUnits(w: World) {
  if (!w.upperOpen) return
  for (const spec of UPPER_SPECS) {
    if (w.units.some((u) => u.number === spec.n)) continue
    w.units.push({
      id: `u${spec.n}`,
      number: spec.n,
      product: "5x10",
      access: "interior",
      x: spec.x,
      y: spec.y,
      w: 8.5,
      d: 10,
      h: 6.2,
      z: 8.2,
      floor: 2,
      door: "s",
      status: "rentReady",
      lease: null,
      tenant: null,
      note: "Floor 2. Reached by the elevator. One cab is the capacity.",
      group: "floor2",
      padId: null,
      buildCost: 0,
      progress: 1,
      doorOpen: 0,
      climate: false,
    })
  }
}

function addEnergy() {
  world.energy = Math.min(energyMax(world), world.energy + 1)
}

function cabBlocked(w: World) {
  return w.elevWear === "down" && w.cabs < 2
}

function whoLabel(who: StaffRole | null) {
  if (who === "owner") return "Owner"
  if (who === "porter") return "Porter"
  if (who === "tech") return "Tech"
  if (who === "tech2") return "Second Tech"
  if (!who) return "Waiting"
  return "Nobody"
}

function bookGroup(u: Unit): "look" | "empty" | "leased" {
  if (u.status === "occupied" && !u.behind) return "leased"
  if (u.status === "rentReady") return "empty"
  return "look"
}

function statusLine(u: Unit) {
  if (u.status === "makeReady") {
    const stage = u.progress < 0.34 ? "Haul the leftovers out" : u.progress < 0.67 ? "Sweep" : "Door check"
    return `Vacant. ${stage}.`
  }
  if (u.status === "rentReady") return "Vacant. Rent-ready."
  if (u.status === "occupied" && u.behind && u.locked) {
    const owed = u.owed ? ` ${money(u.owed)} owed, not cash.` : ""
    return u.tenant ? `Occupied. ${u.tenant}. Overlocked.${owed}` : `Occupied. Overlocked.${owed}`
  }
  if (u.status === "occupied" && u.behind) {
    const owed = u.owed ? ` ${money(u.owed)} owed, not cash.` : ""
    return u.tenant ? `Occupied. ${u.tenant}. Behind on rent.${owed}` : `Occupied. Behind on rent.${owed}`
  }
  if (u.status === "occupied") return u.tenant ? `Occupied. ${u.tenant}` : "Occupied."
  if (u.status === "constructing") return "Under construction."
  return "Built. Not commissioned."
}

function selectionOf(w: World): Snap["selection"] {
  const id = w.selectedId
  if (!id || w.sheet !== "inspect") return null
  if (id === "office") {
    return {
      title: "Office",
      lines: [
        { k: "Role", v: "Customer service and leasing" },
        { k: "Staff", v: "Owner on site" },
      ],
      note: "The beginner facility needs a real office. It is open.",
      actions: [],
      price: null,
      progress: null,
    }
  }
  if (id === "gate") {
    const actions: Action[] = []
    const covered =
      w.lot === "empty" ||
      (w.milestones.repaired && !w.lightFault && w.units.some((u) => u.padId) && !w.units.some((u) => u.status === "uncommissioned" && u.site !== "cedar"))
    if (covered && !w.camera) actions.push({ id: "camera", label: `Add camera ${money(CAMERA_COST)}`, tone: "accent" })
    else if (covered && !w.keypad) actions.push({ id: "keypad", label: `Upgrade keypad ${money(KEYPAD_COST)}`, tone: "accent" })
    if (w.cameraFault && !w.tasks.some((t) => t.targetId === "camera")) {
      actions.unshift({ id: "service-camera", label: "Service the camera", tone: "accent" })
    }
    if (w.keypadFault && !w.tasks.some((t) => t.targetId === "keypad")) {
      actions.unshift({ id: "service-keypad", label: "Service the keypad", tone: "accent" })
    }
    if (w.lightFault && !w.tasks.some((t) => t.targetId === "light")) {
      actions.unshift({ id: "repair", label: "Replace the lamp", tone: "accent" })
    }
    const nextBuy = !w.camera ? CAMERA_COST : !w.keypad ? KEYPAD_COST : 0
    return {
      title: "Main gate",
      lines: [
        { k: "Access", v: "Vehicle gate and keypad" },
        { k: "Street", v: "Connected to Maple Street" },
        { k: "Lamp", v: w.lightFault ? "Out" : "Working" },
        { k: "Camera", v: !w.camera ? "None" : w.cameraFault ? "Offline" : "Watching the apron" },
        { k: "Keypad", v: w.keypadFault ? "Sticking" : w.keypad ? "Upgraded" : "Basic" },
      ],
      note: w.lightFault
        ? "The gate lamp is out. Replace it from here. The camera and the keypad are a different job."
        : w.cameraFault
        ? "The camera is installed and offline. The apron is a blind spot until someone services it."
        : nextBuy && covered
          ? `${!w.camera ? "A camera" : "The keypad upgrade"} is ${money(nextBuy)}${!w.camera ? `, then ${money(CAMERA_DAILY)} a day` : ""}. After it you would have ${money(w.cash - nextBuy)}. One purchase at a time.`
          : w.camera && w.keypad
            ? "The street side is covered. Customers still pause here, then the arm opens."
            : "The lamp is not the same as coverage. The camera and the keypad are separate spends, and they wait until the new row is commissioned.",
      actions,
      price: null,
      progress: null,
    }
  }
  if (id === "light") {
    const task = w.tasks.find((t) => t.kind === "repair" && t.targetId === "light")
    return {
      title: "Gate light",
      lines: [
        { k: "State", v: w.lightFault ? "Out" : "Working" },
        { k: "Assigned", v: task ? whoLabel(task.assignee) : "Nobody" },
      ],
      note: w.lightFault ? "Work: replace the lamp." : "The lamp is covering the gate.",
      actions: w.lightFault && !task ? [{ id: "repair", label: "Start repair", tone: "accent" }] : [],
      price: null,
      progress: task ? task.done / task.work : null,
    }
  }
  if (id === "corral") {
    const available = w.carts.filter((c) => c.phase === "home").length
    const inUse = w.carts.length - available
    const waiting = w.visit?.kind === "interior" && w.visit.stage === 3 && !w.visit.cartId
    const actions: Action[] = []
    if (w.carts.some((c) => c.phase === "stray") && !w.tasks.some((t) => t.kind === "recover")) {
      actions.push({ id: "recover-cart", label: "Recover the cart", tone: "accent" })
    }
    if (w.carts.length < CART_MAX) actions.push({ id: "buy-cart", label: `Add a cart ${money(CART_COST)}`, tone: "ghost" })
    const note = waiting
      ? "A customer is waiting here. The hall trip does not start without a cart."
      : w.carts.some((c) => c.phase === "stray")
        ? "One cart is outside the corral, by the loading door."
        : available < 2
          ? "Below the target. The next indoor customer will wait if none are free."
          : "Carts leave with interior customers and come back here. Drive-up units do not use them."
    return {
      title: "Main Loading Cart Corral",
      lines: [
        { k: "Assigned", v: String(w.carts.length) },
        { k: "Available", v: String(available) },
        { k: "In use", v: String(inUse) },
        { k: "Target stock", v: "2+" },
      ],
      note,
      actions,
      price: null,
      progress: null,
    }
  }
  if (id === "building") {
    const actions: Action[] = [{ id: "interior", label: w.roofHold ? "Close roof" : "Open roof", tone: "ghost" }]
    const climateNow = w.camera && w.keypad && !w.cameraFault && w.units.some((u) => u.padId) && !w.lightFault
    let climate = "Not installed"
    let note = "Open the roof to read the hallway. This building is still one floor."
    let progress: number | null = null
    if (w.hvac === "none") {
      if (climateNow) {
        actions.unshift({ id: "hvac", label: `Install HVAC ${money(HVAC_COST)}`, tone: "accent" })
        note = `The plant is ${money(HVAC_COST)}, then ${money(HVAC_DAILY)} a day after you commission it. The floor is ${money(FLOOR_COST)} and the elevator is ${money(ELEVATOR_COST)}, ${money(FLOOR_COST + ELEVATOR_COST)} together. Starting one makes the other wait until rent posts.`
      } else {
        note = "Open the roof to read the hallway. The climate plant is a later spend. It is not for sale on this sheet yet."
      }
    } else if (w.hvac === "building" && w.hvacProgress < 1) {
      climate = "Under construction"
      actions.push({ id: "cancel-hvac", label: `Cancel plant, refund ${money(HVAC_COST * 0.4)}`, tone: "ghost" })
      note = "The condenser is going in. Power is not billed until the zone is commissioned."
      progress = w.hvacProgress
    } else if (w.hvac === "building") {
      climate = "Ready to commission"
      actions.unshift({ id: "climate", label: "Commission climate", tone: "accent" })
      note = "Commission the zone so units 205 and 206 earn the climate rate. Power then posts every day."
      progress = 1
    } else {
      climate = "Live on 205 and 206"
      note = "Those 10×10s are climate-controlled. The ground floor is full. A second floor needs an elevator. Stairs do not move carts."
    }
    let floors = "Ground only"
    let elev = "None"
    if (w.hvac === "live" || w.floor2 !== "none" || w.elevator !== "none" || w.upperOpen || climateNow) {
      if (!w.upperOpen && w.floor2 === "none" && (w.elevator !== "none" || (w.elevator === "none" && holdsTheOther(w, FLOOR_COST, ELEVATOR_COST)))) {
        actions.push({ id: "floor2", label: `Add second floor ${money(FLOOR_COST)}`, tone: "accent" })
      }
      if (!w.upperOpen && w.elevator === "none" && w.floor2 !== "none" && w.cash >= ELEVATOR_COST) {
        actions.push({ id: "elevator", label: `Add elevator ${money(ELEVATOR_COST)}`, tone: "accent" })
      }
      if (w.floor2 === "building" && w.floorProgress < 1) {
        floors = "Under construction"
        progress = w.floorProgress
        actions.push({ id: "cancel-floor", label: `Cancel floor, refund ${money(FLOOR_COST * 0.4)}`, tone: "ghost" })
      } else if (w.upperOpen) floors = "2 floors open"
      else if (w.floor2 === "built") floors = "Built, not open"
      if (w.elevator === "building" && w.elevatorProgress < 1) {
        elev = "Under construction"
        progress = progress == null ? w.elevatorProgress : Math.min(progress, w.elevatorProgress)
        actions.push({ id: "cancel-elevator", label: `Cancel elevator, refund ${money(ELEVATOR_COST * 0.4)}`, tone: "ghost" })
      } else if (w.upperOpen && w.cabs >= 2) elev = "2 cabs"
      else if (w.upperOpen) elev = "1 cab"
      else if (w.elevator === "built") elev = "1 cab, not in service"
      if (w.secondCab === "building" && w.secondProgress < 1) {
        elev = "Second cab going in"
        progress = progress == null ? w.secondProgress : Math.min(progress, w.secondProgress)
        actions.push({ id: "cancel-second", label: `Cancel second cab, refund ${money(SECOND_CAB_COST * 0.4)}`, tone: "ghost" })
      }
      if (w.upperOpen && w.secondCab === "none" && w.queueSeen && w.manager) {
        actions.push({ id: "second-cab", label: `Add a second cab ${money(SECOND_CAB_COST)}`, tone: "accent" })
      }
      if (w.floor2 === "built" && w.elevator === "built" && !w.upperOpen) {
        actions.unshift({ id: "open-upper", label: "Open floor 2", tone: "accent" })
        note = "The floor and the elevator are both in. Open floor 2 before units 401 to 406 can lease. One cab is the capacity."
        progress = 1
      } else if (w.floor2 === "built" && w.elevator !== "built") {
        note = `The second floor is built. The elevator is ${money(ELEVATOR_COST)}, then ${money(ELEVATOR_DAILY)} a day. After it you would have ${money(w.cash - ELEVATOR_COST)}. Stairs are not a substitute.`
      } else if (w.elevator === "built" && w.floor2 !== "built") {
        note = "The elevator is in. It needs a second floor to serve."
      } else if (w.floor2 === "building" && w.elevator === "none") {
        note = `The floor is going in. The elevator is ${money(ELEVATOR_COST)}, then ${money(ELEVATOR_DAILY)} a day. After it you would have ${money(w.cash - ELEVATOR_COST)}.`
      } else if (w.upperOpen) {
        const waiting = w.elevatorQueue > 0.3 ? "1" : "0"
        note =
          w.cabs >= 2
            ? `Two cabs serve floor 2. The second shaft took floor area and did not add units. Waiting now: ${waiting}.`
            : `Floor 2 is open. Upper units ask less than the ground floor because customers wait on one cab. Waiting now: ${waiting}.`
      } else if (
        w.floor2 === "none" &&
        w.elevator === "none" &&
        !holdsTheOther(w, FLOOR_COST, ELEVATOR_COST) &&
        !holdsTheOther(w, ELEVATOR_COST, FLOOR_COST)
      ) {
        const short = Math.max(0, FLOOR_COST + ELEVATOR_COST - w.cash)
        note = `The floor is ${money(FLOOR_COST)} and the elevator is ${money(ELEVATOR_COST)}, ${money(FLOOR_COST + ELEVATOR_COST)} together. You are short ${money(short)}. Those buttons stay off until starting one would still leave the other paid.`
      }
    }
    if (cabBlocked(w)) note = "The cab is down. Carts cannot reach floor 2 until someone services it. Parts post when the work finishes."
    else if (w.elevWear === "down" && w.cabs >= 2) note = "One cab is down. The other is still running. Service the failed cab. Parts post when the work finishes."
    else if (w.elevWear === "due") note = "The cab still runs, slower. Service it before it stops. A Tech can take this so turnover does not wait on you."
    if ((w.elevWear === "due" || w.elevWear === "down") && !w.tasks.some((t) => t.kind === "service")) {
      actions.unshift({ id: "service", label: "Service the elevator", tone: "accent" })
    }
    if (w.milestones.serviced && !w.servicePlan) actions.push({ id: "plan", label: "Keep a service plan", tone: "accent" })
    else if (w.servicePlan) actions.push({ id: "plan", label: "Drop the service plan", tone: "ghost" })
    if (!w.tech && (w.elevWear !== "good" || w.milestones.serviced)) {
      actions.push({ id: "hire-tech", label: `Hire a Tech ${money(TECH_DAILY)} a day`, tone: "ghost" })
    }
    const lines: Line[] = [
      { k: "Route", v: "Apron, cart, wide door, hall, unit" },
      { k: "Roof", v: w.roofHold ? "Held open" : "Opens for interior trips" },
      { k: "Climate", v: climate },
      { k: "Floors", v: floors },
      { k: "Elevator", v: elev },
    ]
    if (w.upperOpen) lines.push({ k: "Waiting", v: w.elevatorQueue > 0.3 ? "1 cart" : "Clear" })
    if (w.upperOpen || w.elevWear !== "good") {
      lines.push({ k: "Condition", v: w.elevWear === "down" ? "Down" : w.elevWear === "due" ? "Due" : "Good" })
      lines.push({ k: "Plan", v: w.servicePlan ? "On" : "Off" })
    }
    if (w.hallDark) {
      lines.push({ k: "Hall", v: "Dark" })
      note = "The hallway lamp is out. You can see it with the roof open."
      if (!w.tasks.some((t) => t.targetId === "hall")) actions.unshift({ id: "service-hall", label: "Replace the hall lamp", tone: "accent" })
    }
    if (w.expandLock) {
      const days = Math.max(0, Math.ceil(w.expandUntil - w.day))
      const when = days === 1 ? "day" : "days"
      const wait =
        w.expandLock === "plant"
          ? `The floor and the elevator wait until rent posts in ${days} ${when}.`
          : `The plant waits until rent posts in ${days} ${when}.`
      note = `${note} ${wait}`
    }
    return {
      title: "Indoor building",
      lines,
      note,
      actions,
      price: null,
      progress,
    }
  }
  const unit = findUnit(w, id)
  if (!unit) return null
  const task = w.tasks.find((t) => t.targetId === unit.id)
  const key = productKey(unit)
  const lines: Line[] = [
    { k: "Size", v: unit.product.replace("x", "×") },
    { k: "Access", v: unit.access === "drive-up" ? "Drive-up" : unit.floor === 2 ? "Floor 2, elevator" : "Interior" },
    { k: "State", v: statusLine(unit) },
  ]
  if (unit.status === "occupied" && unit.lease) lines.push({ k: "Lease", v: `${money(unit.lease)} / month` })
  if (task) lines.push({ k: "Assigned", v: whoLabel(task.assignee) })
  else if (unit.status === "makeReady") lines.push({ k: "Assigned", v: unit.site === "cedar" ? "Site lead" : "Nobody" })
  const actions: Action[] = []
  if (unit.status === "makeReady" && !task && unit.site !== "cedar") {
    actions.push({
      id: "make-ready",
      label: unit.number === "107" ? "Start Owner Make-Ready" : "Start make-ready",
      tone: "accent",
    })
  }
  if (unit.status === "occupied" && (w.play === "free" || w.sandbox)) {
    actions.push({ id: "end-lease", label: "End the lease", tone: "ghost" })
  }
  if (unit.status !== "occupied" && unit.status !== "constructing" && unit.site !== "cedar" && (unit.padId || w.sandbox || w.play === "free" || w.lot === "empty")) {
    const refund = unit.buildCost > 0 ? ` Refund ${money(unit.buildCost * 0.4)}.` : ""
    actions.push({ id: "demolish", label: `Remove unit.${refund}`, tone: "ghost" })
  }
  if (unit.behind && !unit.locked && unit.status === "occupied") {
    actions.push({ id: "overlock", label: "Overlock. Pay, or leave it dirty", tone: "accent" })
  }
  if (unit.status === "uncommissioned" && unit.site !== "cedar") actions.push({ id: "commission", label: "Commission row", tone: "accent" })
  if (unit.site === "cedar" && unit.status === "constructing") {
    actions.push({ id: "cancel-cedar-row", label: `Cancel row, refund ${money(CEDAR_ROW_COST * 0.4)}`, tone: "ghost" })
  }
  if (unit.site === "cedar" && unit.status === "uncommissioned") {
    actions.push({ id: "commission-cedar", label: "Commission Cedar row", tone: "accent" })
  }
  const cedar = unit.site === "cedar"
  const live = w.hvac === "live"
  const market = cedar ? MARKET["drive-up:5x10"] : marketFor(key, live, cabBlocked(w))
  const price =
    unit.status === "constructing" || (cedar && unit.status === "occupied")
      ? null
      : {
          key,
          value: cedar ? (unit.ask ?? market) : w.prices[key],
          min: Math.round(market * 0.55),
          max: Math.round(market * 1.9),
          market,
        }
  return {
    title: `Unit ${unit.number}`,
    lines,
    note: unit.behind
      ? unit.locked
        ? "Overlocked. They are more likely to pay the missed rent plus a $35 late fee, or leave the unit dirty."
        : "This lease did not pay. Overlock makes a payment more likely: the missed rent plus a $35 late fee, then they leave. If you wait, they usually leave and you get no check. Either way a dirty unit needs a sweep."
      : cedar
      ? "Cedar Court. This asking price stays here. It does not change Maple Street."
      : unit.floor === 2 && cabBlocked(w)
        ? "Floor 2 is harder to rent while the only cab is down."
        : unit.floor === 2 && w.elevWear === "down"
          ? "One cab is down. The other still reaches this unit, more slowly."
          : unit.floor === 2 && w.elevWear === "due"
          ? "The elevator is due, so this unit is a slower trip."
          : unit.climate
            ? "Climate-controlled. The HVAC plant covers this unit."
            : (unit.note ?? (unit.access === "interior" ? "Reached through the loading door, a cart, and the hall." : "Direct aisle access.")),
    actions,
    price,
    progress: task ? task.done / task.work : unit.site === "cedar" && unit.status === "makeReady" ? unit.progress : unit.status === "constructing" ? unit.progress : null,
  }
}

function nextBuy(w: World): string {
  if (!w.milestones.graduated || !w.manager) return ""
  if (w.upperOpen && w.secondCab === "none" && w.cabs < 2) {
    return ` A second cab is ${money(SECOND_CAB_COST)} when this lease is handled. It does not add units.`
  }
  if (!w.units.some((u) => u.site === "cedar")) {
    return ` Cedar Court is ${money(CEDAR_COST)} when this lease is handled. It does not add units here.`
  }
  return ""
}

function reserveNote(w: World, price: number): string {
  const left = w.cash - price
  const until = Math.round(dailyCost(w) * Math.max(0, w.daysToRent))
  if (left >= until) return ""
  return ` After it you would have ${money(left)}. Costs until the next rent are about ${money(until)}.`
}

function rowOffer(w: World) {
  const cedarUnits = w.units.filter((u) => u.site === "cedar")
  const open =
    w.manager &&
    !w.heldRow &&
    cedarUnits.length > 0 &&
    !cedarUnits.some((u) => u.number === "C5" || u.status === "makeReady" || u.status === "constructing")
  if (!open) return null
  const daily = dailyCost(w)
  const left = w.cash - CEDAR_ROW_COST
  const days = daily > 0 ? Math.max(0, Math.floor(left / daily)) : 0
  return { left, days, thin: days < 12, short: left < 0 }
}

function countLabel(n: number, singular: string) {
  const d = Math.max(0, Math.round(n))
  return `${d} ${singular}${d === 1 ? "" : "s"}`
}

function pastOpening(w: World) {
  return (
    w.porter ||
    w.camera ||
    w.milestones.commissioned ||
    w.milestones.graduated ||
    w.floor2 !== "none" ||
    w.hvac !== "none" ||
    w.units.some((u) => u.padId || u.site === "cedar")
  )
}

function coach(w: World): Snap["coach"] {
  const card = coachRaw(w)
  if (!card || openingWeek(w)) return card
  if (isLive(card.title)) return { ...card, action: null }
  if (!w.milestones.graduated) return { title: "Steady", body: steadyLine(w), action: null }
  return { title: "The quarter", body: quarterLine(w), action: null }
}

function openingWeek(w: World) {
  return !(w.milestones.leased && w.milestones.repaired)
}

function isLive(title: string) {
  if (title.startsWith("Unit ")) return true
  return (
    title === "One pair of hands" ||
    title === "Equipment is waiting" ||
    title === "Maintenance queue" ||
    title === "Out of energy" ||
    title === "Time is paused" ||
    title === "This morning" ||
    title === "Gate light" ||
    title === "Camera offline" ||
    title === "No cart free" ||
    title === "Cart left out" ||
    title === "Hall light" ||
    title === "Keypad stuck" ||
    title === "One cab is down" ||
    title === "Elevator is down" ||
    title === "Elevator service" ||
    title === "Rent is behind" ||
    title === "Move-out" ||
    title === "Cash is negative" ||
    title === "Short before rent"
  )
}

const STEADY_MARK = 78

function steadyLine(w: World): string {
  const left: string[] = []
  if (!w.milestones.commissioned) left.push("a new row commissioned")
  if (!w.milestones.climate) left.push("climate commissioned")
  if (!w.milestones.upper) left.push("floor 2 open")
  if (!w.milestones.serviced) left.push("one elevator service")
  if (!w.milestones.hired) left.push("someone on the payroll")
  if (!w.milestones.turned) left.push("two turnovers")
  else if (!w.milestones.cycled) left.push("one more turnover")
  if (!w.servicePlan && !w.tech) left.push("a Tech or a service plan")
  const late = w.day > STEADY_MARK ? ` Day ${STEADY_MARK} has passed.` : ""
  if (!left.length) return `The mark is day ${STEADY_MARK}. The work is done. It counts the next morning.${late}`
  return `The mark is day ${STEADY_MARK}. Still open: ${left.slice(0, 3).join(", ")}.${late}`
}

function quarterLine(w: World): string {
  if (!w.steadyAt) return "Maple Street is steady. The quarter starts that morning."
  const due = w.steadyAt + 90
  const cedar = w.units.some((u) => u.site === "cedar" && u.status !== "uncommissioned")
  const month = rentRoll(w.units) - dailyCost(w) * 30
  if (w.quarterTold === "held") return `The quarter held. ${money(w.goalCash)} by day ${due}, Cedar open, and the month was not short.`
  if (w.quarterTold === "slipped") {
    const why: string[] = []
    if (w.cash < w.goalCash) why.push(`cash is ${money(w.cash)}, short of ${money(w.goalCash)}`)
    if (!cedar) why.push("Cedar is not open")
    if (month < 0) why.push("this month is short")
    return `The quarter slipped. ${why.join(". ") || "The mark was missed."}`
  }
  const left = Math.max(0, Math.ceil(due - w.day))
  return `By day ${due} (${countLabel(left, "day")}): ${money(w.goalCash)} on hand and Cedar open. A short month fails it. Cash is ${money(w.cash)}. ${cedar ? "Cedar is open." : "Cedar is not open. The books can buy it."}`
}

function buildingChoice(w: World): Snap["coach"] {
  const together = FLOOR_COST + ELEVATOR_COST
  const plant =
    w.hvac === "live"
      ? "The plant is already in."
      : `The plant is ${money(HVAC_COST)}, then ${money(HVAC_DAILY)} a day.`
  const days = w.expandLock ? Math.max(0, Math.ceil(w.expandUntil - w.day)) : 0
  const when = days === 1 ? "day" : "days"
  const wait =
    w.expandLock === "plant"
      ? `The plant was this cycle. The floor and the elevator wait until rent posts in ${days} ${when}.`
      : w.expandLock === "up"
        ? `The floor was this cycle. The plant waits until rent posts in ${days} ${when}.`
        : "Starting one makes the other wait until rent posts."
  const elevatorShort = w.floor2 === "built" && w.elevator === "none" && w.cash < ELEVATOR_COST
  const floorShort = w.elevator === "built" && w.floor2 === "none" && w.cash < FLOOR_COST
  const short = elevatorShort
    ? ` You are short ${money(ELEVATOR_COST - w.cash)} of the elevator.`
    : floorShort
      ? ` You are short ${money(FLOOR_COST - w.cash)} of the floor.`
      : ""
  return {
    title: "The building",
    body: `${plant} The floor and the elevator are ${money(together)} together. ${wait}${short} Both sit on the building sheet.`,
    action:
      elevatorShort || floorShort
        ? { id: "books", label: "Open the books", tone: "accent" }
        : { id: "inspectBuilding", label: "Inspect the building", tone: "ghost" },
  }
}

function hasCheckpoint() {
  try {
    return !!localStorage.getItem(CHECK)
  } catch {
    return false
  }
}

function rulesText(w: World) {
  if (!w.sandbox && w.play !== "free") return ""
  const demand = w.demand === "quiet" ? "Quiet demand" : w.demand === "busy" ? "Busy, picky demand" : "Normal demand"
  const costs = w.costs === "low" ? "low daily cost" : w.costs === "high" ? "high daily cost" : "normal daily cost"
  const upkeep = w.upkeep === "off" ? "no new faults" : w.upkeep === "often" ? "faults sooner" : "normal faults"
  return `${demand}. ${costs[0]!.toUpperCase()}${costs.slice(1)}. ${upkeep[0]!.toUpperCase()}${upkeep.slice(1)}.`
}

function goalText(w: World) {
  if (!w.goal) return ""
  if (w.goalMet) return "Goal met. The lot stays yours."
  if (w.goal === "leased8") {
    const n = w.units.filter((u) => u.site !== "cedar" && u.status === "occupied").length
    return `Goal · ${n} of 8 leased`
  }
  if (w.goal === "row") {
    const n = w.units.filter((u) => u.padId && u.site !== "cedar" && (u.status === "rentReady" || u.status === "occupied" || u.status === "makeReady")).length
    return n > 0 ? "Goal · new row commissioned" : "Goal · commission a new row"
  }
  const left = Math.max(0, Math.ceil(w.goalDay - w.day))
  return left > 0 ? `Goal · cash above ${money(w.openedCash)} in ${left} days` : `Goal · cash above ${money(w.openedCash)}`
}

function coachRaw(w: World): Snap["coach"] {
  if (w.welcome) return null
  const u107 = w.units.find((u) => u.number === "107")
  const mr = w.tasks.find((t) => t.kind === "makeReady")
  const repair = w.tasks.find((t) => t.kind === "repair")
  const ownerBusy = w.tasks.some((t) => t.assignee === "owner")
  const queued = w.tasks.some((t) => t.assignee === null)
  if (queued && ownerBusy && !w.porter) {
    return {
      title: "One pair of hands",
      body: "Two jobs are waiting and the Owner can only work one at a time. Hiring help adds service capacity.",
      action: { id: "crew", label: "Hire a Porter", tone: "accent" },
    }
  }
  const equipWaiting = w.tasks.some((t) => t.assignee === null && (t.kind === "service" || t.kind === "repair"))
  if (equipWaiting && ownerBusy && w.porter && !w.tech) {
    return {
      title: "Equipment is waiting",
      body: "The Owner is on a job. A Porter does not service the elevator. A Tech does, and stays on the building.",
      action: { id: "hire-tech", label: "Hire a Tech", tone: "accent" },
    }
  }
  const techJob = (t: { kind: string; targetId: string }) =>
    t.kind === "service" || t.targetId === "camera" || t.targetId === "hall" || t.targetId === "keypad"
  const waitingTech = w.tasks.find((t) => t.assignee === null && techJob(t))
  const techBusy = w.tasks.some((t) => (t.assignee === "tech" || t.assignee === "tech2") && techJob(t))
  if (w.tech && !w.tech2 && techBusy && waitingTech) {
    return {
      title: "Maintenance queue",
      body: `${waitingTech.label} is waiting. The Tech is already on a job. A second Tech is ${money(TECH_DAILY)} a day, and adds one energy. If you do not hire, the first Tech takes it when they are free.`,
      action: { id: "hire-tech-2", label: "Hire a second Tech", tone: "accent" },
    }
  }
  if (w.energy <= 0 && w.tasks.some((t) => t.assignee === null)) {
    return {
      title: "Out of energy",
      body: `The site can assign ${energyMax(w)} jobs a day. Anything past that stays queued until morning. A Porter, a Tech, or a Manager each adds one energy.`,
      action: { id: "crew", label: "See the crew", tone: "accent" },
    }
  }
  if (w.lot === "empty") {
    const mine = w.units.filter((u) => u.site !== "cedar")
    const uncom = mine.find((u) => u.status === "uncommissioned")
    if (uncom) {
      return {
        title: "Commission",
        body: "The row is built. Commission it before anyone can lease.",
        action: { id: "commission", label: "Commission row", tone: "accent" },
      }
    }
    const going = mine.some((u) => u.status === "constructing")
    if (going) {
      return {
        title: "Under construction",
        body: "The row is going in. Run the clock, then commission it.",
        action: w.speed === 0 ? { id: "speed1", label: "Run 1×", tone: "accent" } : { id: "build", label: "Build", tone: "ghost" },
      }
    }
    if (!mine.length) {
      return {
        title: "Gated lot",
        body: "The fence and the gate are in. The pads are empty. Build the rows you want.",
        action: { id: "build", label: "Build", tone: "accent" },
      }
    }
    return {
      title: "Your lot",
      body: "Add another row, or run the clock and lease what is ready. A short purchase is sandbox funds, not income.",
      action: { id: "build", label: "Build", tone: "ghost" },
    }
  }
  const plant = w.hvac === "building" && w.hvacProgress < 1
  const rising =
    (w.floor2 === "building" && w.floorProgress < 1) ||
    (w.elevator === "building" && w.elevatorProgress < 1) ||
    (w.secondCab === "building" && w.secondProgress < 1)
  const servicing = w.tasks.some((t) => t.kind === "service")
  if ((mr || repair || plant || rising || servicing) && w.speed === 0) {
    return {
      title: "Time is paused",
      body:
        servicing && !mr && !repair && !plant && !rising
          ? "Elevator service is assigned. Run the clock to watch the work."
          : rising && !mr && !repair && !plant
            ? "The upper work is going in. Run the clock to watch it."
            : plant && !mr && !repair
              ? "The HVAC plant is going in. Run the clock to watch the work."
              : "The job is assigned. Run the clock to watch the work.",
      action: { id: "speed1", label: "Run 1×", tone: "accent" },
    }
  }
  if (!pastOpening(w) && u107?.status === "makeReady" && !mr) {
    return {
      title: "Unit 107",
      body: "One unit is not rent-ready. It needs a sweep, a door check, and a reset.",
      action: { id: "inspect107", label: "Inspect unit 107", tone: "accent" },
    }
  }
  if (!pastOpening(w) && u107?.status === "rentReady" && !w.milestones.leased) {
    return {
      title: "Rent-ready",
      body: "Rent-ready units can lease. Asking rent affects how strongly the market responds. There is no single perfect price.",
      action: { id: "inspect107", label: "Set asking rent", tone: "accent" },
    }
  }
  const pile: string[] = []
  if (w.lightFault && !w.tasks.some((t) => t.targetId === "light")) pile.push("the gate lamp")
  if (w.hallDark && !w.tasks.some((t) => t.targetId === "hall")) pile.push("the hall light")
  if (w.keypadFault && !w.tasks.some((t) => t.targetId === "keypad")) pile.push("the keypad")
  if (w.carts.some((c) => c.phase === "stray") && !w.tasks.some((t) => t.kind === "recover")) pile.push("a cart by the dock")
  if (pile.length >= 2) {
    const room = w.energy
    return {
      title: "This morning",
      body: `${pile.join(", ")} are wrong. Energy is ${room} of ${energyMax(w)}. ${room < pile.length ? "You cannot clear all of them today. " : ""}What you leave will still be wrong tonight, and prospects will say so.`,
      action: null,
    }
  }
  if (w.lightFault && !repair) {
    return {
      title: "Gate light",
      body: "A light at the gate is out. You can see it from the lot. Prospects are slower to lease while it stays dark.",
      action: { id: "inspectLight", label: "Inspect the light", tone: "accent" },
    }
  }
  if (w.cameraFault && !w.tasks.some((t) => t.targetId === "camera")) {
    return {
      title: "Camera offline",
      body: "The gate camera is offline, and some prospects treat that as a reason to pass. Service it. A Porter stays on sweeps. You can do this, or a Tech if one is on the payroll.",
      action: { id: "service-camera", label: "Service the camera", tone: "accent" },
    }
  }
  const waitingCart = w.visit?.kind === "interior" && w.visit.stage === 3 && !w.visit.cartId
  if (waitingCart) {
    const stray = w.carts.some((c) => c.phase === "stray")
    return {
      title: "No cart free",
      body: stray
        ? "A customer is at the corral and will not enter the hall without a cart. One is sitting by the loading door. Walk it back, or wait until another rolls home. Target stock is 2 or more free."
        : "A customer is at the corral and will not enter the hall without a cart. Every cart is out or still rolling back. Target stock is 2 or more free.",
      action: stray && !w.tasks.some((t) => t.kind === "recover")
        ? { id: "recover-cart", label: "Recover the cart", tone: "accent" }
        : { id: "inspectCorral", label: "Check the corral", tone: "accent" },
    }
  }
  const rowWaiting =
    w.milestones.leased &&
    w.pads.length > 0 &&
    w.pads.every((p) => !padTaken(w, p.id)) &&
    !w.units.some((u) => u.padId)
  if (w.carts.some((c) => c.phase === "stray") && !w.tasks.some((t) => t.kind === "recover") && !(rowWaiting && w.milestones.cartRecovered)) {
    return {
      title: "Cart left out",
      body: "A cart is sitting by the loading door, not in the corral. Walk it back. A Porter does this. A Tech does not.",
      action: { id: "recover-cart", label: "Recover the cart", tone: "accent" },
    }
  }
  if (w.hallDark && !w.tasks.some((t) => t.targetId === "hall") && !(rowWaiting && w.milestones.hallLit)) {
    return {
      title: "Hall light",
      body: "The indoor hallway is dark, and prospects hesitate on indoor units. Open the roof and you can see it. A Porter stays on sweeps and carts. You can replace the lamp, or a Tech if one is on the payroll.",
      action: { id: "service-hall", label: "Replace the hall lamp", tone: "accent" },
    }
  }
  if (w.keypadFault && !w.tasks.some((t) => t.targetId === "keypad")) {
    return {
      title: "Keypad stuck",
      body: "The gate keypad is sticking. Cars still arrive, but most prospects leave without leasing until someone services it.",
      action: { id: "service-keypad", label: "Service the keypad", tone: "accent" },
    }
  }
  if (w.upperOpen && w.milestones.serviced && w.elevWear === "good" && !w.milestones.hired) {
    return {
      title: "Hire help",
      body: `A Porter sweeps and recovers carts for ${money(PORTER_DAILY)} a day. The property does not steady until someone is on the payroll.`,
      action: { id: "hire-porter", label: `Hire a Porter ${money(PORTER_DAILY)} a day`, tone: "accent" },
    }
  }
  if (w.milestones.serviced && !w.milestones.graduated && w.elevWear === "good" && !w.servicePlan && !w.tech && !w.tasks.some((t) => t.kind === "service")) {
    return {
      title: "Service plan",
      body: "The cab is healthy again. A service plan queues the next visit before it fails.",
      action: { id: "plan", label: "Keep a service plan", tone: "accent" },
    }
  }
  if (w.milestones.graduated && !w.reviewSeen) {
    return {
      title: "Steady property",
      body: "You turned units, leased them, built, repaired, and hired help. Open the books. Construction stays separate from the daily cost.",
      action: { id: "books", label: "Open the books", tone: "accent" },
    }
  }
  if (w.milestones.graduated && w.reviewSeen && !w.manager) {
    return {
      title: "Hire a Manager",
      body: `A Manager queues routine work for ${money(MANAGER_DAILY)} a day. You still set priority and the service plan.`,
      action: { id: "hire-manager", label: `Hire a Manager ${money(MANAGER_DAILY)} a day`, tone: "accent" },
    }
  }
  const late = w.units.find((u) => u.behind && u.status === "occupied")
  if (late && !late.locked && !(w.milestones.graduated && w.reviewSeen)) {
    return {
      title: "Rent is behind",
      body: `Unit ${late.number} did not pay. Overlock turns that gate code off. Waiting usually means they leave, and you do not get the check.${nextBuy(w)}`,
      action: { id: "inspect-behind", label: `Inspect unit ${late.number}`, tone: "accent" },
    }
  }
  if (w.units.some((u) => u.status === "uncommissioned")) {
    return {
      title: "Commission",
      body: "Construction is finished. Commission the row before those units can lease.",
      action: { id: "commission", label: "Commission row", tone: "accent" },
    }
  }
  if (rowWaiting) {
    const picked = w.pads.filter((p) => w.buildPick.includes(p.id) && !padTaken(w, p.id))
    if (!picked.length) {
      return {
        title: "The rows are full",
        body: "Rent-ready space is gone. The south gravel is the next row. Mark it, then confirm. That spend is construction, not a daily cost.",
        action: { id: "mark-row", label: "Mark the south row", tone: "accent" },
      }
    }
    const row = `${picked.length} drive-up ${picked.length === 1 ? "unit" : "units"}`
    const cost = picked.length * BUILD_COST
    const short = cost - w.cash
    if (short > 0) {
      return {
        title: "The rows are full",
        body: `The south row is marked. ${row} ${picked.length === 1 ? "costs" : "cost"} ${money(cost)}. You are short ${money(short)}.`,
        action: { id: "books", label: "Open the books", tone: "accent" },
      }
    }
    return {
      title: "The rows are full",
      body: `The south row is marked. ${row}, ${money(cost)}. Confirm to start construction.`,
      action: { id: "confirm-build", label: "Confirm the row", tone: "accent" },
    }
  }
  const expanded = w.units.some((u) => u.padId)
  if (w.milestones.repaired && !w.lightFault && expanded && !w.units.some((u) => u.status === "uncommissioned") && (!w.camera || !w.keypad)) {
    const needCam = !w.camera
    const needKey = !w.keypad
    return {
      title: "Gate coverage",
      body: needCam && needKey
        ? `The lamp is fixed. A camera is ${money(CAMERA_COST)}, then ${money(CAMERA_DAILY)} a day. After it you would have ${money(w.cash - CAMERA_COST)}. The keypad is a separate visit.`
        : needCam
          ? `The keypad is upgraded. A camera is ${money(CAMERA_COST)}, then ${money(CAMERA_DAILY)} a day. After it you would have ${money(w.cash - CAMERA_COST)}.`
          : `The camera is up. The keypad upgrade is ${money(KEYPAD_COST)}. After it you would have ${money(w.cash - KEYPAD_COST)}.`,
      action: { id: "inspectGate", label: "Inspect the gate", tone: "accent" },
    }
  }
  const dirtyWaiting = w.units.find(
    (u) => u.status === "makeReady" && u.number !== "107" && !w.tasks.some((t) => t.kind === "makeReady" && t.targetId === u.id),
  )
  if (dirtyWaiting && w.camera && w.keypad) {
    return {
      title: `Unit ${dirtyWaiting.number}`,
      body: `Unit ${dirtyWaiting.number} is empty. It needs a sweep before it can rent again.`,
      action: { id: "make-ready", label: "Start make-ready", tone: "accent" },
    }
  }
  if (w.camera && w.keypad && !w.cameraFault && expanded && !w.lightFault) {
    const floorGoing = w.floor2 === "building" && w.floorProgress < 1
    const elevGoing = w.elevator === "building" && w.elevatorProgress < 1
    if (floorGoing || elevGoing) {
      return {
        title: "Going up",
        body: floorGoing
          ? "The floor is going in. The plant waits until rent posts. It is not a new choice."
          : "The elevator is going in. The plant waits until rent posts. It is not a new choice.",
        action: { id: "inspectBuilding", label: "Check the work", tone: "ghost" },
      }
    }
    if (w.hvac === "none" && w.floor2 !== "built") return buildingChoice(w)
    if (w.hvac === "building" && w.hvacProgress >= 1) {
      return {
        title: "Commission climate",
        body: "The plant is in. Commission the zone so units 205 and 206 earn the climate rate.",
        action: { id: "climate", label: "Commission climate", tone: "accent" },
      }
    }
    if (w.hvac === "building") {
      return {
        title: "HVAC plant",
        body: "The condenser is going in beside the loading canopy. It does not earn the climate rate until you commission it.",
        action: { id: "inspectBuilding", label: "Check the plant", tone: "ghost" },
      }
    }
  }
  if (w.hvac === "live" && !w.upperOpen && expanded && !w.lightFault && !w.units.some((u) => u.status === "uncommissioned")) {
    const floorReady = w.floor2 === "built"
    const elevReady = w.elevator === "built"
    if (floorReady && elevReady) {
      return {
        title: "Open floor 2",
        body: "The floor and the elevator are in. Open them together. One cab is the capacity, so upper units will not rent like the ground floor.",
        action: { id: "open-upper", label: "Open floor 2", tone: "accent" },
      }
    }
    if (floorReady && w.elevator === "none") return buildingChoice(w)
    if (elevReady && w.floor2 === "none") return buildingChoice(w)
    if (w.floor2 === "none" && w.elevator === "none") {
      const floorOk = holdsTheOther(w, FLOOR_COST, ELEVATOR_COST)
      const elevOk = holdsTheOther(w, ELEVATOR_COST, FLOOR_COST)
      if (!floorOk && !elevOk) {
        const together = FLOOR_COST + ELEVATOR_COST
        const short = Math.max(0, together - w.cash)
        const days = `${w.daysToRent} ${w.daysToRent === 1 ? "day" : "days"}`
        return {
          title: "Build up",
          body: `The floor is ${money(FLOOR_COST)} and the elevator is ${money(ELEVATOR_COST)}, ${money(together)} together. You have ${money(w.cash)}. You are short ${money(short)}. Starting one now would leave the other unpaid. Rent posts in ${days}.`,
          action: { id: "books", label: "Open the books", tone: "accent" },
        }
      }
      return buildingChoice(w)
    }
    return {
      title: "Going up",
      body: "The floor and the elevator can rise together. Units stay closed until both are in and you open the floor.",
      action: { id: "inspectBuilding", label: "Check the work", tone: "ghost" },
    }
  }
  if (w.upperOpen && w.elevWear !== "good" && !w.tasks.some((t) => t.kind === "service")) {
    const vacancy = w.units.find((u) => u.status === "makeReady")
    if (w.elevWear === "down" && w.cabs >= 2) {
      return {
        title: "One cab is down",
        body: "The other cab is still taking carts. Service the failed one so you are not back to a single shaft.",
        action: { id: "service", label: "Service the cab", tone: "accent" },
      }
    }
    if (w.elevWear === "down") {
      return {
        title: "Elevator is down",
        body: "Carts cannot reach floor 2. New upper leases fall, and other prospects hesitate. Service the cab.",
        action: { id: "service", label: "Service the elevator", tone: "accent" },
      }
    }
    return {
      title: "Elevator service",
      body: vacancy
        ? `The cab still runs, but it is due. Unit ${vacancy.number} also needs a sweep. Equipment should not wait behind turnover.`
        : "The cab still runs, but it is due. Service it before it stops.",
      action: { id: "service", label: "Service the elevator", tone: "accent" },
    }
  }
  const loose = w.units.find((u) => u.status === "makeReady" && u.number !== "107" && !w.tasks.some((t) => t.targetId === u.id))
  if (loose && !(w.milestones.graduated && w.reviewSeen)) {
    return {
      title: `Unit ${loose.number}`,
      body: "A tenant moved out. The unit needs a sweep before it can rent again. A Porter can do this.",
      action: { id: "make-ready", label: "Start make-ready", tone: "accent" },
    }
  }
  if (w.manager && !w.managerSeen) {
    return {
      title: "Manager on site",
      body: "The Manager assigns routine work from your policies. They do not sweep, and they will not start an elevator visit you did not plan.",
      action: { id: "crew", label: "Open crew", tone: "ghost" },
    }
  }
  if (w.upperOpen && w.secondCab === "none" && w.queueSeen && w.cabs < 2 && w.manager) {
    const short = SECOND_CAB_COST - w.cash
    if (short > 0) {
      return {
        title: "One cab is the limit",
        body: `A second cab is ${money(SECOND_CAB_COST)}. You are short ${money(short)}. It does not add units. It holds upper rent at ${money(MARKET["upper:5x10"])} when one cab stops.`,
        action: { id: "books", label: "Open the books", tone: "accent" },
      }
    }
    return {
      title: "One cab is the limit",
      body: `A second cab is ${money(SECOND_CAB_COST)}, then ${money(SECOND_CAB_DAILY)} a day. It does not add units. Without it, new upper leases fall to ${money(UPPER_DOWN)} while the only cab is down.${reserveNote(w, SECOND_CAB_COST)}`,
      action: { id: "second-cab", label: "Add a second cab", tone: "accent" },
    }
  }
  if (w.manager && !w.units.some((u) => u.site === "cedar")) {
    const short = CEDAR_COST - w.cash
    if (short > 0) {
      return {
        title: "Maple Street is one site",
        body: `Cedar Court is ${money(CEDAR_COST)}. You are short ${money(short)}. It does not add units here.`,
        action: { id: "books", label: "Open the books", tone: "accent" },
      }
    }
    return {
      title: "Maple Street is one site",
      body: `Cedar Court is ${money(CEDAR_COST)} from company cash. You would have ${money(w.cash - CEDAR_COST)}. Maple Street keeps its own books.`,
      action: { id: "buy-cedar", label: "Buy Cedar Court", tone: "accent" },
    }
  }
  const cedarUnits = w.units.filter((u) => u.site === "cedar")
  const cedarWaiting = cedarUnits.filter((u) => u.status === "uncommissioned")
  if (cedarWaiting.length) {
    return {
      title: "Cedar Court row",
      body: "The new units are built. They cannot lease until you commission them. Maple Street is not affected.",
      action: { id: "commission-cedar", label: "Commission Cedar row", tone: "accent" },
    }
  }
  const offer = rowOffer(w)
  if (offer) {
    if (offer.short) {
      return {
        title: "Where the next dollar goes",
        body: `Two more drive-up units at Cedar Court are ${money(CEDAR_ROW_COST)}. You are short ${money(-offer.left)}. Keeping the reserve leaves Cedar the size it is. Rent posts in ${w.daysToRent} ${w.daysToRent === 1 ? "day" : "days"}.`,
        action: { id: "books", label: "Compare the sites", tone: "accent" },
      }
    }
    return {
      title: "Where the next dollar goes",
      body: `The Cedar row is ${money(CEDAR_ROW_COST)}. You would have ${money(offer.left)}, about ${offer.days} days of cost. Compare before you spend.`,
      action: { id: "books", label: "Compare the sites", tone: "accent" },
    }
  }
  if (w.upperOpen && w.elevatorQueue > 0.3 && w.cabs < 2) {
    return {
      title: "Elevator queue",
      body: "One cab is in use. The next cart waits. A second cab would take floor area and would not add units.",
      action: { id: "inspectBuilding", label: "Inspect the elevator", tone: "ghost" },
    }
  }
  if (w.visit?.kind === "interior" && (w.milestones.graduated || !w.upperOpen)) {
    return {
      title: "Interior trip",
      body: "Loading apron, cart, wide door, hallway, unit. That chain is the indoor product.",
      action: { id: "interior", label: w.roofHold ? "Close roof" : "Open the roof", tone: "ghost" },
    }
  }
  if (pastOpening(w) && u107?.status === "makeReady" && !mr) {
    return {
      title: "Unit 107",
      body: "Unit 107 is still not rent-ready. The rest of the property has moved on. It can still be swept.",
      action: { id: "make-ready", label: "Start make-ready", tone: "accent" },
    }
  }
  if (w.visit?.kind === "moveout") {
    const leaving = w.units.find((u) => u.id === w.visit?.unitId)
    return {
      title: leaving ? `Unit ${leaving.number}` : "Move-out",
      body: leaving
        ? `${w.visit.name} is leaving unit ${leaving.number}. The sweep starts when the truck is gone.`
        : "A tenant is leaving. The sweep starts when the truck is gone.",
      action: w.speed === 0 ? { id: "speed1", label: "Run 1×", tone: "accent" } : null,
    }
  }
  const dirty = w.units.find(
    (u) => u.status === "makeReady" && !w.tasks.some((t) => t.kind === "makeReady" && t.targetId === u.id),
  )
  if (dirty && dirty.number !== "107") {
    return {
      title: `Unit ${dirty.number}`,
      body: `Unit ${dirty.number} is empty. It needs a sweep before it can rent again.`,
      action: { id: "make-ready", label: "Start make-ready", tone: "accent" },
    }
  }
  const burn = dailyCost(w)
  const untilRent = burn * w.daysToRent
  const beforeCheck = Math.round(w.cash - untilRent)
  const due = rentRoll(w.units)
  const afterCheck = beforeCheck + due
  if (w.daysToRent > 0 && beforeCheck < burn * 3) {
    return {
      title: w.cash < 0 ? "Cash is negative" : "Short before rent",
      body: `Daily cost is ${moneyCents(burn)}. In ${countLabel(w.daysToRent, "day")} that is ${money(Math.round(untilRent))}, so cash would be ${money(beforeCheck)} before the check. The rent roll is ${money(due)}. After it, about ${money(afterCheck)}, if nothing else is spent.`,
      action: { id: "books", label: "Open the books", tone: "accent" },
    }
  }
  return {
    title: w.upperOpen && !w.milestones.graduated ? "Not steady yet" : "Maple Street",
    body: w.upperOpen && !w.milestones.graduated
      ? `The building is up.${!w.milestones.serviced ? " The cab has not been serviced yet. Wait until it is due. That is the next job, not another purchase." : ""}${w.milestones.serviced && !w.milestones.hired ? " Someone still has to be on the payroll." : ""}${!w.milestones.turned ? (w.milestones.turnover ? " The move-out did not leave a unit. Another one will." : " A move-out has not started yet.") : ""}${w.milestones.turned && !w.milestones.cycled ? " A second unit still has to turn." : ""}`
      : "You built the access. The business follows the layout. Pause whenever you want to look.",
    action: w.upperOpen && !w.milestones.graduated && w.speed === 0 ? { id: "speed1", label: "Run 1×", tone: "accent" } : null,
  }
}

function reputationLine(w: World): string {
  const strain = siteStrain(w)
  if (strain.reason && strain.pass >= 0.2) {
    const lead = strain.reason.charAt(0).toUpperCase() + strain.reason.slice(1)
    return `Prospects notice. ${lead}.`
  }
  if (w.unmet) return w.unmet
  return w.dayNote
}

function toSnap(w: World): Snap {
  const roll = rentRoll(w.units)
  const daily = dailyCost(w)
  const leased = w.units.filter((u) => u.status === "occupied").length
  const stock = w.units.length
  const picks = w.pads.filter((p) => w.buildPick.includes(p.id) && !padTaken(w, p.id))
  const costN = picks.length * BUILD_COST
  const onView = (u: Unit) => (w.view === "cedar" ? u.site === "cedar" : u.site !== "cedar")
  const constructing = w.units.filter((u) => u.status === "constructing" && onView(u))
  const uncom = w.units.some((u) => u.status === "uncommissioned" && onView(u))
  const cedarHere = w.view === "cedar" && w.units.some((u) => u.site === "cedar")
  const rowStarted = w.units.some((u) => u.number === "C5")
  let reason = "Tap pads on the south gravel row."
  if (cedarHere) {
    const left = w.cash - CEDAR_ROW_COST
    if (constructing.length) reason = "Cedar Court row is under construction. Commission it when it finishes. This is not an operating cost."
    else if (uncom) reason = "The Cedar Court row is built. Commission it before those units can lease."
    else if (rowStarted) reason = "The Cedar Court row is already open."
    else if (left < 0) reason = `Not enough cash. Two units at Cedar Court are ${money(CEDAR_ROW_COST)}. You are short ${money(-left)}.`
    else reason = `Two drive-up units, ${money(CEDAR_ROW_COST)}. You would have ${money(left)}.`
  } else if (!picks.length && w.pads.every((p) => padTaken(w, p.id))) reason = "The expansion row is already built."
  else if (!picks.length) reason = "Select one or more empty pads. Doors face the south aisle."
  else if (w.cash < costN) reason = `Not enough cash. This row is ${money(costN)}. You are short ${money(costN - w.cash)}.`
  else {
    const vertical =
      (w.floor2 === "none" ? FLOOR_COST : 0) + (w.elevator === "none" && !w.upperOpen ? ELEVATOR_COST : 0)
    const left = w.cash - costN
    reason =
      vertical > 0 && left < vertical
        ? `${picks.length} drive-up ${picks.length === 1 ? "unit" : "units"}, ${money(costN)}. After this row you would have ${money(left)}. The floor and elevator still need ${money(vertical)}.`
        : `${picks.length} drive-up ${picks.length === 1 ? "unit" : "units"}, 5×5. Aisle frontage is clear. Not commissioned until you open them.`
  }

  const parts = costLines(w)
  const split = [{ k: "Base", v: money(parts.base) }]
  if (parts.payroll) split.push({ k: "Payroll", v: money(parts.payroll) })
  if (parts.power) split.push({ k: "Power", v: money(parts.power) })
  if (parts.elevator) split.push({ k: "Elevator", v: money(parts.elevator) })
  if (parts.upkeep) split.push({ k: "Upkeep", v: money(parts.upkeep) })
  if (parts.cedar) split.push({ k: "Cedar Court", v: money(parts.cedar) })

  const mapleUnits = w.units.filter((u) => u.site !== "cedar")
  const cedarUnits = w.units.filter((u) => u.site === "cedar")
  const mapleRoll = rentRoll(mapleUnits)
  const cedarRoll = rentRoll(cedarUnits)
  const sites = [{ name: "Maple Street", roll: money(mapleRoll), daily: money(daily - parts.cedar) }]
  if (cedarUnits.length) sites.push({ name: "Cedar Court", roll: money(cedarRoll), daily: money(parts.cedar) })
  const owned = cedarUnits.length > 0
  const place = w.view === "cedar" && owned ? "Cedar Court" : "Maple Street"

  const rowDone =
    (!cedarHere && w.pads.length > 0 && w.pads.every((p) => padTaken(w, p.id)) && constructing.length === 0 && !uncom) ||
    (cedarHere && rowStarted && constructing.length === 0 && !uncom)

  return {
    clock: clockLabel(w.day, w.speed),
    dayNote: reputationLine(w),
    goal: w.steadyAt ? `Quarter · day ${w.steadyAt + 90} · ${money(w.cash)} of ${money(w.goalCash)}` : "",
    energy: `${w.energy}/${energyMax(w)}`,
    cash: money(w.cash),
    leased: `${leased} leased / ${stock}`,
    welcome: w.welcome,
    saved: !!pendingBiz && !opening(pendingBiz),
    sandboxSaved: !!pendingSand,
    override:
      w.play === "free"
        ? w.instant
          ? "Free build · Instant construction"
          : "Free build"
        : w.sandbox
          ? w.upkeep === "off"
            ? "Sandbox · No new faults"
            : "Sandbox"
          : "",
    rules: rulesText(w),
    goalLine: goalText(w),
    sandbox: w.sandbox || w.play === "free",
    checkpoint: hasCheckpoint(),
    toast: w.toast,
    sound: w.sound,
    sheet: w.sheet,
    interiorOpen: w.roofHold,
    speed: w.speed,
    resume: resumeSpeed === null ? "" : resumeSpeed === 0 ? "stay paused" : `${resumeSpeed}×`,
    place,
    switchSite: owned
      ? { id: w.view === "cedar" ? "view-maple" : "view-cedar", label: w.view === "cedar" ? "Back to Maple Street" : "Open Cedar Court", tone: "ghost" }
      : null,
    coach: coach(w),
    selection: selectionOf(w),
    books: {
      roll: money(roll),
      daily: moneyCents(daily),
      lastRent: money(w.lastRent),
      rentWhen: w.rentAge <= 0 ? "Posted today" : `${countLabel(w.rentAge, "day")} ago`,
      nextRent: countLabel(w.daysToRent, "day"),
      atRent: w.daysToRent > 0 && w.cash - daily * w.daysToRent < daily * 3 ? `Before rent ${money(Math.round(w.cash - daily * w.daysToRent))}` : "",
      gap: (() => {
        if (w.daysToRent <= 0) return null
        const before = Math.round(w.cash - daily * w.daysToRent)
        if (before >= daily * 3) return null
        const after = before + roll
        return { before: money(before), after: money(after), short: after < daily * 3 }
      })(),
      month: (() => {
        const out = Math.round(daily * 30)
        const net = Math.round(roll - out)
        const word = net >= 0 ? `${money(net)} left` : `${money(Math.abs(net))} short`
        return `If everyone pays: ${money(roll)} in, ${money(out)} out, about ${word} this month. Construction is not in that.`
      })(),
      construction: money(w.constructionSpend),
    injected: w.injected > 0 ? money(w.injected) : "",
      note: propertyNote(w),
      full: occupancyLine(w),
      market: marketLine(w),
      pass: w.lastPass ? `Last pass: ${w.lastPass}.` : "",
      owed: money(owedBalance(w)),
      owedHint: owedBalance(w) > 0 ? "Billed. Not cash." : "Nothing billed is waiting.",
      owedLive: owedBalance(w) > 0,
      ledger: (w.ledger ?? []).map((row) => ({
        text: row.text,
        amount: row.amount ? money(row.amount) : "",
      })),
      split,
      sites,
      choice: (() => {
        const offer = rowOffer(w)
        if (!offer) return null
        return {
          cost: money(CEDAR_ROW_COST),
          after: money(Math.max(0, offer.left)),
          days: offer.days,
          thin: offer.thin,
          short: offer.short,
        }
      })(),
      cedar:
        w.steadyAt && !w.units.some((u) => u.site === "cedar")
          ? { cost: money(CEDAR_COST), ready: w.cash >= CEDAR_COST }
          : null,
      units: [...w.units]
        .sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }))
        .map((u) => ({
          id: u.id,
          number: u.number,
          state: statusLine(u),
          line: `${u.site === "cedar" ? "Cedar Court" : "Maple Street"} · ${u.product.replace("x", "×")} · ${u.floor === 2 ? "Floor 2" : u.access === "drive-up" ? "Drive-up" : "Interior"}${u.climate ? " · Climate" : ""}`,
          group: bookGroup(u),
        })),
    },
    crew: {
      porter: w.porter,
      tech: w.tech,
      tech2: w.tech2,
      wage: money(PORTER_DAILY),
      techWage: money(TECH_DAILY),
      offerTech: w.elevWear !== "good" || w.milestones.serviced,
      offerTech2: w.tech && w.tasks.some((t) => t.assignee === null && (t.kind === "service" || t.targetId === "camera" || t.targetId === "hall" || t.targetId === "keypad")),
      showPriority: w.elevWear !== "good" || w.milestones.serviced,
      priority: w.priority,
      plan: w.servicePlan,
      canPlan: w.milestones.serviced,
      manager: w.manager,
      offerManager: w.milestones.graduated && w.reviewSeen,
      managerWage: money(MANAGER_DAILY),
      tasks: w.tasks.map((t) => {
        const line = w.tasks.filter((other) => other.assignee && other.assignee === t.assignee)
        const place = t.assignee ? line.indexOf(t) + 1 : 0
        const who = !t.assignee
          ? "Queued until morning"
          : place <= 1
            ? whoLabel(t.assignee)
            : `${whoLabel(t.assignee)} · ${place} in line`
        return {
          label: t.label,
          who,
          pct: Math.min(100, Math.round((t.done / t.work) * 100)),
        }
      }),
    },
    build: {
      picks: cedarHere ? 2 : picks.length,
      cost: cedarHere ? money(CEDAR_ROW_COST) : money(costN),
      daily: cedarHere ? money(1.7) : money(picks.length * 0.55),
      duration: rowDone ? "Done" : cedarHere ? (rowStarted ? "Under way" : "About 25 seconds at 1×") : picks.length ? `About ${Math.round(16 + picks.length * 4.5)} seconds at 1×` : "Select pads",
      reason,
      canConfirm: cedarHere ? !rowStarted && constructing.length === 0 && w.cash >= CEDAR_ROW_COST : picks.length > 0 && w.cash >= costN,
      canCancel: constructing.length > 0,
      refund: money(constructing.reduce((s, u) => s + u.buildCost, 0) * 0.4),
      commissioning: uncom,
      progress: constructing.length ? constructing.reduce((s, u) => s + u.progress, 0) / constructing.length : null,
      site: cedarHere ? "cedar" : "maple",
      finished: rowDone,
    },
    resetArmed,
  }
}

function occupancyLine(w: World): string {
  const live = w.units.filter((u) => u.status === "occupied" || u.status === "rentReady" || u.status === "makeReady")
  const leased = w.units.filter((u) => u.status === "occupied").length
  const pct = live.length ? Math.round((leased / live.length) * 100) : 0
  return `${leased} of ${live.length} leased, ${pct}%`
}

function marketLine(w: World): string {
  const base = w.priceNote
    ? `${w.priceNote} Since then, ${w.passesSince} passed and ${w.tookSince} leased.`
    : w.passes + w.took === 0
      ? "No prospect has answered a price yet."
      : `${w.took} leased and ${w.passes} passed at the current asking rents.`
  return w.unmet ? `${base} ${w.unmet}` : base
}

function propertyNote(w: World): string {
  const late = w.units.find((u) => u.behind && u.status === "occupied")
  const gate = w.cameraFault
    ? "The gate camera is offline."
    : !w.camera && !w.keypad
      ? "Gate coverage is still basic."
      : w.camera && w.keypad
        ? "Gate camera and keypad are in."
        : "Gate coverage is only partly upgraded."
  const company = w.units.some((u) => u.site === "cedar") ? " Company cash is shared. Cedar Court has its own rent and costs." : ""
  if (cabBlocked(w)) return `${gate} The elevator is down. Floor 2 carts wait until it is serviced.${company}`
  if (late) {
    const owed = money(late.owed ?? 0)
    return `Unit ${late.number} did not pay. ${owed} is owed and is not cash.${late.locked ? " It is overlocked, so a payment is more likely, or they leave it dirty." : " Overlock makes a payment more likely. Waiting usually means no check."} The rent roll still lists the lease.${company}`
  }
  if (w.elevWear === "down" && w.cabs >= 2) return `${gate} One cab is down. The second cab is still taking carts.${company}`
  if (w.elevWear === "due") return `${gate} The elevator is due for service. It still runs, slower.${company}`
  if (w.milestones.graduated && w.manager) return `A Manager assigns routine work from the office. Priority and the service plan are still yours.${company}`
  if (w.milestones.graduated) return `Maple Street is steady. Collected rent and daily cost are the operation. Construction is a separate spend.${company}`
  if (w.upperOpen && w.milestones.serviced) {
    const plan = w.servicePlan ? "A service plan queues the cab before it fails." : "There is no service plan yet."
    const who = w.tech ? "A Tech covers building equipment." : "Equipment still waits on you."
    return `${gate} Floor 2 is open. ${plan} ${who}`
  }
  if (w.upperOpen) return `${gate} Floor 2 is open on ${w.cabs >= 2 ? "two cabs" : "one elevator"}. Upper asking is ${money(MARKET["upper:5x10"])}${w.cabs >= 2 ? ", and it holds if one cab stops." : `, and new leases fall to ${money(UPPER_DOWN)} while that cab is down.`}`
  if (w.hvac === "live") return `${gate} Climate is live on 205 and 206. Power is inside the daily cost.`
  if (w.hvac === "building") return `${gate} HVAC plant is ${w.hvacProgress >= 1 ? "ready to commission" : "under construction"}.`
  return `${gate} Indoor 10×10s are still standard.`
}

function opening(w: World) {
  return w.welcome && w.day < 18.4 && w.cash >= 22000 && !w.units.some((u) => u.padId || u.site === "cedar")
}

function parseSave(raw: string | null): World | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw) as { world?: World } | World
    const w = parsed && typeof parsed === "object" && "units" in parsed ? (parsed as World) : parsed?.world
    if (!w || !Array.isArray(w.units) || typeof w.day !== "number") return null
    return w
  } catch {
    return null
  }
}

function better(a: World, b: World) {
  const ao = opening(a)
  const bo = opening(b)
  if (ao !== bo) return ao ? b : a
  if (a.day !== b.day) return a.day > b.day ? a : b
  return a.units.length >= b.units.length ? a : b
}

function loadSlot(key: string): World | null {
  const found: World[] = []
  try {
    const raws = [localStorage.getItem(key), sessionStorage.getItem(key)]
    if (key === KEY) raws.push(localStorage.getItem(BAK))
    for (const raw of raws) {
      const w = parseSave(raw)
      if (w) found.push(w)
    }
  } catch {
    /* storage blocked */
  }
  return found.reduce<World | null>((best, w) => (best ? better(best, w) : w), null)
}

function bestSave() {
  return loadSlot(KEY)
}

function adopt(w: World) {
  world = w
  try {
    hydrate(world)
  } catch {
    /* keep the parsed game */
  }
  if (!Array.isArray(world.movers)) world.movers = []
  for (const m of world.movers) if (m && !m.path) m.path = []
  world.speed = 0
  world.sheet = "none"
  world.selectedId = null
  world.toast = null
  world.toastTtl = 0
  loadedSave = true
  saveHold = false
}

function idbGet(key: string) {
  return new Promise<string | null>((resolve) => {
    try {
      const req = indexedDB.open("sst", 1)
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains("save")) req.result.createObjectStore("save")
      }
      req.onerror = () => resolve(null)
      req.onsuccess = () => {
        try {
          const get = req.result.transaction("save", "readonly").objectStore("save").get(key)
          get.onsuccess = () => resolve(typeof get.result === "string" ? get.result : null)
          get.onerror = () => resolve(null)
        } catch {
          resolve(null)
        }
      }
    } catch {
      resolve(null)
    }
  })
}

function idbSet(payload: string, key: string) {
  try {
    const req = indexedDB.open("sst", 1)
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains("save")) req.result.createObjectStore("save")
    }
    req.onsuccess = () => {
      try {
        req.result.transaction("save", "readwrite").objectStore("save").put(payload, key)
      } catch {
        /* ignore */
      }
    }
  } catch {
    /* ignore */
  }
}

function idbClear(key: string) {
  try {
    const req = indexedDB.open("sst", 1)
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains("save")) req.result.createObjectStore("save")
    }
    req.onsuccess = () => {
      try {
        req.result.transaction("save", "readwrite").objectStore("save").delete(key)
      } catch {
        /* ignore */
      }
    }
  } catch {
    /* ignore */
  }
}

function activeKey() {
  return world.slot === "sandbox" ? SAND : KEY
}

function saveNow(force = false) {
  if (!booted) return false
  if (!force && saveHold && opening(world)) return false
  try {
    const key = activeKey()
    const existing = localStorage.getItem(key)
    if (!force && !loadedSave && existing && opening(world)) return false
    const payload = JSON.stringify({ version: 3, world })
    if (key === KEY && existing && existing !== payload) localStorage.setItem(BAK, existing)
    localStorage.setItem(key, payload)
    sessionStorage.setItem(key, payload)
    idbSet(payload, key)
    if (localStorage.getItem(key) !== payload) return false
    loadedSave = true
    if (key === SAND) pendingSand = world
    else if (!opening(world)) pendingBiz = world
    return true
  } catch {
    return false
  }
}

export function saveGame() {
  if (opening(world)) {
    const other = bestSave()
    if (other && !opening(other)) {
      world.toast = "This is a new day. The earlier game is still the saved one."
      world.toastTtl = 3.4
      publish()
      return false
    }
  }
  const ok = saveNow(true)
  world.toast = ok
    ? `Saved. Day ${Math.floor(world.day)} · ${money(world.cash)}.`
    : "Not saved. This browser kept it in memory only."
  world.toastTtl = 3.4
  publish()
  return ok
}

function saveSoon() {
  const now = Date.now()
  if (now - saveAt < 1200) return
  saveAt = now
  saveNow()
}

export function readWorld() {
  return world
}

export function boot() {
  if (booted) return
  booted = true
  saveHold = true
  pendingBiz = loadSlot(KEY)
  pendingSand = loadSlot(SAND)
  if (pendingBiz && opening(pendingBiz)) pendingBiz = null
  publish()
  void idbGet(KEY).then((raw) => {
    const saved = parseSave(raw)
    if (saved && !opening(saved) && (!pendingBiz || better(saved, pendingBiz) === saved)) pendingBiz = saved
    if (world.welcome) publish()
  })
  void idbGet(SAND).then((raw) => {
    const saved = parseSave(raw)
    if (saved && (!pendingSand || better(saved, pendingSand) === saved)) pendingSand = saved
    if (world.welcome) publish()
  })
}

export function flushSave() {
  saveNow()
}

let pubCarry = 0

export function step(realDt: number) {
  const before = world.toast
  advanceWorld(world, realDt)
  applyInstant(world)
  noteGoal()
  if (!world.welcome && !world.ledgerSeen && world.milestones.serviced && world.porter) {
    world.ledgerSeen = true
    world.toast = "The books. Rent comes in, the daily cost goes out, and the cash is what is left."
    world.toastTtl = 4.2
    if (world.sheet !== "books") setSheet("books")
  }
  pubCarry += realDt
  if (pubCarry >= 0.25 || world.toast !== before) {
    pubCarry = 0
    publish()
    if (world.speed > 0) saveSoon()
  }
}

function noteGoal() {
  if (!world.goal || world.goalMet) return
  if (world.goal === "leased8") {
    const n = world.units.filter((u) => u.site !== "cedar" && u.status === "occupied").length
    if (n < 8) return
    world.goalMet = true
    world.toast = "Goal met. 8 units are leased. The lot stays yours."
    world.toastTtl = 4.2
    return
  }
  if (world.goal === "row") {
    const ready = world.units.some(
      (u) => u.padId && u.site !== "cedar" && (u.status === "rentReady" || u.status === "occupied" || u.status === "makeReady"),
    )
    if (!ready) return
    world.goalMet = true
    world.toast = "Goal met. A new row is commissioned. The lot stays yours."
    world.toastTtl = 4.2
    return
  }
  if (world.goal !== "profit") return
  if (world.day < world.goalDay || world.cash <= world.openedCash) return
  world.goalMet = true
  world.toast = `Goal met. Cash is above the ${money(world.openedCash)} you started with.`
  world.toastTtl = 4.2
}

export function saveCheckpoint() {
  try {
    localStorage.setItem(CHECK, JSON.stringify(world))
  } catch {
    refuse("The checkpoint could not be saved.")
    return
  }
  world.toast = "Checkpoint saved. The main save is unchanged."
  world.toastTtl = 3.6
  publish()
}

export function restoreCheckpoint() {
  let raw: string | null = null
  try {
    raw = localStorage.getItem(CHECK)
  } catch {
    raw = null
  }
  const saved = parseSave(raw)
  if (!saved) {
    refuse("No checkpoint yet.")
    return
  }
  adopt(saved)
  world.toast = "Checkpoint restored."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function addFunds() {
  if (world.play !== "free" && !world.sandbox) {
    refuse("Sandbox funds are on a sandbox setup, not the plain start.")
    return
  }
  const amount = 5000
  world.injected += amount
  world.cash += amount
  pushLedger(world, `Sandbox funds · ${money(amount)} in`, amount)
  world.toast = `Added ${money(amount)}. Sandbox funds, not income.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function endLease() {
  const unit = world.units.find((u) => u.id === world.selectedId && u.status === "occupied")
  if (!unit) {
    refuse("Select a leased unit.")
    return
  }
  if (world.play !== "free" && !world.sandbox) {
    refuse("Ending a lease early is a sandbox tool.")
    return
  }
  const owed = unit.owed || 0
  unit.status = "rentReady"
  unit.tenant = null
  unit.lease = null
  unit.behind = false
  unit.locked = false
  unit.owed = 0
  unit.rentDue = undefined
  unit.doorOpen = 0
  pushLedger(world, `Lease ended on ${unit.number}. ${owed ? `${money(owed)} owed was dropped.` : "No payment."}`, 0)
  world.toast = `${unit.number} is empty. They left. You can remove the unit.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function demolishUnit() {
  const unit = world.units.find((u) => u.id === world.selectedId)
  if (!unit) {
    refuse("Select a unit.")
    return
  }
  if (unit.site === "cedar") {
    refuse("Cedar Court is not removed from here.")
    return
  }
  if (unit.status === "occupied") {
    refuse("They are still in. End the lease first.")
    return
  }
  if (unit.status === "constructing") {
    refuse("Cancel construction instead of removing it.")
    return
  }
  if (world.play !== "free" && !world.sandbox && !unit.padId) {
    refuse("The starter units stay unless this is a sandbox.")
    return
  }
  world.tasks = world.tasks.filter((t) => t.targetId !== unit.id)
  const refund = unit.buildCost > 0 ? unit.buildCost * 0.4 : 0
  if (refund) giveBack(refund, `Removed ${unit.number}`)
  world.units = world.units.filter((u) => u.id !== unit.id)
  world.selectedId = null
  world.sheet = "none"
  world.toast = refund ? `Removed ${unit.number}. Refund ${money(refund)}.` : `Removed ${unit.number}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

function deskOpen(sheet: Sheet) {
  return sheet === "books" || sheet === "crew"
}

function setSheet(sheet: Sheet) {
  const was = deskOpen(world.sheet)
  const next = deskOpen(sheet)
  if (!was && next && resumeSpeed === null) resumeSpeed = world.speed
  if (was && !next && resumeSpeed !== null) {
    world.speed = resumeSpeed
    resumeSpeed = null
  }
  if (next) world.speed = 0
  world.sheet = sheet
}

export function setSpeed(speed: Speed) {
  const next: Speed = speed === 1 || speed === 2 || speed === 4 ? speed : 0
  world.welcome = false
  if (deskOpen(world.sheet)) {
    resumeSpeed = next
    world.speed = 0
  } else {
    resumeSpeed = null
    world.speed = next
  }
  publish()
  saveSoon()
}

export function noteLook() {
  if (!world.welcome) return
  world.welcome = false
  publish()
  saveSoon()
}

export function startSandbox(opts: {
  play: "business" | "free"
  instant: boolean
  lot: "starter" | "empty"
  difficulty: "relaxed" | "standard" | "hard" | "custom"
  demand?: World["demand"]
  costs?: World["costs"]
  upkeep?: World["upkeep"]
  purse?: "thin" | "open" | "full"
  goal: "" | "leased8" | "profit" | "row"
}) {
  const preset = opts.difficulty
  const fromPreset =
    preset === "relaxed"
      ? { demand: "quiet" as const, costs: "low" as const, upkeep: "normal" as const }
      : preset === "hard"
        ? { demand: "busy" as const, costs: "high" as const, upkeep: "often" as const }
        : { demand: "normal" as const, costs: "normal" as const, upkeep: "normal" as const }
  world.play = opts.play
  world.instant = opts.play === "free" && opts.instant
  world.lot = opts.lot
  world.demand = opts.demand ?? fromPreset.demand
  world.costs = opts.costs ?? fromPreset.costs
  world.upkeep = opts.upkeep ?? fromPreset.upkeep
  world.difficulty =
    world.demand === fromPreset.demand && world.costs === fromPreset.costs && world.upkeep === fromPreset.upkeep && preset !== "custom"
      ? preset === "relaxed" || preset === "hard"
        ? preset
        : "standard"
      : "custom"
  world.goal = opts.goal === "leased8" && opts.lot !== "empty" ? "" : opts.goal
  world.goalMet = false
  world.sandbox = true
  if (opts.lot === "empty") emptyLot(world)
  if (opts.purse === "thin") world.cash = 8000
  else if (opts.purse === "full") world.cash = 40000
  else if (opts.purse === "open") world.cash = 22400
  else if (preset === "relaxed") world.cash = Math.round(22400 * 1.4)
  else if (preset === "hard") world.cash = Math.round(22400 * 0.6)
  else world.cash = 22400
  world.openedCash = world.cash
  world.goalDay = Math.floor(world.day) + 30
  world.welcome = false
  publish()
  saveNow()
}

export function setSandboxPlay(play: "business" | "free") {
  if (!world.sandbox && world.play !== "free") {
    refuse("That switch is part of a sandbox setup.")
    return
  }
  if (world.play === play) return
  world.play = play
  world.sandbox = true
  if (play === "business") world.instant = false
  pushLedger(
    world,
    play === "free"
      ? "Override · free build on. A short purchase is sandbox funds, not income."
      : "Override · business cash. Purchases need cash again.",
    0,
  )
  world.toast = play === "free" ? "Free build is on. Short purchases are sandbox funds." : "Business cash is on. Purchases need cash."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function setInstantBuild(on: boolean) {
  if (world.play !== "free") {
    refuse("Instant construction is a free-build switch.")
    return
  }
  if (world.instant === on) return
  world.instant = on
  pushLedger(world, on ? "Override · instant construction on." : "Override · instant construction off. Work takes time again.", 0)
  world.toast = on ? "Construction finishes immediately. You still commission it." : "Construction takes time again."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function setUpkeep(level: World["upkeep"]) {
  if (!world.sandbox && world.play !== "free") {
    refuse("Upkeep is set in sandbox setup.")
    return
  }
  if (world.upkeep === level) return
  world.upkeep = level
  world.difficulty = "custom"
  const line =
    level === "off"
      ? "Upkeep off. New faults stop. Damage already here still needs work."
      : level === "often"
        ? "Upkeep often. Faults come sooner."
        : "Upkeep back to normal."
  pushLedger(world, `Override · ${line}`, 0)
  world.toast = line
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function setGoal(goal: World["goal"]) {
  const next = goal === "leased8" && world.lot !== "empty" ? "" : goal
  if (goal === "leased8" && world.lot !== "empty") {
    refuse("Lease 8 is for an empty lot. This one already has tenants.")
    return
  }
  world.goal = next
  world.goalMet = false
  world.goalDay = Math.floor(world.day) + 30
  if (next === "profit") world.openedCash = world.cash
  const line = next === "leased8" ? "Goal · lease 8 units." : next === "profit" ? "Goal · cash above today, in 30 days." : next === "row" ? "Goal · commission a new row." : "Goal cleared."
  pushLedger(world, line, 0)
  world.toast = line
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function continueGame() {
  saveHold = false
  const saved = pendingBiz ?? loadSlot(KEY)
  if (!saved || opening(saved)) {
    world.slot = "business"
    world.welcome = false
    publish()
    saveSoon()
    return
  }
  adopt(saved)
  if (world.slot !== "sandbox") world.slot = "business"
  world.welcome = false
  publish()
}

export function openSandbox() {
  saveHold = false
  const saved = pendingSand ?? loadSlot(SAND)
  if (saved && !opening(saved)) {
    adopt(saved)
    world.slot = "sandbox"
    world.welcome = false
    publish()
    return
  }
  world.slot = "sandbox"
  startGatedLot()
}

export function startGatedLot() {
  world.slot = "sandbox"
  startSandbox({
    play: "free",
    instant: false,
    lot: "empty",
    difficulty: "standard",
    demand: "normal",
    costs: "normal",
    upkeep: "off",
    purse: "open",
    goal: "",
  })
  world.toast = "Gated lot. The pads are empty. Build what you want."
  world.toastTtl = 4.2
  publish()
}

export function dismissWelcome() {
  world.welcome = false
  publish()
  saveSoon()
}

export function select(id: string) {
  world.welcome = false
  if (id.startsWith("pad")) {
    togglePad(id)
    return
  }
  if (id.startsWith("cedar-pad")) {
    startCedarRow()
    return
  }
  world.selectedId = id
  setSheet("inspect")
  if (id === "u107") world.milestones.inspected107 = true
  publish()
}

export function openSheet(sheet: Sheet) {
  world.welcome = false
  setSheet(sheet)
  if (sheet !== "inspect") world.selectedId = null
  if (sheet === "books" && world.milestones.graduated) world.reviewSeen = true
  if (sheet === "crew" && world.manager) world.managerSeen = true
  publish()
}

export function markRow() {
  const pad = world.pads.find((p) => !padTaken(world, p.id))
  if (!pad) return
  world.welcome = false
  world.buildPick = [pad.id]
  setSheet("build")
  world.toast = "South row marked. Confirm to start construction."
  world.toastTtl = 3.2
  publish()
}

export function togglePad(id: string) {
  if (padTaken(world, id)) return
  setSheet("build")
  world.welcome = false
  world.buildPick = world.buildPick.includes(id) ? world.buildPick.filter((p) => p !== id) : [...world.buildPick, id]
  publish()
}

export function confirmBuild() {
  const pads = world.pads.filter((p) => world.buildPick.includes(p.id) && !padTaken(world, p.id))
  const cost = pads.length * BUILD_COST
  if (!pads.length) {
    refuse("Select an empty pad first.")
    return
  }
  if (!spend(cost, pads.length === 1 ? "One drive-up unit" : `${pads.length} drive-up units`)) return
  const group = `exp${world.groupSeq++}`
  pads.forEach((pad) => {
    const number = String(301 + pad.index)
    world.units.push({
      id: `u${number}`,
      number,
      product: "5x5",
      access: "drive-up",
      x: pad.x,
      y: pad.y,
      w: pad.w,
      d: pad.d,
      h: 7,
      door: "s",
      status: "constructing",
      lease: null,
      tenant: null,
      note: null,
      group,
      padId: pad.id,
      buildCost: BUILD_COST,
      progress: 0,
      doorOpen: 0,
      climate: false,
      floor: 1,
      z: 0,
    })
  })
  world.buildPick = []
  world.milestones.commissioned = false
  world.toast = `Building ${pads.length} drive-up ${pads.length === 1 ? "unit" : "units"}. Cost ${money(cost)}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function cancelBuild() {
  const list = world.units.filter((u) => u.status === "constructing" && u.site !== "cedar")
  if (!list.length) {
    refuse("Nothing is under construction.")
    return
  }
  const refund = list.reduce((s, u) => s + u.buildCost, 0) * 0.4
  giveBack(refund, "Construction canceled")
  world.units = world.units.filter((u) => u.status !== "constructing" || u.site === "cedar")
  world.toast = `Construction canceled. Refund ${money(refund)}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function commission() {
  const list = world.units.filter((u) => u.status === "uncommissioned" && u.site !== "cedar")
  if (!list.length) {
    refuse("Nothing is waiting to be commissioned.")
    return
  }
  for (const unit of list) {
    unit.status = "rentReady"
    clearMiss(world, unit)
  }
  world.milestones.commissioned = true
  world.toast = "Row commissioned. Those units can lease."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function overlock() {
  const unit = world.units.find((u) => u.id === world.selectedId && u.behind && !u.locked && u.status === "occupied")
  if (!unit) {
    const late = world.units.find((u) => u.behind && u.status === "occupied")
    refuse(late?.locked ? "That unit is already overlocked." : "Select a unit that is behind on rent.")
    return
  }
  unit.locked = true
  world.toast = `Unit ${unit.number} is overlocked. They are more likely to pay the missed rent plus a $35 late fee, or leave the unit dirty.`
  world.toastTtl = 3.6
  publish()
  saveSoon()
}

export function startMakeReady() {
  const selected = world.units.find((u) => u.id === world.selectedId && u.status === "makeReady")
  const unit =
    selected ?? world.units.find((u) => u.status === "makeReady" && !world.tasks.some((t) => t.targetId === u.id))
  if (!unit) {
    refuse("No vacant unit is waiting for a sweep.")
    return
  }
  if (
    !queueTask(world, {
      id: `task-${unit.number}`,
      kind: "makeReady",
      targetId: unit.id,
      label: `Make-ready · ${unit.number}`,
      work: 2.4,
      done: 0,
      assignee: null,
    })
  ) {
    refuse("That sweep is already queued.")
    return
  }
  world.milestones.makeReadyStarted = true
  world.selectedId = unit.id
  world.toast = `Make-ready started on unit ${unit.number}.`
  world.toastTtl = 3.6
  setSheet("inspect")
  publish()
  saveSoon()
}

export function startRecover() {
  if (!world.carts.some((c) => c.phase === "stray")) {
    refuse("No cart is out of the corral.")
    return
  }
  if (
    !queueTask(world, {
      id: "task-cart",
      kind: "recover",
      targetId: "cart",
      label: "Recover cart",
      work: 1.6,
      done: 0,
      assignee: null,
    })
  ) {
    refuse("That cart recovery is already queued.")
    return
  }
  world.selectedId = "corral"
  setSheet("inspect")
  publish()
  saveSoon()
}

export function startHallService() {
  if (!world.hallDark) {
    refuse("The hall light is already on.")
    return
  }
  if (
    !queueTask(world, {
      id: "task-hall",
      kind: "repair",
      targetId: "hall",
      label: "Replace hall lamp",
      work: 2.2,
      done: 0,
      assignee: null,
    })
  ) {
    refuse("The hall lamp is already queued.")
    return
  }
  world.roofHold = true
  world.selectedId = "building"
  setSheet("inspect")
  publish()
  saveSoon()
}

export function startKeypadService() {
  if (!world.keypadFault) {
    refuse("The keypad is not sticking.")
    return
  }
  if (
    !queueTask(world, {
      id: "task-keypad",
      kind: "repair",
      targetId: "keypad",
      label: "Service gate keypad",
      work: 2.2,
      done: 0,
      assignee: null,
    })
  ) {
    refuse("The keypad job is already queued.")
    return
  }
  world.selectedId = "gate"
  setSheet("inspect")
  publish()
  saveSoon()
}

export function startCameraService() {
  if (!world.camera) {
    refuse("There is no gate camera to service.")
    return
  }
  if (!world.cameraFault) {
    refuse("The gate camera is already online.")
    return
  }
  if (
    !queueTask(world, {
      id: "task-camera",
      kind: "repair",
      targetId: "camera",
      label: "Service gate camera",
      work: 2.2,
      done: 0,
      assignee: null,
    })
  ) {
    refuse("The camera job is already queued.")
    return
  }
  world.selectedId = "gate"
  setSheet("inspect")
  publish()
  saveSoon()
}

export function startRepair() {
  if (!world.lightFault) {
    refuse("The gate lamp is already on.")
    return
  }
  if (
    !queueTask(world, {
      id: "task-light",
      kind: "repair",
      targetId: "light",
      label: "Replace gate lamp",
      work: 2.2,
      done: 0,
      assignee: null,
    })
  ) {
    refuse("The gate lamp is already queued.")
    return
  }
  world.selectedId = "light"
  setSheet("inspect")
  publish()
  saveSoon()
}

export function buyCedar() {
  if (world.units.some((u) => u.site === "cedar")) {
    refuse("Cedar Court is already open.")
    return
  }
  if (!world.milestones.graduated && !world.manager) {
    refuse("Maple Street is not steady yet.")
    return
  }
  if (!spend(CEDAR_COST, "Cedar Court")) return
  world.units.push(...makeCedar())
  world.view = "cedar"
  world.selectedId = null
  setSheet("books")
  world.toast = "Cedar Court is yours. Its rent and costs stay on their own lines. Company cash is shared."
  world.toastTtl = 4
  publish()
  saveNow()
}

export function setView(site: "maple" | "cedar") {
  if (site === "cedar" && !world.units.some((u) => u.site === "cedar")) {
    refuse("Cedar Court is not open yet.")
    return
  }
  world.view = site
  world.selectedId = null
  setSheet("none")
  publish()
  saveSoon()
}

export function keepReserve() {
  if (!rowOffer(world) && world.heldRow) {
    refuse("The reserve is already kept.")
    return
  }
  world.heldRow = true
  world.toast = "Reserve kept. Cedar Court stays the size it is. The row can wait."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function startCedarRow() {
  if (!world.units.some((u) => u.site === "cedar")) {
    refuse("Open Cedar Court first.")
    return
  }
  if (world.units.some((u) => u.number === "C5" || (u.site === "cedar" && u.status === "constructing"))) {
    refuse("That Cedar Court row is already under way.")
    return
  }
  if (!spend(CEDAR_ROW_COST, "A Cedar Court row")) return
  const spots = [
    { number: "C5", x: 50 },
    { number: "C6", x: 59 },
  ]
  for (const spot of spots) {
    world.units.push({
      id: `u${spot.number}`,
      number: spot.number,
      product: "5x10",
      access: "drive-up",
      x: spot.x,
      y: 22,
      w: 7.2,
      d: 14,
      h: 7.2,
      door: "s",
      status: "constructing",
      lease: null,
      tenant: null,
      note: "New drive-up on Cedar Court. Not commissioned.",
      group: "cedar-row",
      padId: null,
      buildCost: CEDAR_ROW_COST / 2,
      progress: 0,
      doorOpen: 0,
      climate: false,
      floor: 1,
      z: 0,
      site: "cedar",
      ask: 140,
    })
  }
  world.view = "cedar"
  setSheet("build")
  world.toast = `Cedar Court row started. Cost ${money(CEDAR_ROW_COST)}. It does not add units on Maple Street.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function cancelCedarRow() {
  const list = world.units.filter((u) => u.site === "cedar" && u.status === "constructing")
  if (!list.length) {
    refuse("No Cedar Court row is under construction.")
    return
  }
  const refund = list.reduce((sum, unit) => sum + unit.buildCost, 0) * 0.4
  giveBack(refund, "Cedar Court row canceled")
  const ids = new Set(list.map((unit) => unit.id))
  world.units = world.units.filter((unit) => !ids.has(unit.id))
  world.toast = `Cedar Court row canceled. Refund ${money(refund)}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function commissionCedar() {
  const list = world.units.filter((u) => u.site === "cedar" && u.status === "uncommissioned")
  if (!list.length) {
    refuse("Nothing at Cedar Court is waiting to be commissioned.")
    return
  }
  for (const unit of list) {
    unit.status = "rentReady"
    unit.ask = unit.ask ?? 140
  }
  world.toast = "Cedar Court row commissioned. Those units can lease. Maple Street is unchanged."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function setAsking(key: ProductKey, value: number) {
  if (!Number.isFinite(value)) return
  const selected = world.selectedId ? findUnit(world, world.selectedId) : null
  if (selected?.site === "cedar") {
    const market = MARKET["drive-up:5x10"]
    const min = Math.round(market * 0.55)
    const max = Math.round(market * 1.9)
    const next = Math.min(max, Math.max(min, Math.round(value)))
    notePrice(`Cedar Court unit ${selected.number}`, selected.ask ?? market, next)
    selected.ask = next
    publish()
    saveSoon()
    return
  }
  const market = marketFor(key, world.hvac === "live", world.elevWear === "down" && world.cabs < 2)
  const min = Math.round(market * 0.55)
  const max = Math.round(market * 1.9)
  const next = Math.min(max, Math.max(min, Math.round(value)))
  notePrice(key.replace(":", " "), world.prices[key], next)
  world.prices[key] = next
  refreshProspect(world)
  publish()
  saveSoon()
}

function notePrice(label: string, before: number, after: number) {
  if (before === after) return
  world.passesSince = 0
  world.tookSince = 0
  world.priceNote = `${label} moved from ${money(before)} to ${money(after)}.`
}

export function queueMorning() {
  const notes: string[] = []
  if (world.lightFault && !world.tasks.some((t) => t.targetId === "light")) {
    queueTask(world, { id: "task-light", kind: "repair", targetId: "light", label: "Replace gate lamp", work: 2.2, done: 0, assignee: null })
    notes.push("the gate lamp")
  }
  if (world.hallDark && !world.tasks.some((t) => t.targetId === "hall")) {
    queueTask(world, { id: "task-hall", kind: "repair", targetId: "hall", label: "Replace hall lamp", work: 2.2, done: 0, assignee: null })
    world.roofHold = true
    notes.push("the hall light")
  }
  if (world.keypadFault && !world.tasks.some((t) => t.targetId === "keypad")) {
    queueTask(world, { id: "task-keypad", kind: "repair", targetId: "keypad", label: "Service gate keypad", work: 2.2, done: 0, assignee: null })
    notes.push("the keypad")
  }
  if (world.carts.some((c) => c.phase === "stray") && !world.tasks.some((t) => t.kind === "recover")) {
    queueTask(world, { id: "task-cart", kind: "recover", targetId: "cart", label: "Recover cart", work: 1.6, done: 0, assignee: null })
    notes.push("the cart")
  }
  const waiting = world.tasks.some((t) => t.assignee === null)
  world.toast = notes.length
    ? waiting
      ? `Queued ${notes.join(", ")}. Energy ran out, so the rest wait until morning.`
      : `Queued ${notes.join(", ")}. They run in that order.`
    : "Those jobs are already in the line."
  world.toastTtl = 3.6
  world.selectedId = null
  setSheet("none")
  publish()
  saveSoon()
}

export function buyCart() {
  if (world.carts.length >= CART_MAX) {
    refuse("The corral already holds five carts.")
    return
  }
  if (!spend(CART_COST, "A cart")) return
  const i = world.carts.length
  const x = 75.6 + (i % 3) * 3.1
  const y = 47.2 + Math.floor(i / 3) * 2.6
  world.carts.push({ id: `cart${i}`, x, y, homeX: x, homeY: y, phase: "home" })
  const free = world.carts.filter((c) => c.phase === "home").length
  world.toast = `Cart added. ${free} ${free === 1 ? "is" : "are"} free.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function buyCamera() {
  if (world.camera) {
    refuse("The camera is already in.")
    return
  }
  const ready = world.lot === "empty" || (world.milestones.repaired && !world.lightFault && world.units.some((u) => u.padId))
  if (!ready) {
    world.toast = "Commission the new row before you buy a camera."
    world.toastTtl = 3.6
    publish()
    return
  }
  if (!spend(CAMERA_COST, "A gate camera")) return
  world.camera = true
  world.cameraFault = false
  if (world.keypad && !world.securedAt) world.securedAt = world.day
  if (world.keypad) world.milestones.secured = true
  world.toast = "Camera is watching the gate and the apron."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function buyKeypad() {
  if (world.keypad) {
    refuse("The keypad is already in.")
    return
  }
  if (!world.camera) {
    world.toast = "The camera comes first. The keypad is the next visit."
    world.toastTtl = 3.6
    publish()
    return
  }
  if (!spend(KEYPAD_COST, "The keypad upgrade")) return
  world.keypad = true
  world.keypadAt = world.day
  if (world.camera && !world.securedAt) world.securedAt = world.day
  if (world.camera) world.milestones.secured = true
  world.toast = "Keypad upgraded. After-hours access is clearer."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function installHvac() {
  if (world.hvac === "live") {
    refuse("Climate is already live.")
    return
  }
  if (world.hvac !== "none") {
    refuse("The plant is already under way.")
    return
  }
  if (!world.camera || !world.keypad || world.lightFault) {
    world.toast = "Cover the gate before you buy the plant. It is not part of the lamp job."
    world.toastTtl = 3.6
    publish()
    return
  }
  if (expansionBlocked("plant", HVAC_COST, "The plant")) return
  if (!spend(HVAC_COST, "The HVAC plant")) return
  armExpansion("plant")
  world.hvac = "building"
  world.hvacProgress = 0
  world.selectedId = "building"
  setSheet("inspect")
  world.toast = `HVAC plant started. Cost ${money(HVAC_COST)}. Commission it when the work finishes.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function cancelHvac() {
  if (world.hvac !== "building" || world.hvacProgress >= 1) {
    refuse("The plant can no longer be canceled.")
    return
  }
  giveBack(HVAC_COST * 0.4, "Plant canceled")
  world.hvac = "none"
  world.hvacProgress = 0
  if (world.expandLock === "plant") {
    world.expandLock = ""
    world.expandUntil = 0
  }
  world.toast = `Plant canceled. Refund ${money(HVAC_COST * 0.4)}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function commissionClimate() {
  if (world.hvac === "live") {
    refuse("Climate is already live.")
    return
  }
  if (world.hvac !== "building" || world.hvacProgress < 1) {
    refuse("The plant is not ready to commission.")
    return
  }
  world.hvac = "live"
  world.milestones.climate = true
  const rate = marketFor("interior:10x10", true)
  if (world.prices["interior:10x10"] <= MARKET["interior:10x10"]) world.prices["interior:10x10"] = rate
  for (const number of ["205", "206"]) {
    const unit = world.units.find((u) => u.number === number)
    if (!unit) continue
    unit.climate = true
    if (unit.status === "occupied") unit.lease = rate
    unit.note = "Climate-controlled. The HVAC plant covers this unit."
  }
  world.toast = "Climate is live. Units 205 and 206 moved to the climate rate."
  world.toastTtl = 4
  publish()
  saveNow()
}

function refuse(text: string) {
  world.toast = text
  world.toastTtl = 3.6
  publish()
}

function shortOf(cost: number, label: string): boolean {
  if (world.cash >= cost) return false
  const short = cost - world.cash
  const when = world.daysToRent === 1 ? "day" : "days"
  world.toast = `Not enough cash. ${label} is ${money(cost)}. You are short ${money(short)}. Rent posts in ${world.daysToRent} ${when}.`
  world.toastTtl = 4
  publish()
  return true
}

function spend(cost: number, label: string): boolean {
  if (world.play === "free" && world.cash < cost) {
    const need = Math.round((cost - world.cash) * 100) / 100
    world.injected += need
    world.cash += need
    pushLedger(world, `Sandbox funds · ${money(need)} in`, need)
  }
  if (shortOf(cost, label)) return false
  world.cash -= cost
  world.constructionSpend += cost
  pushLedger(world, `${label} · ${money(cost)} out`, -cost)
  return true
}

function giveBack(amount: number, label: string) {
  world.cash += amount
  world.constructionSpend = Math.max(0, world.constructionSpend - amount)
  pushLedger(world, `${label} · ${money(amount)} back`, amount)
}

function expansionBlocked(side: "plant" | "up", cost: number, label: string): boolean {
  if (world.expandLock && world.day >= world.expandUntil) {
    world.expandLock = ""
    world.expandUntil = 0
  }
  if (!world.expandLock || world.expandLock === side) return false
  const days = Math.max(0, Math.ceil(world.expandUntil - world.day))
  const when = days === 1 ? "day" : "days"
  refuse(`${label} is ${money(cost)}. It waits until rent posts in ${days} ${when}.`)
  return true
}

function armExpansion(side: "plant" | "up") {
  if (world.expandLock) return
  world.expandLock = side
  world.expandUntil = Math.floor(world.day) + Math.max(1, world.daysToRent)
}

function comingRent(w: World) {
  return w.units.reduce((sum, u) => sum + (u.status === "occupied" && !u.behind ? (u.lease ?? 0) : 0), 0)
}

function holdsTheOther(w: World, paying: number, other: number): boolean {
  if (w.cash - paying >= other) return true
  if (w.daysToRent > 0 && w.daysToRent <= 14) {
    const after = w.cash - paying - dailyCost(w) * w.daysToRent + comingRent(w)
    return after >= other
  }
  return false
}

export function startFloor() {
  if (world.upperOpen) {
    refuse("Floor 2 is already open.")
    return
  }
  if (world.floor2 !== "none") {
    refuse("The second floor is already under way.")
    return
  }
  if (expansionBlocked("up", FLOOR_COST, "The floor")) return
  if (world.elevator === "none" && !holdsTheOther(world, FLOOR_COST, ELEVATOR_COST)) {
    world.toast = `The floor is ${money(FLOOR_COST)} and the elevator is ${money(ELEVATOR_COST)}. Paying for the floor now leaves the cab unpaid. Wait for rent, or keep that cash.`
    world.toastTtl = 4.2
    publish()
    return
  }
  if (!spend(FLOOR_COST, "The second floor")) return
  armExpansion("up")
  world.floor2 = "building"
  world.floorProgress = 0
  world.selectedId = "building"
  setSheet("inspect")
  world.toast = `Second floor started. Cost ${money(FLOOR_COST)}. It cannot open without an elevator.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function startElevator() {
  if (world.upperOpen) {
    refuse("Floor 2 is already open.")
    return
  }
  if (world.elevator !== "none") {
    refuse("The elevator is already under way.")
    return
  }
  if (expansionBlocked("up", ELEVATOR_COST, "The elevator")) return
  if (world.floor2 === "none" && !holdsTheOther(world, ELEVATOR_COST, FLOOR_COST)) {
    world.toast = `The elevator is ${money(ELEVATOR_COST)} and the floor is ${money(FLOOR_COST)}. Buying the cab now leaves the floor unpaid. Wait for rent, or buy the floor first.`
    world.toastTtl = 4.2
    publish()
    return
  }
  if (!spend(ELEVATOR_COST, "The elevator")) return
  armExpansion("up")
  world.elevator = "building"
  world.elevatorProgress = 0
  world.selectedId = "building"
  setSheet("inspect")
  world.toast = `Elevator started. Cost ${money(ELEVATOR_COST)}. One cab.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function cancelFloor() {
  if (world.floor2 !== "building" || world.floorProgress >= 1) {
    refuse("The floor can no longer be canceled.")
    return
  }
  const refund = FLOOR_COST * 0.4
  giveBack(refund, "Floor canceled")
  world.floor2 = "none"
  world.floorProgress = 0
  if (world.expandLock === "up" && world.elevator === "none") {
    world.expandLock = ""
    world.expandUntil = 0
  }
  world.toast = `Floor canceled. Refund ${money(refund)}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function cancelElevator() {
  if (world.elevator !== "building" || world.elevatorProgress >= 1) {
    refuse("The elevator can no longer be canceled.")
    return
  }
  const refund = ELEVATOR_COST * 0.4
  giveBack(refund, "Elevator canceled")
  world.elevator = "none"
  world.elevatorProgress = 0
  if (world.expandLock === "up" && world.floor2 === "none") {
    world.expandLock = ""
    world.expandUntil = 0
  }
  world.toast = `Elevator canceled. Refund ${money(refund)}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function startSecondCab() {
  if (!world.upperOpen) {
    refuse("Open floor 2 before a second cab.")
    return
  }
  if (world.secondCab !== "none" || world.cabs >= 2) {
    refuse("A second cab is already in or under way.")
    return
  }
  if (!spend(SECOND_CAB_COST, "A second cab")) return
  world.secondCab = "building"
  world.secondProgress = 0
  world.selectedId = "building"
  setSheet("inspect")
  world.toast = `Second cab started. Cost ${money(SECOND_CAB_COST)}. It takes floor area and does not add units.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function cancelSecondCab() {
  if (world.secondCab !== "building" || world.secondProgress >= 1) {
    refuse("The second cab can no longer be canceled.")
    return
  }
  const refund = SECOND_CAB_COST * 0.4
  giveBack(refund, "Second cab canceled")
  world.secondCab = "none"
  world.secondProgress = 0
  world.toast = `Second cab canceled. Refund ${money(refund)}.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function openUpper() {
  if (world.upperOpen) {
    refuse("Floor 2 is already open.")
    return
  }
  if (world.floor2 !== "built" || world.elevator !== "built") {
    refuse("Floor 2 needs both the floor and the elevator finished.")
    return
  }
  world.upperOpen = true
  world.milestones.upper = true
  world.upperAt = world.day
  ensureUpperUnits(world)
  world.roofHold = true
  world.selectedId = "building"
  setSheet("inspect")
  world.toast = "Floor 2 is open. Units 401 to 406 can lease. The elevator is one cab."
  world.toastTtl = 4.2
  publish()
  saveNow()
}

export function hirePorter() {
  if (world.porter) {
    refuse("A porter is already on the crew.")
    return
  }
  world.porter = true
  world.milestones.hired = true
  addEnergy()
  const porter = world.movers.find((m) => m.id === "porter")
  if (porter) porter.visible = true
  pushLedger(world, `Porter hired. ${money(PORTER_DAILY)} a day.`, 0)
  world.toast = "Porter hired. Two jobs can move at once."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function hireTech() {
  if (world.tech) {
    refuse("A tech is already on the crew.")
    return
  }
  world.tech = true
  world.milestones.hired = true
  addEnergy()
  const tech = world.movers.find((m) => m.id === "tech")
  if (tech) {
    tech.visible = true
    tech.x = tech.x || 54
    tech.y = tech.y || 30
  }
  pushLedger(world, `Tech hired. ${money(TECH_DAILY)} a day.`, 0)
  world.toast = `Tech hired. Wage ${money(TECH_DAILY)} a day. Equipment can move without you.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function hireTech2() {
  if (!world.tech) {
    refuse("Hire the first tech before a second.")
    return
  }
  if (world.tech2) {
    refuse("A second tech is already on the crew.")
    return
  }
  world.tech2 = true
  addEnergy()
  const tech = world.movers.find((m) => m.id === "tech2")
  if (tech) tech.visible = true
  pushLedger(world, `Second tech hired. ${money(TECH_DAILY)} a day.`, 0)
  world.toast = `Second Tech hired. Wage ${money(TECH_DAILY)} a day. A waiting repair can start while the first Tech is busy.`
  world.toastTtl = 3.8
  publish()
  saveNow()
}

export function hireManager() {
  if (world.manager) {
    refuse("A manager is already on the crew.")
    return
  }
  if (!world.milestones.graduated || !world.reviewSeen) {
    refuse("The quarter review comes before a manager.")
    return
  }
  world.manager = true
  addEnergy()
  const manager = world.movers.find((m) => m.id === "manager")
  if (manager) {
    manager.visible = true
    manager.x = manager.x || 37
    manager.y = manager.y || 33
  }
  if (world.sheet === "crew") world.managerSeen = true
  pushLedger(world, `Manager hired. ${money(MANAGER_DAILY)} a day.`, 0)
  world.toast = `Manager hired. Wage ${money(MANAGER_DAILY)} a day. Routine work follows your policies.`
  world.toastTtl = 3.8
  publish()
  saveNow()
}

export function releaseManager() {
  if (!world.manager) {
    refuse("There is no manager to release.")
    return
  }
  world.manager = false
  world.managerAlert = null
  world.energy = Math.min(world.energy, energyMax(world))
  const manager = world.movers.find((m) => m.id === "manager")
  if (manager) manager.visible = false
  world.toast = "Manager released. Routine work waits on you again."
  world.toastTtl = 3.4
  publish()
  saveNow()
}

export function startService() {
  if (world.elevWear === "good") {
    refuse("The elevator does not need service.")
    return
  }
  if (!queueService(world)) {
    refuse("Elevator service is already queued.")
    return
  }
  world.selectedId = "building"
  setSheet("inspect")
  const bill = world.elevWear === "down" ? SERVICE_PARTS : PLAN_PARTS
  world.toast = `Elevator service started. Parts ${money(bill)} when it finishes.`
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function setPriority(priority: "equipment" | "turnover") {
  world.priority = priority
  world.toast =
    priority === "equipment"
      ? "Equipment first. A down elevator outranks a sweep."
      : "Turnover first. Empty units get turned before equipment."
  world.toastTtl = 3.2
  publish()
  saveSoon()
}

export function setServicePlan(on: boolean) {
  world.servicePlan = on
  if (on && world.elevWear === "due") queueService(world)
  world.toast = on
    ? world.elevWear === "down"
      ? "Service plan is on. It starts after this cab is repaired."
      : "Service plan is on. The next due visit is queued before the cab fails."
    : "Service plan is off. The cab can go down if nobody services it."
  world.toastTtl = 3.6
  publish()
  saveNow()
}

export function toggleInterior() {
  world.roofHold = !world.roofHold
  publish()
}

export function toggleSound() {
  world.sound = !world.sound
  setHeard(world.sound)
  publish()
}

export function armReset() {
  if (!resetArmed) {
    resetArmed = true
    publish()
    return
  }
  resetArmed = false
  resumeSpeed = null
  const key = world.slot === "sandbox" ? SAND : KEY
  world = freshWorld()
  loadedSave = true
  saveHold = true
  try {
    localStorage.removeItem(key)
    sessionStorage.removeItem(key)
    if (key === KEY) {
      localStorage.removeItem(BAK)
      localStorage.removeItem(CHECK)
    }
  } catch {
    /* ignore */
  }
  idbClear(key)
  if (key === SAND) pendingSand = null
  else pendingBiz = null
  publish()
}

export function runAction(id: string) {
  if (id === "speed1") setSpeed(1)
  else if (id === "inspect107") select("u107")
  else if (id === "inspectLight") select("light")
  else if (id === "inspectCorral") select("corral")
  else if (id === "buy-cart") buyCart()
  else if (id === "crew") openSheet("crew")
  else if (id === "build") openSheet("build")
  else if (id === "mark-row") markRow()
  else if (id === "confirm-build") confirmBuild()
  else if (id === "books") openSheet("books")
  else if (id === "commission") commission()
  else if (id === "inspect-behind") {
    const late = world.units.find((u) => u.behind && u.status === "occupied")
    if (late) select(late.id)
    else refuse("No unit is behind on rent.")
  }
  else if (id === "overlock") overlock()
  else if (id === "end-lease") endLease()
  else if (id === "demolish") demolishUnit()
  else if (id === "checkpoint") saveCheckpoint()
  else if (id === "restore-checkpoint") restoreCheckpoint()
  else if (id === "add-funds") addFunds()
  else if (id === "sandbox-business") setSandboxPlay("business")
  else if (id === "sandbox-free") setSandboxPlay("free")
  else if (id === "instant-on") setInstantBuild(true)
  else if (id === "instant-off") setInstantBuild(false)
  else if (id === "upkeep-off") setUpkeep("off")
  else if (id === "upkeep-normal") setUpkeep("normal")
  else if (id === "upkeep-often") setUpkeep("often")
  else if (id === "goal-none") setGoal("")
  else if (id === "goal-leased8") setGoal("leased8")
  else if (id === "goal-profit") setGoal("profit")
  else if (id === "goal-row") setGoal("row")
  else if (id === "make-ready") startMakeReady()
  else if (id === "repair") startRepair()
  else if (id === "service-camera") startCameraService()
  else if (id === "recover-cart") startRecover()
  else if (id === "queue-morning") queueMorning()
  else if (id === "service-hall") startHallService()
  else if (id === "service-keypad") startKeypadService()
  else if (id === "interior") toggleInterior()
  else if (id === "inspectGate") select("gate")
  else if (id === "inspectBuilding") select("building")
  else if (id === "camera") buyCamera()
  else if (id === "keypad") buyKeypad()
  else if (id === "hvac") installHvac()
  else if (id === "cancel-hvac") cancelHvac()
  else if (id === "climate") commissionClimate()
  else if (id === "floor2") startFloor()
  else if (id === "elevator") startElevator()
  else if (id === "cancel-floor") cancelFloor()
  else if (id === "cancel-elevator") cancelElevator()
  else if (id === "second-cab") startSecondCab()
  else if (id === "cancel-second") cancelSecondCab()
  else if (id === "buy-cedar") buyCedar()
  else if (id === "view-maple") setView("maple")
  else if (id === "view-cedar") setView("cedar")
  else if (id === "cedar-row") startCedarRow()
  else if (id === "keep-reserve") keepReserve()
  else if (id === "cancel-cedar-row") cancelCedarRow()
  else if (id === "commission-cedar") commissionCedar()
  else if (id === "open-upper") openUpper()
  else if (id === "service") startService()
  else if (id === "hire-porter") hirePorter()
  else if (id === "hire-tech") hireTech()
  else if (id === "hire-tech-2") hireTech2()
  else if (id === "hire-manager") hireManager()
  else if (id === "plan") setServicePlan(!world.servicePlan)
}
