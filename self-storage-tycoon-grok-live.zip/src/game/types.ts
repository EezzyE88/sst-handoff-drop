export type Speed = 0 | 1 | 2 | 4
export type Sheet = "none" | "inspect" | "build" | "books" | "crew"
export type Access = "drive-up" | "interior"
export type Product = "5x5" | "5x10" | "10x10"
export type ProductKey = "drive-up:5x5" | "drive-up:5x10" | "interior:5x10" | "interior:10x10" | "upper:5x10"
export type UnitStatus =
  | "occupied"
  | "makeReady"
  | "rentReady"
  | "constructing"
  | "uncommissioned"
export type Door = "s" | "n" | "e" | "w"

export interface Unit {
  id: string
  number: string
  product: Product
  access: Access
  x: number
  y: number
  w: number
  d: number
  h: number
  door: Door
  status: UnitStatus
  lease: number | null
  tenant: string | null
  note: string | null
  group: string | null
  padId: string | null
  buildCost: number
  progress: number
  doorOpen: number
  climate: boolean
  floor: 1 | 2
  z: number
  site?: "maple" | "cedar"
  ask?: number | null
  behind?: boolean
  locked?: boolean
  rentDue?: number
  owed?: number
}

export interface Pad {
  id: string
  index: number
  x: number
  y: number
  w: number
  d: number
}

export type TaskKind = "makeReady" | "repair" | "service" | "recover"
export type StaffRole = "owner" | "porter" | "tech" | "tech2"

export interface Task {
  id: string
  kind: TaskKind
  targetId: string
  label: string
  work: number
  done: number
  assignee: StaffRole | null
}

export interface Mover {
  id: string
  kind: "person" | "car" | "crew"
  role: "owner" | "porter" | "customer" | "crew" | "tech" | "tech2" | "manager"
  x: number
  y: number
  path: { x: number; y: number }[]
  speed: number
  fill: string
  wait: number
  visible: boolean
  facing: "x" | "y"
  working: boolean
  heldCart: boolean
  vehicle: "sedan" | "pickup" | "van" | null
}

export interface Cart {
  id: string
  x: number
  y: number
  homeX: number
  homeY: number
  phase: "home" | "follow" | "return" | "stray"
}

export interface Prospect {
  unitId: string
  wait: number
  name: string
  pass: boolean
}

export interface Visit {
  kind: "interior" | "lease" | "pass" | "moveout" | "office"
  stage: number
  wait: number
  unitId: string | null
  name: string
  cartId: string | null
  line?: string
  since?: number
}

export interface Milestones {
  inspected107: boolean
  makeReadyStarted: boolean
  rentReady: boolean
  leased: boolean
  commissioned: boolean
  cartSeen: boolean
  repaired: boolean
  hired: boolean
  secured: boolean
  cameraServiced: boolean
  cartRecovered: boolean
  hallLit: boolean
  keypadServiced: boolean
  climate: boolean
  upper: boolean
  serviced: boolean
  turnover: boolean
  turned: boolean
  cycled: boolean
  graduated: boolean
}

export interface LedgerEntry {
  text: string
  amount: number
}

export interface World {
  version: number
  speed: Speed
  day: number
  billedThrough: number
  daysToRent: number
  rentAge: number
  cash: number
  prices: Record<ProductKey, number>
  units: Unit[]
  pads: Pad[]
  tasks: Task[]
  movers: Mover[]
  carts: Cart[]
  visit: Visit | null
  prospect: Prospect | null
  nextInterior: number
  lightFault: boolean
  porter: boolean
  camera: boolean
  cameraFault: boolean
  securedAt: number
  keypad: boolean
  looseAt: number
  hallDark: boolean
  hallAt: number
  keypadFault: boolean
  keypadAt: number
  cartNote: boolean
  cartPace: number
  dock: number
  hvac: "none" | "building" | "live"
  hvacProgress: number
  floor2: "none" | "building" | "built"
  elevator: "none" | "building" | "built"
  floorProgress: number
  elevatorProgress: number
  upperOpen: boolean
  cabs: number
  secondCab: "none" | "building" | "built"
  secondProgress: number
  queueSeen: boolean
  view: "maple" | "cedar"
  cedarWait: number
  cedarPassId: string | null
  elevatorQueue: number
  cab: number
  elevWear: "good" | "due" | "down"
  wearAt: number
  upperAt: number
  tech: boolean
  tech2: boolean
  energy: number
  energyDay: number
  issueDay: number
  dayLeases: number
  dayPasses: number
  dayNote: string
  steadyAt: number
  goalCash: number
  quarterTold: "" | "held" | "slipped"
  passes: number
  took: number
  passesSince: number
  tookSince: number
  priceNote: string
  unmet: string
  unmetAt: number
  misses: Partial<Record<ProductKey, number>>
  lastPass: string
  expandLock: "" | "plant" | "up"
  expandUntil: number
  ledger: LedgerEntry[]
  priority: "equipment" | "turnover"
  servicePlan: boolean
  turnoverAt: number
  turnoverId: string | null
  delinquentAt: number
  lateId: string
  lateUntil: number
  officeAt: number
  officeSeen: string
  reviewSeen: boolean
  heldRow: boolean
  ledgerSeen: boolean
  manager: boolean
  managerSeen: boolean
  managerAlert: string | null
  gate: number
  roof: number
  roofHold: boolean
  welcome: boolean
  slot: "business" | "sandbox"
  play: "business" | "free"
  lot: "starter" | "empty"
  difficulty: "relaxed" | "standard" | "hard" | "custom"
  demand: "quiet" | "normal" | "busy"
  costs: "low" | "normal" | "high"
  upkeep: "off" | "normal" | "often"
  goal: "" | "leased8" | "profit" | "row"
  goalMet: boolean
  goalDay: number
  sandbox: boolean
  openedCash: number
  instant: boolean
  injected: number
  sheet: Sheet
  selectedId: string | null
  buildPick: string[]
  groupSeq: number
  milestones: Milestones
  sound: boolean
  toast: string | null
  toastTtl: number
  lastRent: number
  constructionSpend: number
  rng: number
}

export function productKey(u: Pick<Unit, "access" | "product" | "floor">): ProductKey {
  if (u.floor === 2) return "upper:5x10"
  if (u.access === "drive-up" && u.product === "5x5") return "drive-up:5x5"
  if (u.access === "drive-up") return "drive-up:5x10"
  if (u.product === "10x10") return "interior:10x10"
  return "interior:5x10"
}
