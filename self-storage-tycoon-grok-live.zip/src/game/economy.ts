import type { ProductKey, Unit, World } from "@/game/types"
import { productKey } from "@/game/types"

export const MARKET: Record<ProductKey, number> = {
  "drive-up:5x5": 95,
  "drive-up:5x10": 145,
  "interior:5x10": 129,
  "interior:10x10": 219,
  "upper:5x10": 119,
}

export const UPPER_DOWN = 86

export const BUILD_COST = 980
export const BASE_DAILY = 22
export const PORTER_DAILY = 6
export const CAMERA_COST = 1800
export const KEYPAD_COST = 900
export const CAMERA_DAILY = 1
export const HVAC_COST = 4200
export const HVAC_DAILY = 3
export const CLIMATE_10 = 360
export const FLOOR_COST = 3800
export const ELEVATOR_COST = 2200
export const ELEVATOR_DAILY = 4
export const SECOND_CAB_COST = 1400
export const SECOND_CAB_DAILY = 2
export const CEDAR_COST = 1800
export const CEDAR_DAILY = 6
export const CEDAR_ROW_COST = 1200
export const TECH_DAILY = 8
export const MANAGER_DAILY = 10
export const SERVICE_PARTS = 140
export const PLAN_PARTS = 40
export const CART_COST = 220
export const CART_MAX = 5

const UNIT_DAILY: Record<ProductKey, number> = {
  "drive-up:5x5": 0.55,
  "drive-up:5x10": 0.85,
  "interior:5x10": 0.8,
  "interior:10x10": 1.15,
  "upper:5x10": 0.7,
}

export const DAY_SECONDS = 18
export const BASE_ENERGY = 3

export function energyMax(w: { porter: boolean; tech: boolean; tech2: boolean; manager: boolean }): number {
  return BASE_ENERGY + (w.porter ? 1 : 0) + (w.tech ? 1 : 0) + (w.tech2 ? 1 : 0) + (w.manager ? 1 : 0)
}

export function money(n: number): string {
  const sign = n < 0 ? "-" : ""
  return `${sign}$${Math.round(Math.abs(n)).toLocaleString("en-US")}`
}

export function moneyCents(n: number): string {
  const sign = n < 0 ? "-" : ""
  const abs = Math.round(Math.abs(n) * 100) / 100
  const whole = Math.abs(abs - Math.round(abs)) < 0.001
  const text = whole
    ? Math.round(abs).toLocaleString("en-US")
    : abs.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  return `${sign}$${text}`
}

export function clockLabel(day: number, speed: World["speed"]): string {
  const dayNum = Math.floor(day)
  const frac = day - dayNum
  const mins = Math.floor(frac * 24 * 60 + 1e-6)
  const h = Math.floor(mins / 60) % 24
  const m = mins % 60
  const ap = h >= 12 ? "PM" : "AM"
  const h12 = h % 12 || 12
  const pace = speed === 0 ? "Paused" : `${speed}×`
  return `Day ${dayNum} · ${h12}:${m.toString().padStart(2, "0")} ${ap} · ${pace}`
}

export function rentRoll(units: Unit[]): number {
  return units.reduce((sum, u) => sum + (u.status === "occupied" ? (u.lease ?? 0) : 0), 0)
}

export function marketFor(key: ProductKey, hvacLive: boolean, elevDown = false): number {
  if (hvacLive && key === "interior:10x10") return CLIMATE_10
  if (elevDown && key === "upper:5x10") return UPPER_DOWN
  return MARKET[key]
}

export function costLines(w: Pick<World, "units" | "porter" | "tech" | "tech2" | "manager" | "camera" | "hvac" | "upperOpen" | "cabs">): {
  base: number
  payroll: number
  power: number
  elevator: number
  upkeep: number
  cedar: number
  total: number
} {
  const base = BASE_DAILY
  const payroll = (w.porter ? PORTER_DAILY : 0) + (w.tech ? TECH_DAILY : 0) + (w.tech2 ? TECH_DAILY : 0) + (w.manager ? MANAGER_DAILY : 0)
  const power = (w.camera ? CAMERA_DAILY : 0) + (w.hvac === "live" ? HVAC_DAILY : 0)
  const elevator = w.upperOpen ? ELEVATOR_DAILY + (w.cabs >= 2 ? SECOND_CAB_DAILY : 0) : 0
  let upkeep = 0
  let cedar = 0
  for (const u of w.units) {
    const live = u.status === "occupied" || u.status === "rentReady" || u.status === "makeReady"
    if (!live) continue
    if (u.site === "cedar") cedar += UNIT_DAILY[productKey(u)]
    else upkeep += UNIT_DAILY[productKey(u)]
  }
  if (w.units.some((u) => u.site === "cedar")) cedar += CEDAR_DAILY
  return { base, payroll, power, elevator, upkeep, cedar, total: base + payroll + power + elevator + upkeep + cedar }
}

export function dailyCost(w: Pick<World, "units" | "porter" | "tech" | "tech2" | "manager" | "camera" | "hvac" | "upperOpen" | "cabs"> & { costs?: World["costs"] }): number {
  const mult = w.costs === "low" ? 0.8 : w.costs === "high" ? 1.25 : 1
  return Math.round(costLines(w).total * mult * 100) / 100
}

export function siteStrain(w: Pick<World, "keypadFault" | "lightFault" | "cameraFault" | "hallDark" | "elevWear" | "cabs" | "units"> & { demand?: World["demand"] }): {
  extraWait: number
  pass: number
  reason: string | null
} {
  let extraWait = 0
  let pass = 0
  let reason: string | null = null
  const note = (text: string) => {
    if (!reason) reason = text
  }
  if (w.keypadFault) {
    extraWait += 8
    pass += 0.55
    note("the keypad is sticking")
  }
  if (w.lightFault) {
    extraWait += 3
    pass += 0.28
    note("the gate light is out")
  }
  if (w.elevWear === "down" && w.cabs < 2) {
    extraWait += 4
    pass += 0.35
    note("the elevator is down")
  }
  if (w.hallDark) {
    extraWait += 2
    pass += 0.16
    note("the hall is dark")
  }
  if (w.cameraFault) {
    extraWait += 1.2
    pass += 0.1
    note("the gate camera is offline")
  }
  const dirty = w.units.filter((u) => u.status === "makeReady").length
  if (dirty) {
    extraWait += dirty
    pass += Math.min(0.22, dirty * 0.1)
    note(dirty === 1 ? "a unit is sitting dirty" : `${dirty} units are sitting dirty`)
  }
  const lean = w.demand === "busy" ? 1.35 : w.demand === "quiet" ? 0.7 : 1
  return { extraWait, pass: Math.min(0.85, pass * lean), reason }
}

export function responseWait(ask: number, market: number, pass: boolean): number {
  if (pass) return 3.4
  const ratio = ask / Math.max(1, market)
  return 4 + Math.max(0, ratio - 0.8) * 14
}

export function isPass(ask: number, market: number, demand?: World["demand"]): boolean {
  const line = demand === "busy" ? 1.35 : demand === "quiet" ? 1.75 : 1.55
  return ask > market * line
}
