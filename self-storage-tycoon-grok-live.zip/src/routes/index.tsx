import { createFileRoute } from "@tanstack/react-router";
import { MapleGame } from "@/components/MapleGame";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <MapleGame />;
}
