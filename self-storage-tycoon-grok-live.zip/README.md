# self-storage-tycoon-grok

Independent attempt at Self Storage Tycoon, built in the Grok app builder as a TypeScript and React app with a 2D isometric canvas.

This is not the C++ project and not the three.js project.

- C++: [EezzyE88/self-storage-tycoon](https://github.com/EezzyE88/self-storage-tycoon)
- three.js: [EezzyE88/self-storage-tycoon-js](https://github.com/EezzyE88/self-storage-tycoon-js)

The playable property is Maple Street. Game code lives in `src/game` and `src/components/MapleGame.tsx`.

Saved as a snapshot of the sandbox source. `node_modules`, build output, playtest screenshots, and uploaded reference images are not included.
