#!/bin/sh
# Restart contract: bring the preview up if it is not already healthy.
set -e
cd /workspace
if ! curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  npm run dev > /tmp/sst-dev.log 2>&1 &
  i=0
  while [ "$i" -lt 40 ]; do
    curl -sf -o /dev/null --max-time 1 http://127.0.0.1:8080/ && break
    i=$((i + 1))
    sleep 0.25
  done
fi
# localhost is IPv6 here, and the preview will not show the lot until it can
# see a vite process from this session. Forward that loopback as that process.
if ! curl -sf -g -o /dev/null --max-time 2 "http://[::1]:8080/"; then
  bash -c 'exec -a "node /workspace/node_modules/.bin/vite dev --host 0.0.0.0 --port 8080" node /workspace/scripts/ipv6-loopback.mjs' > /tmp/sst-ipv6.log 2>&1 &
fi
exit 0
