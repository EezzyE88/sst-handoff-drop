Live Grok sandbox snapshot, 2026-10-02.
This is the playable Maple Street game. It is not the GitHub repo.
Read artifacts/SST_HANDOFF.md first.
node_modules and phone screenshots are not in this zip.
