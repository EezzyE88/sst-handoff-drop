import { chromium } from "playwright"
import fs from "fs"

const dir = "/workspace/screenshots/bug-2026-09-29"
fs.mkdirSync(dir, { recursive: true })
const wall = () => new Date().toLocaleString("en-US", { timeZone: "America/Los_Angeles", hour12: true, month: "short", day: "numeric", hour: "numeric", minute: "2-digit", second: "2-digit" })

const browser = await chromium.launch({ headless: true })
const page = await browser.newPage({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 2 })
const errors = []
page.on("pageerror", (e) => errors.push(String(e)))
page.on("console", (msg) => {
  if (msg.type() === "error") errors.push(msg.text())
})
await page.addInitScript(() => localStorage.clear())
await page.goto("http://127.0.0.1:8080/", { waitUntil: "networkidle" })

const shots = []
const beats = []
let n = 0
async function shot(slug) {
  n += 1
  const name = `${String(n).padStart(2, "0")}-${slug}.png`
  await page.screenshot({ path: `${dir}/${name}` })
  shots.push(name)
}

async function state() {
  return page.evaluate(async () => {
    const engine = await import("/src/game/engine.ts")
    engine.step(0)
    const s = engine.getSnapshot()
    const w = engine.readWorld()
    return {
      welcome: s.welcome,
      title: s.coach?.title ?? "(none)",
      action: s.coach?.action?.label ?? "",
      id: s.coach?.action?.id ?? "",
      body: (s.coach?.body ?? "").slice(0, 180),
      clock: s.clock,
      cash: w.cash,
      cashLabel: s.cash,
      energy: w.energy,
      sheet: s.sheet,
      toast: s.toast ?? "",
      day: Math.round(w.day * 100) / 100,
      speed: w.speed,
      tasks: w.tasks.length,
      behind: w.units.filter((u) => u.behind).map((u) => u.number),
      graduated: w.milestones.graduated,
      manager: w.manager,
      cabs: w.cabs,
      cedar: w.units.some((u) => u.site === "cedar"),
      passes: w.passes,
      took: w.took,
      full: s.books.full,
    }
  })
}

const bugs = []
function check(s) {
  if (!Number.isFinite(s.cash)) bugs.push(`${s.clock} cash not finite`)
  if (s.energy < 0 || s.energy > 8) bugs.push(`${s.clock} energy ${s.energy}`)
}

await shot("welcome")
beats.push({ wall: wall(), ...(await state()), shot: shots.at(-1) })
await page.getByRole("button", { name: "Look around" }).click()
await page.waitForTimeout(400)
await shot("day18-paused")
let previous = ""
let idle = 0

for (let step = 0; step < 36; step++) {
  const s = await state()
  check(s)
  if (s.title !== previous) {
    await shot(s.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 32) || "coach")
    beats.push({ wall: wall(), ...s, shot: shots.at(-1) })
    previous = s.title
    idle = 0
  } else {
    idle += 1
  }
  if (s.sheet === "books" || s.sheet === "crew") {
    await shot(s.sheet)
    beats.push({ wall: wall(), ...s, shot: shots.at(-1), note: "desk" })
    await page.getByRole("button", { name: "Close" }).click()
    await page.waitForTimeout(200)
  }
  const confirm = page.getByRole("button", { name: "Confirm build" })
  if ((await confirm.count()) && (await confirm.isEnabled())) {
    await confirm.click()
    await page.waitForTimeout(200)
  }
  const start = page.getByRole("button", { name: /Start Owner Make-Ready|Start make-ready|Start repair/ })
  if (await start.count()) {
    await start.first().click()
    await page.waitForTimeout(200)
  }
  const now = await state()
  if (now.id) {
    const coachBtn = page.locator("section.z-20 button").first()
    if (await coachBtn.count()) await coachBtn.click()
  }
  await page.getByRole("button", { name: "4×" }).click()
  await page.waitForTimeout(2800)
  await page.getByRole("button", { name: "Pause" }).click()
  if (idle >= 6) {
    bugs.push(`coach stuck on "${previous}" through ${s.clock}`)
    break
  }
}

const end = await state()
check(end)
beats.push({ wall: wall(), ...end, shot: "", note: "end of guided play" })

const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1)
if (overflow) bugs.push("horizontal overflow")

const report = { started: beats[0]?.wall, ended: wall(), shots, beats, bugs, errors }
fs.writeFileSync(`${dir}/report.json`, JSON.stringify(report, null, 2))
console.log(JSON.stringify({ shots: shots.length, beats: beats.map((b) => `${b.wall} | ${b.clock} | ${b.title} | ${b.cashLabel} | e${b.energy}`), bugs, errors }, null, 2))
await browser.close()
