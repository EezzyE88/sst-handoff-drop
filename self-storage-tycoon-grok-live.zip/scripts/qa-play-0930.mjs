import { chromium } from "playwright"
import fs from "fs"

const dir = "/workspace/screenshots/play-2026-09-30"
fs.mkdirSync(dir, { recursive: true })
const wall = () =>
  new Date().toLocaleString("en-US", {
    timeZone: "America/Los_Angeles",
    hour12: true,
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
  })

const browser = await chromium.launch({ headless: true })
const page = await browser.newPage({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 2 })
const errors = []
page.on("pageerror", (e) => errors.push(String(e)))
page.on("console", (msg) => {
  if (msg.type() === "error") errors.push(msg.text())
})
await page.addInitScript(() => localStorage.clear())
await page.goto("http://127.0.0.1:8080/", { waitUntil: "networkidle" })

const shots = []
const beats = []
let n = 0
async function shot(slug) {
  n += 1
  const name = `${String(n).padStart(2, "0")}-${slug}.png`
  await page.screenshot({ path: `${dir}/${name}` })
  shots.push(name)
  return name
}

async function buttons() {
  return page.locator("button").evaluateAll((els) =>
    els
      .map((el) => ({
        t: (el.textContent || "").replace(/\s+/g, " ").trim(),
        disabled: el.disabled,
      }))
      .filter((b) => b.t),
  )
}

async function state() {
  return page.evaluate(async () => {
    const engine = await import("/src/game/engine.ts")
    engine.step(0)
    const s = engine.getSnapshot()
    const w = engine.readWorld()
    const u107 = w.units.find((u) => u.number === "107")
    const occ = w.units.filter((u) => u.status === "occupied")
    return {
      welcome: s.welcome,
      title: s.coach?.title ?? "(none)",
      action: s.coach?.action?.label ?? "",
      id: s.coach?.action?.id ?? "",
      body: s.coach?.body ?? "",
      clock: s.clock,
      goal: s.goal,
      dayNote: s.dayNote,
      cash: w.cash,
      cashLabel: s.cash,
      energy: `${w.energy}/${s.energy}`,
      sheet: s.sheet,
      sel: s.selection?.title ?? "",
      selActions: (s.selection?.actions ?? []).map((a) => a.label),
      toast: s.toast ?? "",
      day: Math.round(w.day * 100) / 100,
      daysToRent: w.daysToRent,
      lastRent: w.lastRent,
      month: s.books.month,
      daily: s.books.daily,
      roll: s.books.roll,
      repaired: w.milestones.repaired,
      leased: w.milestones.leased,
      graduated: w.milestones.graduated,
      steadyAt: w.steadyAt,
      goalCash: w.goalCash,
      u107: u107
        ? { status: u107.status, lease: u107.lease, rentDue: u107.rentDue ?? null, tenant: u107.tenant }
        : null,
      dues: occ.map((u) => ({ n: u.number, lease: u.lease, due: u.rentDue ?? null })),
    }
  })
}

const bugs = []
const notes = []
function slug(title) {
  return title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 36) || "beat"
}

let prevCash = null
let leaseBeat = null
let rentPosts = []

async function watch(ms) {
  const btn = page.getByRole("button", { name: "4×" })
  if (await btn.count()) await btn.click()
  const start = Date.now()
  while (Date.now() - start < ms) {
    const s = await state()
    if (s.toast.startsWith("Rent posted") && !rentPosts.some((r) => r.toast === s.toast && Math.abs(r.day - s.day) < 0.2)) {
      rentPosts.push({ day: s.day, toast: s.toast, cash: s.cash, lastRent: s.lastRent, roll: s.roll, dues: s.dues })
    }
    if (s.u107?.status === "occupied" && !leaseBeat) {
      leaseBeat = {
        day: s.day,
        cashBefore: prevCash,
        cashAfter: s.cash,
        delta: prevCash == null ? null : Math.round((s.cash - prevCash) * 100) / 100,
        lease: s.u107.lease,
        rentDue: s.u107.rentDue,
        tenant: s.u107.tenant,
        toast: s.toast,
        daysToRent: s.daysToRent,
      }
    }
    prevCash = s.cash
    await page.waitForTimeout(350)
  }
  const pause = page.getByRole("button", { name: "Pause" })
  if (await pause.count()) await pause.click()
  await page.waitForTimeout(200)
}

async function record(why) {
  const s = await state()
  const shotName = await shot(slug(s.title || why))
  const b = await buttons()
  beats.push({ wall: wall(), why, ...s, buttons: b.map((x) => x.t), shot: shotName })
  if (/\b1 days\b/.test(`${s.clock} ${s.body} ${s.month} ${s.goal}`)) bugs.push(`${s.clock} grammar "1 days"`)
  if (!Number.isFinite(s.cash)) bugs.push(`${s.clock} cash not finite`)
  return { ...s, buttons: b.map((x) => x.t), shot: shotName }
}

await shot("welcome")
beats.push({ wall: wall(), why: "boot", ...(await state()), shot: shots.at(-1) })
await page.getByRole("button", { name: "Look around" }).click()
await page.waitForTimeout(400)
let previous = ""

for (let step = 0; step < 28; step++) {
  const s = await record(step === 0 ? "opened" : "loop")
  if (s.leased && s.repaired && step > 2) {
    notes.push(`Opening week ended at ${s.clock} on "${s.title}" action="${s.action || "none"}"`)
    break
  }
  if (s.title !== previous) previous = s.title
  const labels = await buttons()
  const coach = page.locator("section.z-20 button")
  if ((await coach.count()) && (await coach.first().isEnabled())) {
    await coach.first().click()
    await page.waitForTimeout(250)
  }
  const want = labels.find((b) =>
    /Start Owner Make-Ready|Start make-ready|Start repair|Confirm build|Replace the|Service the/.test(b.t) && !b.disabled,
  )
  if (want) {
    const hit = page.getByRole("button", { name: want.t, exact: true })
    if (await hit.count()) await hit.first().click()
  }
  await watch(3200)
}

const after = await record("after-opening")
notes.push(`After opening: coach "${after.title}" action "${after.action || "none"}" body: ${after.body}`)

await page.getByRole("button", { name: "Build" }).click()
await page.waitForTimeout(300)
const build = await record("build-sheet")
notes.push(`Build sheet buttons: ${build.buttons.filter((t) => !["Pause", "1×", "2×", "4×", "Save", "Center", "Sound", "Muted", "Site", "Build", "Books", "Crew"].includes(t)).join(" | ") || "(none besides chrome)"}`)

await page.getByRole("button", { name: "Books" }).click()
await page.waitForTimeout(400)
await record("books")
const back = page.getByRole("button", { name: "Back to the lot" })
if (await back.count()) await back.click()
else await page.getByRole("button", { name: "Site" }).click()
await page.waitForTimeout(200)

await page.getByRole("button", { name: "Crew" }).click()
await page.waitForTimeout(400)
await record("crew")
const back2 = page.getByRole("button", { name: "Back to the lot" })
if (await back2.count()) await back2.click()
else await page.getByRole("button", { name: "Site" }).click()
await page.waitForTimeout(200)

const tapped = await page.evaluate(async () => {
  const canvas = document.querySelector("canvas")
  if (!canvas) return { error: "no canvas" }
  const rect = canvas.getBoundingClientRect()
  const sheet = document.querySelector("section.absolute")
  const inset = sheet ? sheet.getBoundingClientRect().height : 0
  const { frameCamera } = await import("/src/game/draw.ts")
  const cam = { scale: 2, ox: 0, oy: 0 }
  frameCamera(cam, rect.width, rect.height, { focus: "site", insetBottom: inset })
  const x = 92 + 23
  const y = 16 + 31
  const sx = (x - y) * cam.scale + cam.ox
  const sy = (x + y) * cam.scale * 0.5 + cam.oy
  return { sx, sy, left: rect.left, top: rect.top, scale: cam.scale, inset }
})
if (!tapped.error) {
  await page.mouse.click(tapped.left + tapped.sx, tapped.top + tapped.sy)
  await page.waitForTimeout(400)
  const hit = await record("tap-building")
  notes.push(`Tap computed building center selected "${hit.sel || "nothing"}" actions: ${hit.selActions.join(", ") || "none"}`)
}

const end = await state()
const report = {
  started: beats[0]?.wall,
  ended: wall(),
  leaseBeat,
  rentPosts,
  notes,
  bugs,
  errors: errors.slice(0, 12),
  shots,
  beats: beats.map((b) => ({
    wall: b.wall,
    why: b.why,
    clock: b.clock,
    title: b.title,
    action: b.action,
    cash: b.cashLabel,
    day: b.day,
    toast: b.toast,
    goal: b.goal,
    u107: b.u107,
    shot: b.shot,
    body: (b.body || "").slice(0, 220),
  })),
}
fs.writeFileSync(`${dir}/report.json`, JSON.stringify(report, null, 2))
console.log(JSON.stringify({ leaseBeat, rentPosts, notes, bugs, errors: errors.slice(0, 6), beats: report.beats }, null, 2))
await browser.close()
