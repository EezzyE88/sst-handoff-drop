import net from "node:net"

// The preview probe dials localhost, which resolves to ::1 first.
// Vite is bound to IPv4 only. Forward the loopback so that probe can connect.
const server = net.createServer((client) => {
  const upstream = net.connect({ host: "127.0.0.1", port: 8080 })
  client.pipe(upstream)
  upstream.pipe(client)
  const close = () => {
    client.destroy()
    upstream.destroy()
  }
  client.on("error", close)
  upstream.on("error", close)
})

server.listen(8080, "::1", () => {
  console.log("ipv6 loopback forwarding ::1:8080 to 127.0.0.1:8080")
})
