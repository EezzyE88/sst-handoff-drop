import { chromium } from "playwright"
import fs from "fs"

const dir = "/workspace/screenshots/newbie-2026-09-29"
fs.mkdirSync(dir, { recursive: true })
const wall = () =>
  new Date().toLocaleString("en-US", { timeZone: "America/Los_Angeles", hour12: true, hour: "numeric", minute: "2-digit", second: "2-digit" })

const browser = await chromium.launch({ headless: true })
const page = await browser.newPage({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 2 })
const errors = []
page.on("pageerror", (e) => errors.push(String(e)))
page.on("console", (msg) => {
  if (msg.type() === "error") errors.push(msg.text())
})
await page.addInitScript(() => localStorage.clear())
await page.goto("http://127.0.0.1:8080/", { waitUntil: "networkidle" })

let n = 0
const beats = []
const seen = new Set()
async function shot(slug) {
  n += 1
  const name = `${String(n).padStart(2, "0")}-${slug}.png`
  await page.screenshot({ path: `${dir}/${name}` })
  return name
}
async function read() {
  return page.evaluate(() => {
    const text = document.body.innerText
    const lines = text.split("\n").map((l) => l.trim()).filter(Boolean)
    const coach = document.querySelector("section.z-20")
    const ps = coach ? [...coach.querySelectorAll("p")].map((p) => p.textContent.trim()) : []
    const btn = coach?.querySelector("button")?.textContent?.trim() ?? ""
    const desk = document.querySelector("section.fixed")
    return {
      lines: lines.slice(0, 14),
      title: ps[0] ?? (text.includes("Welcome to Maple Street") ? "Welcome" : "(none)"),
      body: ps[1] ?? "",
      action: btn,
      desk: desk ? desk.innerText.slice(0, 180) : "",
    }
  })
}

await shot("welcome")
const welcome = await read()
beats.push({ wall: wall(), ...welcome, shot: "01-welcome.png" })
await page.getByRole("button", { name: /look around/i }).click()
await page.waitForTimeout(400)

let last = ""
let idle = 0
for (let step = 0; step < 70; step++) {
  const s = await read()
  const key = `${s.title}|${s.action}`
  if (key !== last) {
    const slug = s.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 32) || "beat"
    const file = seen.has(slug) ? "" : await shot(slug)
    if (file) seen.add(slug)
    beats.push({ wall: wall(), ...s, shot: file })
    last = key
    idle = 0
  } else idle += 1

  if (s.desk) {
    const keep = page.getByRole("button", { name: "Keep the reserve" })
    if (await keep.count()) {
      await shot("choice")
      await keep.click()
      await page.waitForTimeout(200)
    }
    const close = page.getByRole("button", { name: "Close" })
    if (await close.count()) await close.click()
    await page.waitForTimeout(200)
  }
  if (s.action && !s.desk) {
    const btn = page.locator("section.z-20 button").first()
    if (await btn.count()) await btn.click()
    await page.waitForTimeout(250)
  }
  for (const name of ["Start Owner Make-Ready", "Start make-ready", "Start repair", "Confirm the row", "Mark the south row"]) {
    const extra = page.getByRole("button", { name, exact: true })
    if ((await extra.count()) && (await extra.first().isEnabled())) {
      await extra.first().click()
      await page.waitForTimeout(150)
      break
    }
  }
  const buttons = page.locator("section.absolute").getByRole("button")
  const count = await buttons.count()
  for (let i = 0; i < count; i++) {
    const b = buttons.nth(i)
    const label = ((await b.innerText()) || "").replace(/\s+/g, " ").trim()
    if (!/^(Add |Upgrade |Install |Open floor|Service |Keep a |Hire |Buy |Commission|Replace )/i.test(label)) continue
    if (await b.isEnabled()) {
      await b.click()
      await page.waitForTimeout(150)
      break
    }
  }
  const desk = page.locator("section.fixed")
  if (await desk.count()) {
    const keep = desk.getByRole("button", { name: "Keep the reserve" })
    if (await keep.count()) {
      beats.push({ wall: wall(), ...(await read()), shot: await shot("choice"), note: "choice" })
      await keep.click()
      await page.waitForTimeout(200)
    }
    const close = desk.getByRole("button", { name: "Close" })
    if (await close.count()) await close.click()
    await page.waitForTimeout(200)
  }
  await page.getByRole("button", { name: "4×" }).click()
  await page.waitForTimeout(2200)
  await page.getByRole("button", { name: "Pause" }).click()
  if (idle >= 6) {
    beats.push({ wall: wall(), ...(await read()), shot: await shot("stuck"), note: "stuck" })
    break
  }
}
fs.writeFileSync(`${dir}/report.json`, JSON.stringify({ errors, beats }, null, 2))
console.log(JSON.stringify({ errors, line: beats.map((b) => `${b.wall} | ${b.lines?.[2] ?? ""} | ${b.lines?.[4] ?? ""} | ${b.title} | ${b.action || "-"} | ${b.shot || ""}`) }, null, 2))
await browser.close()
